# Wirkungsökonomie
## WOeK Rang 22 - Detailkonzept 6: Bürger:innen als Co-Autor:innen der Wirkung
Wie Bürger:innen nicht als Datenobjekte, sondern als Mitgestalter:innen von Alltag, Kommune, Demokratie und Wirkungspraxis verstanden werden.

## Inhaltsverzeichnis
1. Dokumentlogik

2. Kurzfassung

3. Executive Summary

4. Ausgangslage und Problemstellung

5. Wirkungslogik

6. Wirkungspfade erster, zweiter und dritter Ordnung

7. Beispiel und Anwendung

8. Daten und Indikatoren

9. Umsetzungsschritte

10. Zielkonflikte und Schutzmechanismen

11. Politische Anschlussfähigkeit

12. Fazit

13. SDG- und SDG+-Bezug

14. Politische Anschlussfähigkeit und Umsetzungsoptionen

15. Quellen und interne Bezugslinien

16. Onlinefassung und Download

## Dokumentlogik
Wirkung wird in diesem Paket neutral und relational verwendet. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein und braucht immer Bezugspunkt, Zeitraum, Systemebene und Referenzrahmen. Bewertet wird am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratie, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Kurzfassung
Rang 22 übersetzt die Wirkungsökonomie in Zukunftsbilder. Zukunftsbilder sind keine Vorhersagen, keine Utopien und keine Garantie. Sie beschreiben mögliche Zustände, wenn Wirkung tatsächlich in Alltag, Unternehmen, Staat, Kapital, Medien, Bildung, Wohnen, Gesundheit, globale Kooperation und demokratische Korrektur zurückgekoppelt wird. Der Rang bildet damit den Schlussteil der Portalarchitektur: Nach Daten, Recht, Kritik und Umsetzung geht es darum, wie eine Gesellschaft aussehen kann, die nicht mehr nach Kapital als letztem Kompass steuert, sondern nach positiver Netto-Wirkung.

Dieses Dokument dient als Website-Onlinefassung, Downloadgrundlage und Baustein der Fachbibliothek. Es ersetzt keine demokratische Entscheidung. Es macht Wirkpfade, Zielkonflikte, Datenbedarfe und Umsetzungsoptionen sichtbar.

Executive Summary

Bürger:innen als Co-Autor:innen der Wirkung ist ein Detailkonzept innerhalb von Rang 22. Es konkretisiert Wie Bürger:innen nicht als Datenobjekte, sondern als Mitgestalter:innen von Alltag, Kommune, Demokratie und Wirkungspraxis verstanden werden. Das Konzept beschreibt keine perfekte Zukunft, sondern einen prüfbaren Wirkungsraum. Es zeigt, welche Zustände sich verbessern können, welche Zielkonflikte entstehen, welche Daten benötigt werden und welche politischen sowie organisatorischen Rückkopplungen notwendig sind.

Ausgangslage und Problemstellung

Zukunft wird häufig entweder als Bedrohung oder als Verheißung beschrieben. Beide Formen greifen zu kurz. Eine wirkungsökonomische Zukunftsperspektive fragt nicht zuerst, ob ein Bild optimistisch oder pessimistisch ist, sondern welche Systembedingungen es verändert. Entscheidend ist, ob Alltag, Unternehmen, Staat und globale Kooperation weniger wirkungsblind werden.

Wirkungslogik

Die Wirkungslogik dieses Detailkonzepts unterscheidet Wirkungspotenzial, eingetretene Wirkung, Nebenwirkung, Rückkopplung und Transformationswirkung. Eine Maßnahme gilt nicht schon deshalb als positiv, weil sie modern, digital, effizient oder wachstumsfördernd erscheint. Positiv ist sie nur, wenn sie auf SDGs, Agenda 2030 und SDG+ einzahlt und unter roten Linien positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugt.

Wirkungspfade erster, zweiter und dritter Ordnung

Wirkungen erster Ordnung betreffen sichtbare Veränderungen, etwa Preise, Zugänge oder Informationen. Wirkungen zweiter Ordnung betreffen Verhalten, Investitionspfade, Vertrauen und soziale Stabilität. Wirkungen dritter Ordnung verändern Regeln, Standards, Erwartungsräume und künftige Entscheidungsstrukturen. Zukunftsbilder müssen alle drei Ordnungen lesen, sonst bleiben sie dekorative Erzählungen.

Beispiel und Anwendung

Ein Beispiel zeigt die Logik: Ein neues Produktlabel kann zunächst nur Information liefern. Wenn es mit Preis, Steuer, Beschaffung, Kapitalzugang und Verbraucherentlastung verbunden wird, entsteht Rückkopplung. Wenn Unternehmen deshalb ihr Produktportfolio umbauen und Kommunen ihre Beschaffung ändern, entsteht Transformationswirkung. Das Zukunftsbild wird dann nicht nur erzählt, sondern systemisch ermöglicht.

Daten und Indikatoren

Benötigt werden Daten zu Lebensqualität, Zugang, Gesundheit, Bildung, Wohnen, Mobilität, Energie, Produktwirkung, Kapitalwirkung, Vertrauen, Rechtsstaatlichkeit, Diskursqualität, Resilienz und ökologischer Regeneration. Wichtig ist: Daten dienen nicht der Kontrolle privater Lebensführung. Sie dienen der Bewertung von Systembedingungen, Programmen, Produkten, Infrastruktur und institutionellen Wirkungen.

Umsetzungsschritte

Die Umsetzung beginnt mit Pilotfeldern, klaren Baselines, offenen Methoden, verständlichen Dashboards, Beteiligung, rechtlicher Begrenzung und jährlicher Korrektur. Erst wenn eine Maßnahme messbar bessere Zustände erzeugt und Zielkonflikte transparent macht, kann sie skaliert werden.

Zielkonflikte und Schutzmechanismen

Zielkonflikte müssen offen benannt werden: Transparenz kann Datenschutz berühren, Lenkung kann als Bevormundung empfunden werden, Standardisierung kann kulturelle Unterschiede übersehen, schnelle Umsetzung kann demokratische Beteiligung verkürzen. Deshalb braucht jedes Zukunftsbild Rechtsschutz, Datenschutz, Widerspruchsmöglichkeiten, methodische Offenheit und unabhängige Prüfung.

Politische Anschlussfähigkeit

Parteien und Institutionen können aus diesem Detailkonzept unterschiedliche politische Wege ableiten. Die Wirkungsökonomie schreibt keine Parteipolitik vor. Sie verlangt nur, dass Programme nicht allein nach Symbolik, Kosten oder Ideologie beurteilt werden, sondern nach ihrer überprüfbaren Wirkung auf Mensch, Planet und Demokratie.

Fazit

Das Detailkonzept macht Zukunft nicht sicher. Es macht sie gestaltbarer. Es ersetzt weder Streit noch Entscheidung. Es liefert einen Rahmen, in dem Zukunftsbilder nicht bloße Versprechen bleiben, sondern als Wirkungspfade, Risiken, Daten, Schutzmechanismen und Rückkopplungen bearbeitet werden können.

## SDG- und SDG+-Bezug
Rang 22 arbeitet mit den SDGs als internationalem Referenzrahmen und mit SDG+ als transparenter Erweiterung der Wirkungsökonomie. SDG+ ist keine UN-Kategorie, sondern ergänzt Demokratie, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

SDG 1 - Keine Armut

Wirkungswohlstand darf nicht auf Ausschluss beruhen. Armut wird als Zustandsveränderung in Teilhabe, Sicherheit, Gesundheit, Bildung, Wohnen und Selbstwirksamkeit betrachtet.

SDG 3 - Gesundheit und Wohlergehen

Zukunftsbilder prüfen, ob weniger Krankheit, weniger Angst, mehr Prävention, gute Pflege und bessere Lebensbedingungen entstehen.

SDG 4 - Hochwertige Bildung

Das Fach Zukunft, Wirkungskompetenz, Systemdenken und demokratische Medienkompetenz werden als Voraussetzungen einer lernfähigen Gesellschaft behandelt.

SDG 8 - Menschenwürdige Arbeit

Arbeit wird nicht nur als Erwerb, sondern als Wirkleistung gelesen. Automatisierung, Care, Bildung und sinnvolle Tätigkeiten brauchen neue Anerkennung.

SDG 9 - Industrie, Innovation und Infrastruktur

Innovation ist nicht Selbstzweck. Sie wird danach bewertet, ob sie Wirkung, Resilienz, Kreisläufe, Datenqualität und Zukunftsfähigkeit stärkt.

SDG 10 - Weniger Ungleichheiten

Zukunftsbilder müssen zeigen, ob Zugänge, Chancen, Schutz und Teilgabe breiter werden, statt neue Spaltungen zu erzeugen.

SDG 11 - Nachhaltige Städte und Gemeinden

Alltag 2035 beginnt in Quartieren: Wohnen, Mobilität, Energie, Gesundheit, Kultur und Beteiligung werden als lokale Wirkungsräume beschrieben.

SDG 12 - Nachhaltiger Konsum und Produktion

Ehrliche Preise, Produktwirkung, digitale Produktpässe und Verbraucherentlastung sind zentrale Bedingungen einer wirkungsfähigen Konsumordnung.

SDG 13 - Klimaschutz

Wohlstand ohne Zerstörung kann nicht auf Klimaschäden beruhen. Klimawirkung wird in Preise, Kapital, Infrastruktur und Alltag rückgekoppelt.

SDG 16 - Frieden, Gerechtigkeit und starke Institutionen

Demokratie, Rechtsschutz, Wahrheit, Vertrauen und Korrekturfähigkeit sind Kernbedingungen einer wirkungsfähigen Zukunft.

SDG 17 - Partnerschaften

Globale Ordnung 2050 wird als Ordnung der Kooperation, Übersetzung, Datenstandards und Wirkungspartnerschaften beschrieben, nicht als Weltregierung.

SDG+-Dimensionen

Demokratiequalität

Zukunftsfähigkeit braucht Verfahren, die Macht begrenzen, Konflikte offen halten und Korrektur ermöglichen.

Medienqualität

Öffentliche Wahrheit, Quellenklarheit und Schutz vor Desinformation sind Infrastruktur, nicht bloße Meinung.

Rechtsstaatlichkeit

Wirkungslenkung bleibt begrenzt durch Grundrechte, Datenschutz, Gerichte, Parlament und Rechtsschutz.

Diskursfähigkeit

Zukunftsbilder dürfen nicht als moralische Überwältigung erscheinen. Sie brauchen Streitfähigkeit und Übersetzung.

Institutionelles Vertrauen

Vertrauen entsteht, wenn Politik Zustände verbessert, Fehler korrigiert und Zielkonflikte offenlegt.

Gesellschaftlicher Zusammenhalt

Wohlstand entsteht nicht nur aus Kaufkraft, sondern aus Beziehung, Sicherheit, Zugehörigkeit und Teilgabe.

Digitale Selbstbestimmung

Datenräume und Wirkungsscanner dürfen keine Personenüberwachung werden. Sie dienen Systemkorrektur, nicht Kontrolle von Menschen.

## Politische Anschlussfähigkeit und Umsetzungsoptionen
Aufgabe der Politik

Politik muss Zukunftsbilder nicht als Wahlversprechen verkaufen, sondern als prüfbare Orientierungsräume gestalten. Sie schafft Rahmenbedingungen, in denen bessere Wirkung wahrscheinlicher wird: durch ehrliche Preise, Wirkungshaushalte, Rechtsstaat, Bildung, Datenqualität, Schutz vor Missbrauch, soziale Abfederung und demokratische Rückkopplung.

Politische Rahmenbedingungen

Notwendig sind rechtssichere Wirkungsdaten, öffentliche Wirkungshaushalte, faire Übergänge, Pilotkommunen, transparente Beschaffung, digitale Produktpässe, Datenschutz, unabhängige Prüfung, öffentliche Debatte und ein Schutz vor technokratischer Verengung.

Ausgestaltungsspielraum

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Parteien behalten Ausgestaltungsspielraum bei Steuern, Sozialpolitik, Infrastruktur, Bildung, Wirtschaft, Außenpolitik, Klimaschutz, Digitalisierung und Kultur. Entscheidend ist die überprüfbare Wirkung auf Mensch, Planet und Demokratie.

Zielkonflikte

Zukunftsbilder enthalten Zielkonflikte: kurzfristige Belastung und langfristige Stabilität, Datenschutz und Transparenz, Markt und Lenkung, Freiheit und Verantwortung, lokale Akzeptanz und globale Verantwortung, Investitionsschutz und Transformation, Geschwindigkeit und demokratische Legitimation.

Rollenverteilung

Bund, Länder, Kommunen, Unternehmen, Wissenschaft, Medien, Zivilgesellschaft und Bürger:innen tragen unterschiedliche Rollen. Der Staat setzt Regeln und schützt Rechte. Unternehmen organisieren Wirkung. Wissenschaft prüft. Medien schaffen öffentliche Orientierung. Bürger:innen werden nicht bewertet, sondern als Co-Autor:innen der Systemwirkung ernst genommen.

Übergang und Schutz

Der Übergang braucht Pilotierung, soziale Abfederung, Kaufkraftschutz, Datenschutz, Rechtsschutz, offene Methoden, Versionierung, klare rote Linien und Korrekturschleifen. Eine Wirkungsökonomie, die Freiheit schwächt, hätte ihren Maßstab verfehlt.

Evaluation und Korrektur

Zukunftsbilder müssen überprüft werden: Welche Zustände verbessern sich? Welche Nebenwirkungen entstehen? Welche Gruppen werden belastet? Wo kippen Anreize? Welche Daten fehlen? Welche Wirkungspfade waren falsch? Korrektur ist Pflicht, nicht Nachtrag.

Parteipolitische Anschlussfähigkeit

Konservative, liberale, sozialdemokratische, grüne, linke und kommunale Ansätze können die Wirkungslogik unterschiedlich übersetzen. Die Wirkungsökonomie bewertet nicht Ideologie, sondern Folgen.

Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Politische Bewertung, Rechtsschutz, parlamentarische Kontrolle, Gerichte und öffentliche Debatte bleiben unverzichtbar.

## Quellen und interne Bezugslinien
Natalie Weber: Die neue Ordnung des Wohlstands. Arbeitsfassung 2026. Teil XVIII - Schluss, Ausblick und zivilisatorische Perspektive.

Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

Natalie Weber: Grundlagenpapier Wirkungsökonomie WÖk, 2025.

Natalie Weber: Systemmodell der Wirkungsökonomie, 2025.

Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.

Interne Wirkungsökonomie-Arbeitsfassung: Kapitel 107 - Zukunftsbilder und Kapitel 108 - Schlussbild: Die neue Ordnung des Wohlstands.

## Onlinefassung und Download
Dieses Dokument ist für eine vollständige Onlinefassung und als PDF- sowie DOCX-Download vorgesehen. In der Website-Integration müssen beide Dateiformate sichtbar verlinkt werden.
