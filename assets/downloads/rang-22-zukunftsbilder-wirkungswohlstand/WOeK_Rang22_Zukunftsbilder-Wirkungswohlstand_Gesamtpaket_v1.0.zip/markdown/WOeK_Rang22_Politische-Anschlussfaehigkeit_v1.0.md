# Wirkungsökonomie
## WOeK Rang 22 - Politische Anschlussfähigkeit
Zukunftsbilder und Wirkungswohlstand

## Inhaltsverzeichnis
1. Dokumentlogik

2. Kurzfassung

3. Aufgabe der Politik

4. Politische Rahmenbedingungen

5. Ausgestaltungsspielraum

6. Zielkonflikte

7. Rollenverteilung

8. Übergang und Schutz

9. Evaluation und Korrektur

10. Parteipolitische Anschlussfähigkeit

11. Schutz vor Technokratie

## Dokumentlogik
Wirkung wird in diesem Paket neutral und relational verwendet. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein und braucht immer Bezugspunkt, Zeitraum, Systemebene und Referenzrahmen. Bewertet wird am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratie, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Kurzfassung
Rang 22 übersetzt die Wirkungsökonomie in Zukunftsbilder. Zukunftsbilder sind keine Vorhersagen, keine Utopien und keine Garantie. Sie beschreiben mögliche Zustände, wenn Wirkung tatsächlich in Alltag, Unternehmen, Staat, Kapital, Medien, Bildung, Wohnen, Gesundheit, globale Kooperation und demokratische Korrektur zurückgekoppelt wird. Der Rang bildet damit den Schlussteil der Portalarchitektur: Nach Daten, Recht, Kritik und Umsetzung geht es darum, wie eine Gesellschaft aussehen kann, die nicht mehr nach Kapital als letztem Kompass steuert, sondern nach positiver Netto-Wirkung.

Dieses Dokument dient als Website-Onlinefassung, Downloadgrundlage und Baustein der Fachbibliothek. Es ersetzt keine demokratische Entscheidung. Es macht Wirkpfade, Zielkonflikte, Datenbedarfe und Umsetzungsoptionen sichtbar.

Aufgabe der Politik

Politik muss Zukunftsbilder nicht als Wahlversprechen verkaufen, sondern als prüfbare Orientierungsräume gestalten. Sie schafft Rahmenbedingungen, in denen bessere Wirkung wahrscheinlicher wird: durch ehrliche Preise, Wirkungshaushalte, Rechtsstaat, Bildung, Datenqualität, Schutz vor Missbrauch, soziale Abfederung und demokratische Rückkopplung.

Politische Rahmenbedingungen

Notwendig sind rechtssichere Wirkungsdaten, öffentliche Wirkungshaushalte, faire Übergänge, Pilotkommunen, transparente Beschaffung, digitale Produktpässe, Datenschutz, unabhängige Prüfung, öffentliche Debatte und ein Schutz vor technokratischer Verengung.

Ausgestaltungsspielraum

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Parteien behalten Ausgestaltungsspielraum bei Steuern, Sozialpolitik, Infrastruktur, Bildung, Wirtschaft, Außenpolitik, Klimaschutz, Digitalisierung und Kultur. Entscheidend ist die überprüfbare Wirkung auf Mensch, Planet und Demokratie.

Zielkonflikte

Zukunftsbilder enthalten Zielkonflikte: kurzfristige Belastung und langfristige Stabilität, Datenschutz und Transparenz, Markt und Lenkung, Freiheit und Verantwortung, lokale Akzeptanz und globale Verantwortung, Investitionsschutz und Transformation, Geschwindigkeit und demokratische Legitimation.

Rollenverteilung

Bund, Länder, Kommunen, Unternehmen, Wissenschaft, Medien, Zivilgesellschaft und Bürger:innen tragen unterschiedliche Rollen. Der Staat setzt Regeln und schützt Rechte. Unternehmen organisieren Wirkung. Wissenschaft prüft. Medien schaffen öffentliche Orientierung. Bürger:innen werden nicht bewertet, sondern als Co-Autor:innen der Systemwirkung ernst genommen.

Übergang und Schutz

Der Übergang braucht Pilotierung, soziale Abfederung, Kaufkraftschutz, Datenschutz, Rechtsschutz, offene Methoden, Versionierung, klare rote Linien und Korrekturschleifen. Eine Wirkungsökonomie, die Freiheit schwächt, hätte ihren Maßstab verfehlt.

Evaluation und Korrektur

Zukunftsbilder müssen überprüft werden: Welche Zustände verbessern sich? Welche Nebenwirkungen entstehen? Welche Gruppen werden belastet? Wo kippen Anreize? Welche Daten fehlen? Welche Wirkungspfade waren falsch? Korrektur ist Pflicht, nicht Nachtrag.

Parteipolitische Anschlussfähigkeit

Konservative, liberale, sozialdemokratische, grüne, linke und kommunale Ansätze können die Wirkungslogik unterschiedlich übersetzen. Die Wirkungsökonomie bewertet nicht Ideologie, sondern Folgen.

Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Politische Bewertung, Rechtsschutz, parlamentarische Kontrolle, Gerichte und öffentliche Debatte bleiben unverzichtbar.
