# Wirkungsökonomie
## WOeK Rang 22 - Gesamtdossier
Zukunftsbilder, Wirkungswohlstand und zivilisatorische Perspektive

## Inhaltsverzeichnis
1. Dokumentlogik

2. Kurzfassung

3. Executive Summary

4. Buchanker Teil XVIII

5. Alltag 2035

6. Unternehmen 2035

7. Staat 2035

8. Globale Ordnung 2050

9. Wirkungswohlstand

10. Grenzen

11. Website- und Akademielogik

12. SDG- und SDG+-Bezug

13. Politische Anschlussfähigkeit und Umsetzungsoptionen

14. Quellen und interne Bezugslinien

15. Onlinefassung und Download

## Dokumentlogik
Wirkung wird in diesem Paket neutral und relational verwendet. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein und braucht immer Bezugspunkt, Zeitraum, Systemebene und Referenzrahmen. Bewertet wird am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratie, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Kurzfassung
Rang 22 übersetzt die Wirkungsökonomie in Zukunftsbilder. Zukunftsbilder sind keine Vorhersagen, keine Utopien und keine Garantie. Sie beschreiben mögliche Zustände, wenn Wirkung tatsächlich in Alltag, Unternehmen, Staat, Kapital, Medien, Bildung, Wohnen, Gesundheit, globale Kooperation und demokratische Korrektur zurückgekoppelt wird. Der Rang bildet damit den Schlussteil der Portalarchitektur: Nach Daten, Recht, Kritik und Umsetzung geht es darum, wie eine Gesellschaft aussehen kann, die nicht mehr nach Kapital als letztem Kompass steuert, sondern nach positiver Netto-Wirkung.

Dieses Dokument dient als Website-Onlinefassung, Downloadgrundlage und Baustein der Fachbibliothek. Es ersetzt keine demokratische Entscheidung. Es macht Wirkpfade, Zielkonflikte, Datenbedarfe und Umsetzungsoptionen sichtbar.

Executive Summary

Rang 22 übersetzt die Wirkungsökonomie in Zukunftsbilder. Zukunftsbilder sind keine Vorhersagen, keine Utopien und keine Garantie. Sie beschreiben mögliche Zustände, wenn Wirkung tatsächlich in Alltag, Unternehmen, Staat, Kapital, Medien, Bildung, Wohnen, Gesundheit, globale Kooperation und demokratische Korrektur zurückgekoppelt wird. Der Rang bildet damit den Schlussteil der Portalarchitektur: Nach Daten, Recht, Kritik und Umsetzung geht es darum, wie eine Gesellschaft aussehen kann, die nicht mehr nach Kapital als letztem Kompass steuert, sondern nach positiver Netto-Wirkung.

Buchanker Teil XVIII

Der Buchanker liegt im Schlussteil der Arbeitsfassung 2026: Zukunftsbilder, Alltag 2035, Unternehmen 2035, Staat 2035, globale Ordnung 2050 und Schlussbild. Rang 22 übersetzt diesen Buchanker in Website, Download, Akademie, Toolkarten und politische Anschlussfähigkeit.

Alltag 2035

Alltag 2035 beschreibt keine perfekte Lebenswelt. Es beschreibt eine Welt, in der Menschen nicht permanent gegen falsche Preise, intransparente Produkte, zerstörerische Mobilität, unfaire Wohnbedingungen, unsichtbare Care-Leistung und manipulative Informationsräume ankämpfen müssen.

Unternehmen 2035

Unternehmen 2035 beschreibt Organisationen, die Wirkung in Strategie, Governance, Controlling, Risiko, Kapitalzugang, Versicherung, Lieferketten, Produktentwicklung, Marketing und Führung integrieren. Bericht wird Ausgabe einer Steuerungslogik, nicht Selbstzweck.

Staat 2035

Staat 2035 beschreibt öffentliche Institutionen, die Wirkungshaushalte, Beschaffung, Beteiligung, Rechtsschutz, Resilienz, digitale Datenräume und Prävention nutzen, ohne demokratische Konflikte durch Technik zu ersetzen.

Globale Ordnung 2050

Globale Ordnung 2050 ist keine Weltregierung. Sie ist eine Ordnung gemeinsamer Rückkopplung: Wirkungspartnerschaften, faire Lieferketten, Ressourcenfairness, Klimagerechtigkeit, globale Resilienz, kulturelle Übersetzung und gemeinsame Datenstandards.

Wirkungswohlstand

Wirkungswohlstand misst nicht nur Geldmenge, Konsumvolumen, Marktwert oder BIP. Er fragt, ob Lebensbedingungen tragfähiger werden. Weniger Krankheit, Angst, Reparaturbürokratie, Desinformation, Wegwerfware und riskante Kapitalflüsse können mehr Wohlstand bedeuten.

Grenzen

Die Wirkungsökonomie darf nicht alles messen wollen. Sie darf Menschen nicht nach privater Lebensführung klassifizieren. Sie braucht Rechtsschutz, Datenschutz, offene Methoden, demokratische Kontrolle und klare rote Linien.

Website- und Akademielogik

Rang 22 bildet die Brücke zwischen Buchabschluss und öffentlicher Wirkungsökonomie-Praxis: als Portal, Dossier, Akademie-Modul, Zukunftswerkstatt, Toolsammlung und Downloadbereich.

## SDG- und SDG+-Bezug
Rang 22 arbeitet mit den SDGs als internationalem Referenzrahmen und mit SDG+ als transparenter Erweiterung der Wirkungsökonomie. SDG+ ist keine UN-Kategorie, sondern ergänzt Demokratie, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

SDG 1 - Keine Armut

Wirkungswohlstand darf nicht auf Ausschluss beruhen. Armut wird als Zustandsveränderung in Teilhabe, Sicherheit, Gesundheit, Bildung, Wohnen und Selbstwirksamkeit betrachtet.

SDG 3 - Gesundheit und Wohlergehen

Zukunftsbilder prüfen, ob weniger Krankheit, weniger Angst, mehr Prävention, gute Pflege und bessere Lebensbedingungen entstehen.

SDG 4 - Hochwertige Bildung

Das Fach Zukunft, Wirkungskompetenz, Systemdenken und demokratische Medienkompetenz werden als Voraussetzungen einer lernfähigen Gesellschaft behandelt.

SDG 8 - Menschenwürdige Arbeit

Arbeit wird nicht nur als Erwerb, sondern als Wirkleistung gelesen. Automatisierung, Care, Bildung und sinnvolle Tätigkeiten brauchen neue Anerkennung.

SDG 9 - Industrie, Innovation und Infrastruktur

Innovation ist nicht Selbstzweck. Sie wird danach bewertet, ob sie Wirkung, Resilienz, Kreisläufe, Datenqualität und Zukunftsfähigkeit stärkt.

SDG 10 - Weniger Ungleichheiten

Zukunftsbilder müssen zeigen, ob Zugänge, Chancen, Schutz und Teilgabe breiter werden, statt neue Spaltungen zu erzeugen.

SDG 11 - Nachhaltige Städte und Gemeinden

Alltag 2035 beginnt in Quartieren: Wohnen, Mobilität, Energie, Gesundheit, Kultur und Beteiligung werden als lokale Wirkungsräume beschrieben.

SDG 12 - Nachhaltiger Konsum und Produktion

Ehrliche Preise, Produktwirkung, digitale Produktpässe und Verbraucherentlastung sind zentrale Bedingungen einer wirkungsfähigen Konsumordnung.

SDG 13 - Klimaschutz

Wohlstand ohne Zerstörung kann nicht auf Klimaschäden beruhen. Klimawirkung wird in Preise, Kapital, Infrastruktur und Alltag rückgekoppelt.

SDG 16 - Frieden, Gerechtigkeit und starke Institutionen

Demokratie, Rechtsschutz, Wahrheit, Vertrauen und Korrekturfähigkeit sind Kernbedingungen einer wirkungsfähigen Zukunft.

SDG 17 - Partnerschaften

Globale Ordnung 2050 wird als Ordnung der Kooperation, Übersetzung, Datenstandards und Wirkungspartnerschaften beschrieben, nicht als Weltregierung.

SDG+-Dimensionen

Demokratiequalität

Zukunftsfähigkeit braucht Verfahren, die Macht begrenzen, Konflikte offen halten und Korrektur ermöglichen.

Medienqualität

Öffentliche Wahrheit, Quellenklarheit und Schutz vor Desinformation sind Infrastruktur, nicht bloße Meinung.

Rechtsstaatlichkeit

Wirkungslenkung bleibt begrenzt durch Grundrechte, Datenschutz, Gerichte, Parlament und Rechtsschutz.

Diskursfähigkeit

Zukunftsbilder dürfen nicht als moralische Überwältigung erscheinen. Sie brauchen Streitfähigkeit und Übersetzung.

Institutionelles Vertrauen

Vertrauen entsteht, wenn Politik Zustände verbessert, Fehler korrigiert und Zielkonflikte offenlegt.

Gesellschaftlicher Zusammenhalt

Wohlstand entsteht nicht nur aus Kaufkraft, sondern aus Beziehung, Sicherheit, Zugehörigkeit und Teilgabe.

Digitale Selbstbestimmung

Datenräume und Wirkungsscanner dürfen keine Personenüberwachung werden. Sie dienen Systemkorrektur, nicht Kontrolle von Menschen.

## Politische Anschlussfähigkeit und Umsetzungsoptionen
Aufgabe der Politik

Politik muss Zukunftsbilder nicht als Wahlversprechen verkaufen, sondern als prüfbare Orientierungsräume gestalten. Sie schafft Rahmenbedingungen, in denen bessere Wirkung wahrscheinlicher wird: durch ehrliche Preise, Wirkungshaushalte, Rechtsstaat, Bildung, Datenqualität, Schutz vor Missbrauch, soziale Abfederung und demokratische Rückkopplung.

Politische Rahmenbedingungen

Notwendig sind rechtssichere Wirkungsdaten, öffentliche Wirkungshaushalte, faire Übergänge, Pilotkommunen, transparente Beschaffung, digitale Produktpässe, Datenschutz, unabhängige Prüfung, öffentliche Debatte und ein Schutz vor technokratischer Verengung.

Ausgestaltungsspielraum

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Parteien behalten Ausgestaltungsspielraum bei Steuern, Sozialpolitik, Infrastruktur, Bildung, Wirtschaft, Außenpolitik, Klimaschutz, Digitalisierung und Kultur. Entscheidend ist die überprüfbare Wirkung auf Mensch, Planet und Demokratie.

Zielkonflikte

Zukunftsbilder enthalten Zielkonflikte: kurzfristige Belastung und langfristige Stabilität, Datenschutz und Transparenz, Markt und Lenkung, Freiheit und Verantwortung, lokale Akzeptanz und globale Verantwortung, Investitionsschutz und Transformation, Geschwindigkeit und demokratische Legitimation.

Rollenverteilung

Bund, Länder, Kommunen, Unternehmen, Wissenschaft, Medien, Zivilgesellschaft und Bürger:innen tragen unterschiedliche Rollen. Der Staat setzt Regeln und schützt Rechte. Unternehmen organisieren Wirkung. Wissenschaft prüft. Medien schaffen öffentliche Orientierung. Bürger:innen werden nicht bewertet, sondern als Co-Autor:innen der Systemwirkung ernst genommen.

Übergang und Schutz

Der Übergang braucht Pilotierung, soziale Abfederung, Kaufkraftschutz, Datenschutz, Rechtsschutz, offene Methoden, Versionierung, klare rote Linien und Korrekturschleifen. Eine Wirkungsökonomie, die Freiheit schwächt, hätte ihren Maßstab verfehlt.

Evaluation und Korrektur

Zukunftsbilder müssen überprüft werden: Welche Zustände verbessern sich? Welche Nebenwirkungen entstehen? Welche Gruppen werden belastet? Wo kippen Anreize? Welche Daten fehlen? Welche Wirkungspfade waren falsch? Korrektur ist Pflicht, nicht Nachtrag.

Parteipolitische Anschlussfähigkeit

Konservative, liberale, sozialdemokratische, grüne, linke und kommunale Ansätze können die Wirkungslogik unterschiedlich übersetzen. Die Wirkungsökonomie bewertet nicht Ideologie, sondern Folgen.

Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Politische Bewertung, Rechtsschutz, parlamentarische Kontrolle, Gerichte und öffentliche Debatte bleiben unverzichtbar.

## Quellen und interne Bezugslinien
Natalie Weber: Die neue Ordnung des Wohlstands. Arbeitsfassung 2026. Teil XVIII - Schluss, Ausblick und zivilisatorische Perspektive.

Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

Natalie Weber: Grundlagenpapier Wirkungsökonomie WÖk, 2025.

Natalie Weber: Systemmodell der Wirkungsökonomie, 2025.

Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.

Interne Wirkungsökonomie-Arbeitsfassung: Kapitel 107 - Zukunftsbilder und Kapitel 108 - Schlussbild: Die neue Ordnung des Wohlstands.

## Onlinefassung und Download
Dieses Dokument ist für eine vollständige Onlinefassung und als PDF- sowie DOCX-Download vorgesehen. In der Website-Integration müssen beide Dateiformate sichtbar verlinkt werden.
