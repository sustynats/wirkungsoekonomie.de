WOeK Rang 22 - Zukunftsbilder, Wirkungswohlstand und zivilisatorische Perspektive
Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf für Website, Download und Akademie

Dieses Paket enthält PDF, DOCX, Markdown, HTML, JSON, Toolkarten und CodeX-Anweisung.
