# Toolkarten Rang 20

**Transformation, Übergänge und Implementierung**

Dokumenttyp: Toolkarten

Autorin: Natalie Weber

Referenz: Wirkungsökonomie

Version: 1.0

Stand: Mai 2026

Status: Langfassungsentwurf für Website, Akademie, Dossier und Download

Hinweis: Dieses Dokument ist für öffentliche Onlinefassungen und Downloads bestimmt. Es enthält keine internen Arbeitsanweisungen.

## Dokumentinformationen

Dokumenttyp: Toolkarten

Autorin: Natalie Weber

Referenz: Wirkungsökonomie

Version: 1.0

Stand: Mai 2026

Status: Langfassungsentwurf für Website, Akademie, Dossier und Download

Hinweis: Dieses Dokument ist für öffentliche Onlinefassungen und Downloads bestimmt. Es enthält keine internen Arbeitsanweisungen.

## Kurzfassung

Die Toolkarten machen Rang 20 praktisch nutzbar. Sie enthalten Beschreibung, Nutzen, Zielgruppe, Status und Linklogik für die Website.

## Toolkarten

- Transformationspfad-Check: Prüft, ob ein Vorhaben eine klare Phasenlogik, Zuständigkeit, Datenbasis, Schutzmechanismen und Skalierungskriterien besitzt. Zielgruppe: Politik, Verwaltung, Unternehmen, Kommunen. Status: Demo in Vorbereitung.

- Pilotdesign-Canvas: Hilft, Pilotfelder mit Hypothese, Messplan, Zielgruppen, Abbruchregeln, Rechtsschutz und Evaluation zu strukturieren. Zielgruppe: Kommunen, Ministerien, Projektteams. Status: Demo in Vorbereitung.

- Wirkungsreife-Score: Bewertet, ob ein Instrument methodisch, rechtlich, sozial, datenbezogen und verwaltungspraktisch bereit für Skalierung ist. Zielgruppe: Wirkungsrat, Verwaltung, Forschung. Status: Demo in Vorbereitung.

- Übergangsschutz-Rechner: Schätzt Belastungswirkungen auf Haushalte, KMU, Kommunen und Grundbedarfe und schlägt Schutzinstrumente vor. Zielgruppe: Politik, Sozialplanung, Kommunen. Status: Demo in Vorbereitung.

- Wirkungsfonds-Navigator: Ordnet Projekte nach Präventionswirkung, Transformationswirkung, Risiko, Kapitalbedarf und Rückflusslogik. Zielgruppe: Finanzsystem, Kommunen, Unternehmen. Status: Demo in Vorbereitung.

- Beschaffungs-Wirkungsscore: Übersetzt Wirkungsdaten in Vergabekriterien für Schulessen, Bau, Energie, IT, Mobilität und Verwaltung. Zielgruppe: Beschaffungsstellen, Kommunen, Länder. Status: Demo in Vorbereitung.

- Evaluations- und Korrekturmonitor: Verfolgt Hypothesen, Indikatoren, Ergebnisse, Nebenwirkungen, Einsprüche und Korrekturen von Piloten. Zielgruppe: Wirkungsrat, Wissenschaft, Öffentlichkeit. Status: Demo in Vorbereitung.

## Quellenrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands. Arbeitsfassung 2026. Teil XVI - Transformation, Übergänge und Implementierung, Kapitel 97 bis 100.

Weber, Natalie: Grundlagenpapier Wirkungsökonomie WÖk. 2025. Abschnitte zu Umsetzung, Transformation, Change-Management und Praxisbeispielen.

European Commission: Better regulation: guidelines and toolbox. https://commission.europa.eu/law/law-making-process/better-regulation/better-regulation-guidelines-and-toolbox_en

OECD: Recommendation of the Council on Regulatory Policy and Governance. OECD/LEGAL/0390. https://legalinstruments.oecd.org/en/instruments/OECD-LEGAL-0390

OECD: Regulatory Sandbox Toolkit. 2025. https://www.oecd.org/en/publications/regulatory-sandbox-toolkit_de36fa62-en.html

European Commission: Use of regulatory sandboxes in EU Member States. 2026. https://op.europa.eu/en/publication-detail/-/publication/6942cc0e-3d27-11f1-814f-01aa75ed71a1/language-en

European Commission: Public Procurement of Innovation. https://single-market-economy.ec.europa.eu/single-market/public-procurement/strategic-procurement/public-procurement-innovation_en

OECD: Strategic Public Procurement. https://www.oecd.org/en/topics/strategic-public-procurement.html

OECD: Implementation Toolkit for the OECD Recommendation on Public Policy Evaluation. 2025. https://www.oecd.org/en/publications/implementation-toolkit-for-the-oecd-recommendation-on-public-policy-evaluation_77faa4fe-en.html

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development. https://sdgs.un.org/2030agenda

## Glossarlinks

- Wirkung: Tatsächliche Veränderung von Zuständen. Wirkung kann positiv, negativ oder neutral sein.

- Positive Netto-Wirkung: Zielgröße der Wirkungsökonomie: tragfähige Wirkung für Mensch, Planet und Demokratie unter Berücksichtigung negativer Effekte und roter Linien.

- Pilotierung: Zeitlich, sachlich und räumlich begrenzte Erprobung einer Wirkungslogik mit Messplan, Rechtsschutz, Evaluation und Korrektur.

- Reallabor: Geschützter Umsetzungsraum, in dem Regeln, Daten, Prozesse und Governance in realen Bedingungen geprüft werden.

- Wirkungsreife: Grad, zu dem ein Instrument methodisch, rechtlich, organisatorisch, sozial und datenbezogen bereit für Skalierung ist.

- Wirkungs-Konversion: Glaubwürdige Überführung von Altkapital, Geschäftsmodellen und Infrastrukturen von Verlustleistung in Wirkleistung.

- Reverse Merit Order: Engpasslogik: kritische negative Wirkungen dürfen nicht durch positive Werte überdeckt werden.

- Wirkungsrat: Unabhängige Sicherungsinstitution für Indikatoren, Benchmarks, Versionierung, Evaluation und Missbrauchsschutz.

- SDG+: WÖk-Erweiterung für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
