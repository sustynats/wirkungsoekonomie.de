# Detailkonzept Evaluation, Rechtsschutz und Lernschleifen

**Wie die Wirkungsökonomie fehlbar, korrigierbar und demokratisch legitim bleibt**

Dokumenttyp: Detailkonzept

Autorin: Natalie Weber

Referenz: Wirkungsökonomie

Version: 1.0

Stand: Mai 2026

Status: Langfassungsentwurf für Website, Akademie, Dossier und Download

Hinweis: Dieses Dokument ist für öffentliche Onlinefassungen und Downloads bestimmt. Es enthält keine internen Arbeitsanweisungen.

## Dokumentinformationen

Dokumenttyp: Detailkonzept

Autorin: Natalie Weber

Referenz: Wirkungsökonomie

Version: 1.0

Stand: Mai 2026

Status: Langfassungsentwurf für Website, Akademie, Dossier und Download

Hinweis: Dieses Dokument ist für öffentliche Onlinefassungen und Downloads bestimmt. Es enthält keine internen Arbeitsanweisungen.

## Kurzfassung

Detailkonzept Evaluation, Rechtsschutz und Lernschleifen vertieft einen zentralen Umsetzungsbaustein von Rang 20 und ist als Langfassungsentwurf für Website, Download und politische Anschlussfähigkeit angelegt.

## Datenquellen und Nachweisführung

Für jedes Umsetzungsinstrument müssen Datenquellen vor Beginn geklärt werden. Dazu gehören vorhandene Verwaltungsdaten, öffentliche Statistik, Unternehmensdaten, CSRD- und ESRS-Daten, Produktpässe, Beschaffungsdaten, Haushaltsdaten, Sozialraumdaten, Risikodaten aus Versicherungen und Kapitaldaten. Die Wirkungsökonomie darf keine neue Berichtslast erzeugen, wenn vorhandene Daten mit besseren Standards genutzt werden können.

Die Nachweisführung unterscheidet zwischen gemessenen Daten, geprüften Daten, plausibilisierten Daten, Schätzungen und Datenlücken. Jede Datenquelle erhält einen Prüfstatus. Eine Wirkungsaussage ohne Datenqualitätsklasse ist nicht hinreichend belastbar. Das schützt vor Wirkungssimulation und vor dem Missbrauch einzelner Kennzahlen.

Für die Website-Fassung bedeutet das: Jede Onlinefassung braucht einen Datenblock. Dort werden mögliche Datenquellen, Messgrenzen, Unsicherheiten und Anschlussstellen transparent benannt. So bleibt das Portal fachlich nutzbar und politisch anschlussfähig.

## Berechnungslogik und Bewertungsmodell

Die Bewertungslogik für Rang 20 arbeitet nicht mit einer einfachen Summe guter Absichten. Ein Instrument gilt nur dann als umsetzungsreif, wenn mehrere Mindestbedingungen gleichzeitig erfüllt sind: Datenqualität, Rechtsklarheit, soziale Verträglichkeit, Verwaltungsfähigkeit, demokratische Kontrolle und Skalierbarkeit. Ein sehr guter Klimanutzen kann fehlenden Rechtsschutz nicht überdecken.

Der zentrale Operator ist eine Engpasslogik. Wenn ein Umsetzungsfeld in einer kritischen Dimension unter Mindeststandard fällt, wird die Skalierung gebremst. Diese Logik ist wichtig, weil Umsetzungsfehler sonst als Kollateralschäden akzeptiert würden. Die Wirkungsökonomie muss zeigen, dass sie aus Fehlern lernt, bevor Fehler systemisch werden.

Ein mögliches Raster lautet: Datenreife 0 bis 3, Rechtsklarheit 0 bis 3, Sozialschutz 0 bis 3, Verwaltungsfähigkeit 0 bis 3, Evaluationsfähigkeit 0 bis 3 und Skalierungsfähigkeit 0 bis 3. Der niedrigste Wert markiert den Engpass. Erst wenn alle Mindestwerte erreicht sind, darf ein Pilot in die nächste Stufe.

## Governance und institutionelle Verantwortung

Umsetzung braucht eindeutige Rollen. Der Bund kann Rechtsrahmen, Register, Standards und Förderarchitektur schaffen. Länder verantworten Vollzug, Bildung, Verwaltung und Fachaufsicht. Kommunen übersetzen Wirkung in reale Räume. Unternehmen liefern Produkt- und Prozessdaten. Wissenschaft prüft Methoden. Zivilgesellschaft und Betroffene markieren blinde Flecken. Medien sichern öffentliche Verständlichkeit.

Der Wirkungsrat ist dabei keine Regierung und kein Ersatzparlament. Seine Aufgabe ist methodische Sicherung: WÖk-IDs, Benchmarks, Scorecards, Versionierung, Datenqualität, Konsultation und Missbrauchsschutz. Politische Prioritäten bleiben demokratisch zu entscheiden.

Governance bedeutet auch Interessenkonflikte sichtbar zu machen. Wer von alten Fehlanreizen profitiert, wird versuchen, Indikatoren zu verwässern oder Übergänge endlos zu verlängern. Wer schnelle Veränderung will, kann Schutzmechanismen unterschätzen. Rang 20 muss beide Risiken ausbalancieren.

## Umsetzungsbeispiel und Wirkpfad

Ein typischer Wirkpfad beginnt mit einer Ausgangslage: ein Problem ist bekannt, aber die bisherige Steuerung reagiert nur mit Einzelmaßnahmen. Dann wird eine Hypothese formuliert: Wenn Wirkung sichtbar und in Entscheidungskriterien übersetzt wird, verändert sich Verhalten. Anschließend werden Daten, Grenzen, Zielgruppen und Schutzmechanismen definiert.

In der Pilotphase wird die Maßnahme nicht nur auf Zielerreichung geprüft. Gemessen werden auch Nebenwirkungen: Bürokratieaufwand, Verteilungswirkung, Akzeptanz, rechtliche Streitfälle, Datenqualität, Manipulationsrisiken und Auswirkungen auf kleine Akteure. Erst danach kann entschieden werden, ob Skalierung, Korrektur oder Abbruch sinnvoll ist.

Der Wert eines Piloten liegt also nicht darin, dass er sofort perfekt funktioniert. Sein Wert liegt darin, dass er sichtbar macht, welche Annahmen tragen und welche nicht. Damit wird Politik nicht langsamer, sondern lernfähiger.

## Zielkonflikte und Schutzmechanismen

Jede Transformation erzeugt Zielkonflikte. Schnelle Lenkung kann soziale Härten erzeugen. Breite Beteiligung kann Prozesse verlangsamen. Hohe Datenanforderungen können Qualität sichern, aber kleine Akteure überfordern. Starke Standardisierung kann Vergleichbarkeit schaffen, aber lokale Besonderheiten verdrängen.

Die Wirkungsökonomie löst diese Zielkonflikte nicht durch Behauptung auf. Sie macht sie sichtbar und legt Schutzmechanismen fest: Übergangsfristen, Schwellenwerte, einfache Verfahren, Härtefallfonds, Open-Source-Tools, Beratung, öffentliche Konsultation und unabhängige Prüfung.

Besonders wichtig ist der Schutz vor Technokratie. Daten dürfen demokratische Entscheidung nicht ersetzen. Sie müssen Folgen sichtbar machen, Unsicherheit markieren und Korrektur ermöglichen. Politische Verantwortung bleibt politisch.

## Anschluss an Website, Akademie und Downloads

Jedes Detailkonzept muss online vollständig lesbar sein. Ein PDF allein reicht nicht. Die Website braucht eine klare Navigation, ein mobil funktionierendes Inhaltsverzeichnis, Downloadbuttons für PDF und DOCX, eine Druckfunktion, Quellen, Glossarlinks und Querverlinkungen zu angrenzenden Portalen.

Für die Akademie kann das Dokument in Lernmodule zerlegt werden: Einführung, Begriffe, Datenlogik, Umsetzungsbeispiel, Übung zur Pilotplanung, Reflexion zu Zielkonflikten und Checkliste für politische Anschlussfähigkeit. So wird Rang 20 nicht nur dokumentiert, sondern vermittelbar.

Für CodeX und Website-Integration gilt: keine internen Anweisungen im öffentlichen Frontend, keine Platzhalter, keine toten Downloadlinks, keine Tabellen ohne mobile Darstellung und keine Detailkonzepte, die nur aus kurzen Überblickstexten bestehen.

## Wirkungslogik

Wirkung ist neutral und relational. Sie beschreibt tatsächliche Zustandsveränderungen und ist nicht mit Absicht, Image, Bericht oder Output gleichzusetzen. Bewertet wird am Referenzrahmen SDGs, Agenda 2030 und SDG+. Ziel ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Rang 20 wendet diese Begriffslogik auf Umsetzung an: Nicht jede schnelle Maßnahme ist gute Transformation, und nicht jede Verzögerung ist Vorsicht. Entscheidend ist, ob Übergänge robuste, gerechte und lernfähige Zustände erzeugen.

## Warum Rang 20 notwendig ist

Die vorherigen Portale zeigen, welche Felder der Wirkungsökonomie in Wirtschaft, Staat, Kapital, Produkten, Datenräumen, Medien, Wissenschaft, Sicherheit und globaler Ordnung relevant sind. Rang 20 übersetzt diese Architektur in einen Umsetzungspfad. Ohne solche Übergangslogik bliebe die Wirkungsökonomie entweder zu abstrakt oder politisch riskant: Sie könnte als Überforderung, Bürokratie, Utopie oder Kontrollsystem missverstanden werden. Eine gute Implementierung beantwortet genau diese Einwände durch Pilotierung, Rechtsschutz, Datenqualität, Beteiligung, soziale Abfederung und schrittweise Skalierung.

## Leitprinzipien der Implementierung

Die Umsetzung folgt acht Leitprinzipien: erstens keine Schockeinführung, zweitens Pilotierung vor Skalierung, drittens vorhandene Daten nutzen statt neue Berichtslasten erzeugen, viertens Grundbedarfe schützen, fünftens KMU und Kommunen entlasten, sechstens Wirkung öffentlich evaluieren, siebtens Rechtsschutz und Widerspruch ermöglichen, achtens politische Entscheidungen demokratisch halten. Digitalisierung, KI und Datenräume dienen dabei der Rückkopplung, nicht der Überwachung von Personen.

## Problemstellung

Ein Wirkungsmodell, das nicht korrigierbar ist, wird gefährlich. Es könnte Fehlbewertungen, Lobbyeinfluss, Datenfehler oder soziale Nebenwirkungen verstetigen.

Für die Umsetzung bedeutet das: Daten, Zuständigkeiten, Verfahren, Schutzmechanismen und Evaluation müssen von Anfang an zusammen gedacht werden. Ein Instrument ist erst wirkungsreif, wenn es methodisch tragfähig, rechtlich begrenzt, sozial anschlussfähig und praktisch verwaltbar ist.

## Evaluation

Evaluation prüft Zielerreichung, Nebenwirkungen, Datenqualität, Verteilungseffekte, Verwaltungsaufwand, Akzeptanz, Grundrechtsschutz, Kosten und Skalierbarkeit.

Für die Umsetzung bedeutet das: Daten, Zuständigkeiten, Verfahren, Schutzmechanismen und Evaluation müssen von Anfang an zusammen gedacht werden. Ein Instrument ist erst wirkungsreif, wenn es methodisch tragfähig, rechtlich begrenzt, sozial anschlussfähig und praktisch verwaltbar ist.

## Rechtsschutz

Betroffene Akteure brauchen Einsicht, Begründung, Widerspruch, Prüfung und unabhängige Instanzen. Wirkung darf nicht zur Blackbox werden.

Für die Umsetzung bedeutet das: Daten, Zuständigkeiten, Verfahren, Schutzmechanismen und Evaluation müssen von Anfang an zusammen gedacht werden. Ein Instrument ist erst wirkungsreif, wenn es methodisch tragfähig, rechtlich begrenzt, sozial anschlussfähig und praktisch verwaltbar ist.

## Lernschleifen

Jeder Pilot folgt einem Zyklus: Hypothese, Datenplan, Umsetzung, Messung, öffentliche Auswertung, Korrektur, erneute Prüfung und Entscheidung über Skalierung.

Für die Umsetzung bedeutet das: Daten, Zuständigkeiten, Verfahren, Schutzmechanismen und Evaluation müssen von Anfang an zusammen gedacht werden. Ein Instrument ist erst wirkungsreif, wenn es methodisch tragfähig, rechtlich begrenzt, sozial anschlussfähig und praktisch verwaltbar ist.

## Wirkungsrat

Der Wirkungsrat sichert Indikatoren, Benchmarks, Versionierung, Konsultation und Schutz vor Vereinnahmung. Er ersetzt nicht Politik, sondern schützt die Methode.

Für die Umsetzung bedeutet das: Daten, Zuständigkeiten, Verfahren, Schutzmechanismen und Evaluation müssen von Anfang an zusammen gedacht werden. Ein Instrument ist erst wirkungsreif, wenn es methodisch tragfähig, rechtlich begrenzt, sozial anschlussfähig und praktisch verwaltbar ist.

## Beispiel

Ein Pilot zur Produktsteuer zeigt unerwartet hohe Belastungen für kleine Händler. Die Evaluation kann Datenpflichten vereinfachen, Schwellenwerte anpassen oder Übergangsfristen verlängern.

Für die Umsetzung bedeutet das: Daten, Zuständigkeiten, Verfahren, Schutzmechanismen und Evaluation müssen von Anfang an zusammen gedacht werden. Ein Instrument ist erst wirkungsreif, wenn es methodisch tragfähig, rechtlich begrenzt, sozial anschlussfähig und praktisch verwaltbar ist.

## Prinzip

Irrtum ist kein Scheitern, wenn er sichtbar, öffentlich ausgewertet und korrigiert wird. Genau darin liegt die Lernfähigkeit der Wirkungsökonomie.

Für die Umsetzung bedeutet das: Daten, Zuständigkeiten, Verfahren, Schutzmechanismen und Evaluation müssen von Anfang an zusammen gedacht werden. Ein Instrument ist erst wirkungsreif, wenn es methodisch tragfähig, rechtlich begrenzt, sozial anschlussfähig und praktisch verwaltbar ist.

## Umsetzungscheck

| Prüffrage | Anforderung |
| --- | --- |
| Daten | Welche bestehenden Daten können genutzt werden? |
| Recht | Welche Rechtsgrundlage und welcher Rechtsschutz sind nötig? |
| Soziales | Wer könnte belastet werden und wie wird geschützt? |
| Verwaltung | Wer führt aus und welche Vereinfachung ist nötig? |
| Evaluation | Wie wird gelernt, korrigiert und skaliert? |

## SDG- und SDG+-Bezug

- SDG 4 - Hochwertige Bildung: Umsetzung braucht Wirkungskompetenz, Verwaltungslernen, Datenkompetenz und Bürger:innenbildung.

- SDG 8 - Menschenwürdige Arbeit und wirtschaftliche Entwicklung: Transformationspfade müssen Arbeit, Qualifizierung, faire Übergänge und Unternehmensfähigkeit sichern.

- SDG 9 - Industrie, Innovation und Infrastruktur: Pilotierung, Reallabore, Datenräume, DPP, Beschaffung und Innovationspfade sind Infrastrukturfragen.

- SDG 10 - Weniger Ungleichheiten: Übergänge müssen verhindern, dass positive Wirkung nur zahlungskräftigen Gruppen zugänglich bleibt.

- SDG 11 - Nachhaltige Städte und Gemeinden: Kommunen sind zentrale Piloträume für Wirkungshaushalte, Beschaffung, Sozialraumprofile und Bürgerbeteiligung.

- SDG 12 - Nachhaltiger Konsum und Produktion: Produktpässe, Beschaffung, Lieferketten und Wirkungspreise übersetzen Produktionswirkungen in Entscheidungen.

- SDG 13 - Klimaschutz: Transformation muss Emissionspfade, Anpassung, Resilienz und soziale Abfederung verbinden.

- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsschutz, Transparenz, Evaluation und demokratische Kontrolle sichern Legitimität.

- SDG 17 - Partnerschaften: Wirkungsökonomie wird nur durch Kooperation zwischen Staat, Wirtschaft, Wissenschaft, Kommunen und Zivilgesellschaft umsetzbar.

- SDG+ - Demokratie, Medienqualität und digitale Selbstbestimmung: SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Politische Anschlussfähigkeit und Umsetzungsoptionen

- Aufgabe der Politik: Politik muss nicht jede Einzelentscheidung vorgeben. Sie muss Schutzgüter definieren, Datenqualität sichern, Piloträume ermöglichen, soziale Übergänge abfedern, Rechtsschutz garantieren und die Rückkopplung der Wirkung in Haushalte, Beschaffung, Förderung, Steuern, Kapitalzugang und öffentliche Berichte organisieren.

- Politische Rahmenbedingungen: Erforderlich sind gesetzliche Experimentierklauseln, transparente Bewertungsmethoden, Datenschutz, öffentliche Konsultationen, kommunale Finanzierung, unabhängige Evaluation, Wirkungsrat, Widerspruchsrechte und klare Grenzen gegen Personenbewertung oder Social-Credit-Logik.

- Ausgestaltungsspielraum: Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Parteien behalten Spielraum bei Tempo, Instrumenten, Sektorprioritäten, Fördertöpfen, Steuerpfaden, Bürgerbeteiligung und europäischer Einbettung. Entscheidend ist die überprüfbare Wirkung auf Mensch, Planet und Demokratie.

- Zielkonflikte: Umsetzung erzeugt Konflikte zwischen Schnelligkeit und Rechtssicherheit, Innovation und Missbrauchsschutz, Entlastung und Lenkungswirkung, Datenbedarf und Datenschutz, europäischen Standards und lokaler Anpassung, Investitionssicherheit und Abbau destruktiver Geschäftsmodelle.

- Rollenverteilung: Bund, Länder, Kommunen, Wirtschaft, Wissenschaft, Zivilgesellschaft, Medien, Kapitalmärkte und Bürger:innen übernehmen unterschiedliche Rollen. Keine Ebene darf die Umsetzung allein dominieren. Wirksame Transformation braucht koordinierte Zuständigkeiten und nachvollziehbare Verantwortlichkeit.

- Übergang und Schutz: Positive Wirkung darf nicht dauerhaft Luxus bleiben. Grundbedarfe, KMU, Kommunen, verletzliche Gruppen und kleine Lieferanten benötigen Schutz, Übergangsfristen, Beratung, Datenadapter, Finanzierung und einfache Verfahren.

- Evaluation und Korrektur: Jeder Pilot braucht Hypothesen, Messplan, Datenqualitätsklassen, Abbruchregeln, Korrekturschleifen, öffentliche Auswertung und Skalierungskriterien. Fehler sind nicht das Ende des Modells, sondern Material des Lernens.

- Schutz vor Technokratie: Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertungen müssen öffentlich begründet, anfechtbar, versioniert, unabhängig geprüft und politisch diskutierbar sein.

## Quellenrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands. Arbeitsfassung 2026. Teil XVI - Transformation, Übergänge und Implementierung, Kapitel 97 bis 100.

Weber, Natalie: Grundlagenpapier Wirkungsökonomie WÖk. 2025. Abschnitte zu Umsetzung, Transformation, Change-Management und Praxisbeispielen.

European Commission: Better regulation: guidelines and toolbox. https://commission.europa.eu/law/law-making-process/better-regulation/better-regulation-guidelines-and-toolbox_en

OECD: Recommendation of the Council on Regulatory Policy and Governance. OECD/LEGAL/0390. https://legalinstruments.oecd.org/en/instruments/OECD-LEGAL-0390

OECD: Regulatory Sandbox Toolkit. 2025. https://www.oecd.org/en/publications/regulatory-sandbox-toolkit_de36fa62-en.html

European Commission: Use of regulatory sandboxes in EU Member States. 2026. https://op.europa.eu/en/publication-detail/-/publication/6942cc0e-3d27-11f1-814f-01aa75ed71a1/language-en

European Commission: Public Procurement of Innovation. https://single-market-economy.ec.europa.eu/single-market/public-procurement/strategic-procurement/public-procurement-innovation_en

OECD: Strategic Public Procurement. https://www.oecd.org/en/topics/strategic-public-procurement.html

OECD: Implementation Toolkit for the OECD Recommendation on Public Policy Evaluation. 2025. https://www.oecd.org/en/publications/implementation-toolkit-for-the-oecd-recommendation-on-public-policy-evaluation_77faa4fe-en.html

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development. https://sdgs.un.org/2030agenda

## Glossarlinks

- Wirkung: Tatsächliche Veränderung von Zuständen. Wirkung kann positiv, negativ oder neutral sein.

- Positive Netto-Wirkung: Zielgröße der Wirkungsökonomie: tragfähige Wirkung für Mensch, Planet und Demokratie unter Berücksichtigung negativer Effekte und roter Linien.

- Pilotierung: Zeitlich, sachlich und räumlich begrenzte Erprobung einer Wirkungslogik mit Messplan, Rechtsschutz, Evaluation und Korrektur.

- Reallabor: Geschützter Umsetzungsraum, in dem Regeln, Daten, Prozesse und Governance in realen Bedingungen geprüft werden.

- Wirkungsreife: Grad, zu dem ein Instrument methodisch, rechtlich, organisatorisch, sozial und datenbezogen bereit für Skalierung ist.

- Wirkungs-Konversion: Glaubwürdige Überführung von Altkapital, Geschäftsmodellen und Infrastrukturen von Verlustleistung in Wirkleistung.

- Reverse Merit Order: Engpasslogik: kritische negative Wirkungen dürfen nicht durch positive Werte überdeckt werden.

- Wirkungsrat: Unabhängige Sicherungsinstitution für Indikatoren, Benchmarks, Versionierung, Evaluation und Missbrauchsschutz.

- SDG+: WÖk-Erweiterung für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
