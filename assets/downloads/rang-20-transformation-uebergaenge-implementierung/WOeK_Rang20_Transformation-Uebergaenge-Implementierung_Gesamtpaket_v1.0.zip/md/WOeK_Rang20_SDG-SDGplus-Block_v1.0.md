# SDG-/SDG+-Block Rang 20

**Transformation, Übergänge und Implementierung**

Dokumenttyp: SDG-/SDG+-Block

Autorin: Natalie Weber

Referenz: Wirkungsökonomie

Version: 1.0

Stand: Mai 2026

Status: Langfassungsentwurf für Website, Akademie, Dossier und Download

Hinweis: Dieses Dokument ist für öffentliche Onlinefassungen und Downloads bestimmt. Es enthält keine internen Arbeitsanweisungen.

## Dokumentinformationen

Dokumenttyp: SDG-/SDG+-Block

Autorin: Natalie Weber

Referenz: Wirkungsökonomie

Version: 1.0

Stand: Mai 2026

Status: Langfassungsentwurf für Website, Akademie, Dossier und Download

Hinweis: Dieses Dokument ist für öffentliche Onlinefassungen und Downloads bestimmt. Es enthält keine internen Arbeitsanweisungen.

## Kurzfassung

Der SDG-/SDG+-Block ordnet Rang 20 in den Referenzrahmen der Wirkungsökonomie ein.

## SDG- und SDG+-Bezug

- SDG 4 - Hochwertige Bildung: Umsetzung braucht Wirkungskompetenz, Verwaltungslernen, Datenkompetenz und Bürger:innenbildung.

- SDG 8 - Menschenwürdige Arbeit und wirtschaftliche Entwicklung: Transformationspfade müssen Arbeit, Qualifizierung, faire Übergänge und Unternehmensfähigkeit sichern.

- SDG 9 - Industrie, Innovation und Infrastruktur: Pilotierung, Reallabore, Datenräume, DPP, Beschaffung und Innovationspfade sind Infrastrukturfragen.

- SDG 10 - Weniger Ungleichheiten: Übergänge müssen verhindern, dass positive Wirkung nur zahlungskräftigen Gruppen zugänglich bleibt.

- SDG 11 - Nachhaltige Städte und Gemeinden: Kommunen sind zentrale Piloträume für Wirkungshaushalte, Beschaffung, Sozialraumprofile und Bürgerbeteiligung.

- SDG 12 - Nachhaltiger Konsum und Produktion: Produktpässe, Beschaffung, Lieferketten und Wirkungspreise übersetzen Produktionswirkungen in Entscheidungen.

- SDG 13 - Klimaschutz: Transformation muss Emissionspfade, Anpassung, Resilienz und soziale Abfederung verbinden.

- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsschutz, Transparenz, Evaluation und demokratische Kontrolle sichern Legitimität.

- SDG 17 - Partnerschaften: Wirkungsökonomie wird nur durch Kooperation zwischen Staat, Wirtschaft, Wissenschaft, Kommunen und Zivilgesellschaft umsetzbar.

- SDG+ - Demokratie, Medienqualität und digitale Selbstbestimmung: SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## SDG+ Klarstellung

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsökonomie für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung. Rang 20 braucht SDG+, weil Umsetzung ohne demokratische Kontrolle und institutionelles Vertrauen nicht legitim ist.
