# Rang 20 - Transformation, Übergänge und Implementierung

**Portalstartseite der Wirkungsökonomie**

Dokumenttyp: Portalstartseite

Autorin: Natalie Weber

Referenz: Wirkungsökonomie

Version: 1.0

Stand: Mai 2026

Status: Langfassungsentwurf für Website, Akademie, Dossier und Download

Hinweis: Dieses Dokument ist für öffentliche Onlinefassungen und Downloads bestimmt. Es enthält keine internen Arbeitsanweisungen.

## Dokumentinformationen

Dokumenttyp: Portalstartseite

Autorin: Natalie Weber

Referenz: Wirkungsökonomie

Version: 1.0

Stand: Mai 2026

Status: Langfassungsentwurf für Website, Akademie, Dossier und Download

Hinweis: Dieses Dokument ist für öffentliche Onlinefassungen und Downloads bestimmt. Es enthält keine internen Arbeitsanweisungen.

## Kurzfassung

Rang 20 bildet die praktische Umsetzungsarchitektur der Wirkungsökonomie. Der Portalbereich zeigt, wie Pilotierung, Wirkungsdaten, öffentliche Beschaffung, kommunale Reallabore, Unternehmenspfade, Wirkungsfonds, Evaluation und demokratische Kontrolle zusammenwirken.

## Wirkungslogik

Wirkung ist neutral und relational. Sie beschreibt tatsächliche Zustandsveränderungen und ist nicht mit Absicht, Image, Bericht oder Output gleichzusetzen. Bewertet wird am Referenzrahmen SDGs, Agenda 2030 und SDG+. Ziel ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Rang 20 wendet diese Begriffslogik auf Umsetzung an: Nicht jede schnelle Maßnahme ist gute Transformation, und nicht jede Verzögerung ist Vorsicht. Entscheidend ist, ob Übergänge robuste, gerechte und lernfähige Zustände erzeugen.

## Warum Rang 20 notwendig ist

Die vorherigen Portale zeigen, welche Felder der Wirkungsökonomie in Wirtschaft, Staat, Kapital, Produkten, Datenräumen, Medien, Wissenschaft, Sicherheit und globaler Ordnung relevant sind. Rang 20 übersetzt diese Architektur in einen Umsetzungspfad. Ohne solche Übergangslogik bliebe die Wirkungsökonomie entweder zu abstrakt oder politisch riskant: Sie könnte als Überforderung, Bürokratie, Utopie oder Kontrollsystem missverstanden werden. Eine gute Implementierung beantwortet genau diese Einwände durch Pilotierung, Rechtsschutz, Datenqualität, Beteiligung, soziale Abfederung und schrittweise Skalierung.

## Leitprinzipien der Implementierung

Die Umsetzung folgt acht Leitprinzipien: erstens keine Schockeinführung, zweitens Pilotierung vor Skalierung, drittens vorhandene Daten nutzen statt neue Berichtslasten erzeugen, viertens Grundbedarfe schützen, fünftens KMU und Kommunen entlasten, sechstens Wirkung öffentlich evaluieren, siebtens Rechtsschutz und Widerspruch ermöglichen, achtens politische Entscheidungen demokratisch halten. Digitalisierung, KI und Datenräume dienen dabei der Rückkopplung, nicht der Überwachung von Personen.

## Portalidee

Die Wirkungsökonomie beschreibt keinen Schockwechsel und kein starres Endbild. Sie beschreibt einen lernenden Steuerungswechsel: Wirkung wird sichtbar, bewertet, rückgekoppelt und in Entscheidungen übersetzt. Genau deshalb braucht die Umsetzung eine eigene Architektur. Transformation ist hier nicht die euphorische Ankündigung eines Zielzustands, sondern die belastbare Organisation von Übergängen, Pilotfeldern, Korrekturschleifen, Rechtsschutz, sozialer Abfederung und demokratischer Kontrolle. Rang 20 bündelt diese Umsetzungslogik. Er schließt an alle vorherigen Portale an und fragt: Wie beginnt die Wirkungsökonomie praktisch, ohne Kommunen, Unternehmen, Bürger:innen, Verwaltung, Kapitalmärkte oder kleine Lieferanten zu überfordern? Die Antwort lautet: mit Pilotierung, Reihenfolge, Lernschleifen, verhältnismäßigen Verfahren, Wirkungshaushalten, Datenstandards, öffentlicher Beschaffung, Brückenfinanzierung, Wirkungsfonds und einer politischen Dramaturgie, die Konflikte nicht verdrängt, sondern prüfbar und bearbeitbar macht.

Die Portalstartseite führt Besucher:innen nicht in ein weiteres Theoriekapitel, sondern in den Übergang: vom Denken in Wirkung zur praktischen Umsetzung. Sie erklärt, warum Transformation mit kleinen, überprüfbaren Schritten beginnt und dennoch auf systemische Veränderung zielt.

## Unterbereiche des Portals

| Unterbereich | Funktion |
| --- | --- |
| Umsetzungspfad | Phasen, Reihenfolge und Transformationsdramaturgie |
| Pilotkommunen | Kommunale Wirkungsräume, Wirkungshaushalte und Bürger:innenbeteiligung |
| Produkte und Beschaffung | Öffentliche Nachfrage als früher Markt für Wirkungsprodukte |
| Unternehmen | Beschaffung, Produktportfolio, ERM, Managementboni und Wirkungskosten |
| Wirkungsfonds | Brückenfinanzierung, Prävention und Transformationskapital |
| Daten und Versionierung | WÖk-IDs, Datenqualitätsklassen, Register und Korrekturschleifen |
| Reallabore | Regulatorische Sandboxes und Experimentierklauseln |
| Evaluation und Rechtsschutz | Lernschleifen, Abbruchregeln, Widerspruch und demokratische Kontrolle |

## Download- und Online-Logik

Alle Dokumente dieses Portals werden als Online-Volltext, PDF, DOCX und Markdown bereitgestellt. Die Website darf nicht nur Downloads verlinken. Jedes Dossier braucht eine vollständige, mobil lesbare Onlinefassung mit Inhaltsverzeichnis, Druckfunktion, Quellen, Glossarlinks und Downloadbereich.

## SDG- und SDG+-Bezug

- SDG 4 - Hochwertige Bildung: Umsetzung braucht Wirkungskompetenz, Verwaltungslernen, Datenkompetenz und Bürger:innenbildung.

- SDG 8 - Menschenwürdige Arbeit und wirtschaftliche Entwicklung: Transformationspfade müssen Arbeit, Qualifizierung, faire Übergänge und Unternehmensfähigkeit sichern.

- SDG 9 - Industrie, Innovation und Infrastruktur: Pilotierung, Reallabore, Datenräume, DPP, Beschaffung und Innovationspfade sind Infrastrukturfragen.

- SDG 10 - Weniger Ungleichheiten: Übergänge müssen verhindern, dass positive Wirkung nur zahlungskräftigen Gruppen zugänglich bleibt.

- SDG 11 - Nachhaltige Städte und Gemeinden: Kommunen sind zentrale Piloträume für Wirkungshaushalte, Beschaffung, Sozialraumprofile und Bürgerbeteiligung.

- SDG 12 - Nachhaltiger Konsum und Produktion: Produktpässe, Beschaffung, Lieferketten und Wirkungspreise übersetzen Produktionswirkungen in Entscheidungen.

- SDG 13 - Klimaschutz: Transformation muss Emissionspfade, Anpassung, Resilienz und soziale Abfederung verbinden.

- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsschutz, Transparenz, Evaluation und demokratische Kontrolle sichern Legitimität.

- SDG 17 - Partnerschaften: Wirkungsökonomie wird nur durch Kooperation zwischen Staat, Wirtschaft, Wissenschaft, Kommunen und Zivilgesellschaft umsetzbar.

- SDG+ - Demokratie, Medienqualität und digitale Selbstbestimmung: SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Politische Anschlussfähigkeit und Umsetzungsoptionen

- Aufgabe der Politik: Politik muss nicht jede Einzelentscheidung vorgeben. Sie muss Schutzgüter definieren, Datenqualität sichern, Piloträume ermöglichen, soziale Übergänge abfedern, Rechtsschutz garantieren und die Rückkopplung der Wirkung in Haushalte, Beschaffung, Förderung, Steuern, Kapitalzugang und öffentliche Berichte organisieren.

- Politische Rahmenbedingungen: Erforderlich sind gesetzliche Experimentierklauseln, transparente Bewertungsmethoden, Datenschutz, öffentliche Konsultationen, kommunale Finanzierung, unabhängige Evaluation, Wirkungsrat, Widerspruchsrechte und klare Grenzen gegen Personenbewertung oder Social-Credit-Logik.

- Ausgestaltungsspielraum: Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Parteien behalten Spielraum bei Tempo, Instrumenten, Sektorprioritäten, Fördertöpfen, Steuerpfaden, Bürgerbeteiligung und europäischer Einbettung. Entscheidend ist die überprüfbare Wirkung auf Mensch, Planet und Demokratie.

- Zielkonflikte: Umsetzung erzeugt Konflikte zwischen Schnelligkeit und Rechtssicherheit, Innovation und Missbrauchsschutz, Entlastung und Lenkungswirkung, Datenbedarf und Datenschutz, europäischen Standards und lokaler Anpassung, Investitionssicherheit und Abbau destruktiver Geschäftsmodelle.

- Rollenverteilung: Bund, Länder, Kommunen, Wirtschaft, Wissenschaft, Zivilgesellschaft, Medien, Kapitalmärkte und Bürger:innen übernehmen unterschiedliche Rollen. Keine Ebene darf die Umsetzung allein dominieren. Wirksame Transformation braucht koordinierte Zuständigkeiten und nachvollziehbare Verantwortlichkeit.

- Übergang und Schutz: Positive Wirkung darf nicht dauerhaft Luxus bleiben. Grundbedarfe, KMU, Kommunen, verletzliche Gruppen und kleine Lieferanten benötigen Schutz, Übergangsfristen, Beratung, Datenadapter, Finanzierung und einfache Verfahren.

- Evaluation und Korrektur: Jeder Pilot braucht Hypothesen, Messplan, Datenqualitätsklassen, Abbruchregeln, Korrekturschleifen, öffentliche Auswertung und Skalierungskriterien. Fehler sind nicht das Ende des Modells, sondern Material des Lernens.

- Schutz vor Technokratie: Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertungen müssen öffentlich begründet, anfechtbar, versioniert, unabhängig geprüft und politisch diskutierbar sein.

## Quellenrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands. Arbeitsfassung 2026. Teil XVI - Transformation, Übergänge und Implementierung, Kapitel 97 bis 100.

Weber, Natalie: Grundlagenpapier Wirkungsökonomie WÖk. 2025. Abschnitte zu Umsetzung, Transformation, Change-Management und Praxisbeispielen.

European Commission: Better regulation: guidelines and toolbox. https://commission.europa.eu/law/law-making-process/better-regulation/better-regulation-guidelines-and-toolbox_en

OECD: Recommendation of the Council on Regulatory Policy and Governance. OECD/LEGAL/0390. https://legalinstruments.oecd.org/en/instruments/OECD-LEGAL-0390

OECD: Regulatory Sandbox Toolkit. 2025. https://www.oecd.org/en/publications/regulatory-sandbox-toolkit_de36fa62-en.html

European Commission: Use of regulatory sandboxes in EU Member States. 2026. https://op.europa.eu/en/publication-detail/-/publication/6942cc0e-3d27-11f1-814f-01aa75ed71a1/language-en

European Commission: Public Procurement of Innovation. https://single-market-economy.ec.europa.eu/single-market/public-procurement/strategic-procurement/public-procurement-innovation_en

OECD: Strategic Public Procurement. https://www.oecd.org/en/topics/strategic-public-procurement.html

OECD: Implementation Toolkit for the OECD Recommendation on Public Policy Evaluation. 2025. https://www.oecd.org/en/publications/implementation-toolkit-for-the-oecd-recommendation-on-public-policy-evaluation_77faa4fe-en.html

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development. https://sdgs.un.org/2030agenda

## Glossarlinks

- Wirkung: Tatsächliche Veränderung von Zuständen. Wirkung kann positiv, negativ oder neutral sein.

- Positive Netto-Wirkung: Zielgröße der Wirkungsökonomie: tragfähige Wirkung für Mensch, Planet und Demokratie unter Berücksichtigung negativer Effekte und roter Linien.

- Pilotierung: Zeitlich, sachlich und räumlich begrenzte Erprobung einer Wirkungslogik mit Messplan, Rechtsschutz, Evaluation und Korrektur.

- Reallabor: Geschützter Umsetzungsraum, in dem Regeln, Daten, Prozesse und Governance in realen Bedingungen geprüft werden.

- Wirkungsreife: Grad, zu dem ein Instrument methodisch, rechtlich, organisatorisch, sozial und datenbezogen bereit für Skalierung ist.

- Wirkungs-Konversion: Glaubwürdige Überführung von Altkapital, Geschäftsmodellen und Infrastrukturen von Verlustleistung in Wirkleistung.

- Reverse Merit Order: Engpasslogik: kritische negative Wirkungen dürfen nicht durch positive Werte überdeckt werden.

- Wirkungsrat: Unabhängige Sicherungsinstitution für Indikatoren, Benchmarks, Versionierung, Evaluation und Missbrauchsschutz.

- SDG+: WÖk-Erweiterung für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
