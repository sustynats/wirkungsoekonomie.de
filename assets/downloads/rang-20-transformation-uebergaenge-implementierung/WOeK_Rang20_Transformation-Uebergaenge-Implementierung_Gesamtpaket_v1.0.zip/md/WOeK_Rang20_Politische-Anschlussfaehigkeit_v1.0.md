# Politische Anschlussfähigkeit Rang 20

**Umsetzungsoptionen, Zielkonflikte und Schutz vor Technokratie**

Dokumenttyp: Politische Anschlussfähigkeit

Autorin: Natalie Weber

Referenz: Wirkungsökonomie

Version: 1.0

Stand: Mai 2026

Status: Langfassungsentwurf für Website, Akademie, Dossier und Download

Hinweis: Dieses Dokument ist für öffentliche Onlinefassungen und Downloads bestimmt. Es enthält keine internen Arbeitsanweisungen.

## Dokumentinformationen

Dokumenttyp: Politische Anschlussfähigkeit

Autorin: Natalie Weber

Referenz: Wirkungsökonomie

Version: 1.0

Stand: Mai 2026

Status: Langfassungsentwurf für Website, Akademie, Dossier und Download

Hinweis: Dieses Dokument ist für öffentliche Onlinefassungen und Downloads bestimmt. Es enthält keine internen Arbeitsanweisungen.

## Kurzfassung

Dieses Dokument enthält den Pflichtblock für alle Rang-20-Wirkungsfeldseiten.

## Politische Anschlussfähigkeit und Umsetzungsoptionen

- Aufgabe der Politik: Politik muss nicht jede Einzelentscheidung vorgeben. Sie muss Schutzgüter definieren, Datenqualität sichern, Piloträume ermöglichen, soziale Übergänge abfedern, Rechtsschutz garantieren und die Rückkopplung der Wirkung in Haushalte, Beschaffung, Förderung, Steuern, Kapitalzugang und öffentliche Berichte organisieren.

- Politische Rahmenbedingungen: Erforderlich sind gesetzliche Experimentierklauseln, transparente Bewertungsmethoden, Datenschutz, öffentliche Konsultationen, kommunale Finanzierung, unabhängige Evaluation, Wirkungsrat, Widerspruchsrechte und klare Grenzen gegen Personenbewertung oder Social-Credit-Logik.

- Ausgestaltungsspielraum: Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Parteien behalten Spielraum bei Tempo, Instrumenten, Sektorprioritäten, Fördertöpfen, Steuerpfaden, Bürgerbeteiligung und europäischer Einbettung. Entscheidend ist die überprüfbare Wirkung auf Mensch, Planet und Demokratie.

- Zielkonflikte: Umsetzung erzeugt Konflikte zwischen Schnelligkeit und Rechtssicherheit, Innovation und Missbrauchsschutz, Entlastung und Lenkungswirkung, Datenbedarf und Datenschutz, europäischen Standards und lokaler Anpassung, Investitionssicherheit und Abbau destruktiver Geschäftsmodelle.

- Rollenverteilung: Bund, Länder, Kommunen, Wirtschaft, Wissenschaft, Zivilgesellschaft, Medien, Kapitalmärkte und Bürger:innen übernehmen unterschiedliche Rollen. Keine Ebene darf die Umsetzung allein dominieren. Wirksame Transformation braucht koordinierte Zuständigkeiten und nachvollziehbare Verantwortlichkeit.

- Übergang und Schutz: Positive Wirkung darf nicht dauerhaft Luxus bleiben. Grundbedarfe, KMU, Kommunen, verletzliche Gruppen und kleine Lieferanten benötigen Schutz, Übergangsfristen, Beratung, Datenadapter, Finanzierung und einfache Verfahren.

- Evaluation und Korrektur: Jeder Pilot braucht Hypothesen, Messplan, Datenqualitätsklassen, Abbruchregeln, Korrekturschleifen, öffentliche Auswertung und Skalierungskriterien. Fehler sind nicht das Ende des Modells, sondern Material des Lernens.

- Schutz vor Technokratie: Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertungen müssen öffentlich begründet, anfechtbar, versioniert, unabhängig geprüft und politisch diskutierbar sein.

## Parteipolitische Anschlussfähigkeit

Die Wirkungsökonomie kann von unterschiedlichen politischen Richtungen genutzt werden: sozialpolitisch als Schutz von Grundbedarfen, wirtschaftspolitisch als Innovations- und Wettbewerbslogik, ökologisch als Internalisierung externer Kosten, liberal als bessere Marktsignale, konservativ als Stabilitäts- und Resilienzlogik, demokratisch als Transparenz- und Beteiligungsarchitektur. Sie ersetzt keine Programme, sondern macht ihre Folgen prüfbar.

## Grenzen

Keine politische Richtung darf Wirkungsmessung als Vorwand für Personenbewertung, Überwachung, Ausschluss, Identitätskontrolle oder Umgehung demokratischer Verfahren nutzen.

## Quellenrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands. Arbeitsfassung 2026. Teil XVI - Transformation, Übergänge und Implementierung, Kapitel 97 bis 100.

Weber, Natalie: Grundlagenpapier Wirkungsökonomie WÖk. 2025. Abschnitte zu Umsetzung, Transformation, Change-Management und Praxisbeispielen.

European Commission: Better regulation: guidelines and toolbox. https://commission.europa.eu/law/law-making-process/better-regulation/better-regulation-guidelines-and-toolbox_en

OECD: Recommendation of the Council on Regulatory Policy and Governance. OECD/LEGAL/0390. https://legalinstruments.oecd.org/en/instruments/OECD-LEGAL-0390

OECD: Regulatory Sandbox Toolkit. 2025. https://www.oecd.org/en/publications/regulatory-sandbox-toolkit_de36fa62-en.html

European Commission: Use of regulatory sandboxes in EU Member States. 2026. https://op.europa.eu/en/publication-detail/-/publication/6942cc0e-3d27-11f1-814f-01aa75ed71a1/language-en

European Commission: Public Procurement of Innovation. https://single-market-economy.ec.europa.eu/single-market/public-procurement/strategic-procurement/public-procurement-innovation_en

OECD: Strategic Public Procurement. https://www.oecd.org/en/topics/strategic-public-procurement.html

OECD: Implementation Toolkit for the OECD Recommendation on Public Policy Evaluation. 2025. https://www.oecd.org/en/publications/implementation-toolkit-for-the-oecd-recommendation-on-public-policy-evaluation_77faa4fe-en.html

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development. https://sdgs.un.org/2030agenda

## Glossarlinks

- Wirkung: Tatsächliche Veränderung von Zuständen. Wirkung kann positiv, negativ oder neutral sein.

- Positive Netto-Wirkung: Zielgröße der Wirkungsökonomie: tragfähige Wirkung für Mensch, Planet und Demokratie unter Berücksichtigung negativer Effekte und roter Linien.

- Pilotierung: Zeitlich, sachlich und räumlich begrenzte Erprobung einer Wirkungslogik mit Messplan, Rechtsschutz, Evaluation und Korrektur.

- Reallabor: Geschützter Umsetzungsraum, in dem Regeln, Daten, Prozesse und Governance in realen Bedingungen geprüft werden.

- Wirkungsreife: Grad, zu dem ein Instrument methodisch, rechtlich, organisatorisch, sozial und datenbezogen bereit für Skalierung ist.

- Wirkungs-Konversion: Glaubwürdige Überführung von Altkapital, Geschäftsmodellen und Infrastrukturen von Verlustleistung in Wirkleistung.

- Reverse Merit Order: Engpasslogik: kritische negative Wirkungen dürfen nicht durch positive Werte überdeckt werden.

- Wirkungsrat: Unabhängige Sicherungsinstitution für Indikatoren, Benchmarks, Versionierung, Evaluation und Missbrauchsschutz.

- SDG+: WÖk-Erweiterung für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
