# Toolkarten Rang 15

## Beschreibung, Nutzen, Status und Links

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Toolkarte 1: Sozialraumprofil Migration und Vielfalt

Beschreibung: Bewertet kommunale Sozialraeume nach Wohnen, Bildung, Gesundheit, Sicherheit, Teilhabe, Integration, Diversitaetswirkung und digitalem Zugang.

Nutzen: Macht sichtbar, wo Integration gelingt und wo Ueberlastung, Segregation oder Infrastrukturdefizite entstehen.

Status: Demo in Vorbereitung

Link: /tools/sozialraumprofil-migration-vielfalt/

## Toolkarte 2: Integrations-Infrastruktur-Score

Beschreibung: Prueft, ob eine Kommune oder Region ueber tragfaehige Integrationsinfrastruktur verfuegt: Sprache, Bildung, Verwaltung, Wohnen, Gesundheit, Arbeit und Partizipation.

Nutzen: Macht Integration steuerbar, ohne Menschen zu bewerten. Bewertet werden Strukturen, Zugänge und Systemfaehigkeit.

Status: Demo in Vorbereitung

Link: /tools/integrations-infrastruktur-score/

## Toolkarte 3: Zugehoerigkeits- und Teilgabeindex

Beschreibung: Misst, ob Menschen Zugang zu Beteiligung, Vereinen, Kultur, Bildung, Arbeit und lokalen Entscheidungsprozessen haben.

Nutzen: Zeigt, ob Demokratie im Alltag erfahrbar wird.

Status: Demo in Vorbereitung

Link: /tools/zugehoerigkeit-teilgabeindex/

## Toolkarte 4: Diskursrisiko-Radar Migration

Beschreibung: Beobachtet oeffentliche Narrative, Feindseligkeit, Polarisierung, Desinformation und Diskursqualitaet im Themenfeld Migration.

Nutzen: Fruehwarnsystem gegen Eskalation, Stigmatisierung und demokratische Destabilisierung.

Status: Demo in Vorbereitung

Link: /tools/diskursrisiko-radar-migration/

## Toolkarte 5: Arbeitsmarkt-Wirkungsmonitor Migration

Beschreibung: Bewertet Fachkraefteintegration, Qualifikationsanerkennung, faire Arbeit, Schutz vor Ausbeutung und Uebergaenge in Ausbildung.

Nutzen: Verknuepft Arbeitsmarktpolitik mit Wirkung auf Fachkraeftesicherung, Teilhabe und soziale Stabilitaet.

Status: Demo in Vorbereitung

Link: /tools/arbeitsmarkt-wirkungsmonitor-migration/

## Toolkarte 6: Kommunale Integrationsarchitektur-Check

Beschreibung: Prueft, ob Kommunen ueber koordinierte Strukturen fuer Integration, Gemeinwesenarbeit, Konfliktmoderation, Beteiligung und Datenmonitoring verfuegen.

Nutzen: Unterstuetzt Staedte und Gemeinden bei der Planung wirkungsorientierter Integrationspolitik.

Status: Demo in Vorbereitung

Link: /tools/kommunale-integrationsarchitektur-check/
