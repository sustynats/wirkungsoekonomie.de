# Rang 15 - Bestands- und Nachlieferliste

## Migration und Vielfalt

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Ziel dieser Liste

Diese Liste trennt vorhandene Grundlagen von echten Nachlieferungen. Sie verhindert, dass kurze Grobtexte als Detailkonzepte ausgegeben werden. Rang 15 wird als Fachportal im Dossier-Niveau aufgebaut.

## Statusmatrix

| Baustein | Status | Massnahme | Prioritaet |
|---|---|---|---|
| Portalstartseite | neu erstellt im Paket | als Online-Volltext einpflegen | hoch |
| Konzeptpapier | vorhanden als Entwurf | als Kurz- und Einfuehrungspapier verwenden, nicht als Detailkonzept | hoch |
| Gesamtdossier | neu als Langfassungsentwurf | redaktionell vertiefen, Quellen aktualisieren, PDF verlinken | hoch |
| Migration als Wirkungsfeld | neu als Detailkonzept | Langfassung veroeffentlichen | hoch |
| Integration als Infrastruktur | neu als Detailkonzept | Langfassung veroeffentlichen | hoch |
| Vielfalt als Resilienzfaktor | neu als Detailkonzept | Langfassung veroeffentlichen | mittel |
| Zugehoerigkeit und Teilgabe | neu als Detailkonzept | Langfassung veroeffentlichen | hoch |
| Arbeitsmarkt und Fachkraefte | neu als Detailkonzept | mit Rang 6 Arbeit und Einkommen querverlinken | hoch |
| Bildung und Sprache | neu als Detailkonzept | mit Rang 8 Bildung querverlinken | hoch |
| Wohnen und Sozialraeume | neu als Detailkonzept | mit Rang 5 Wohnen und Stadt querverlinken | hoch |
| Gesundheit und Trauma | neu als Detailkonzept | mit Rang 10 Gesundheit und Pflege querverlinken | hoch |
| Diskurs und Polarisierung | neu als Detailkonzept | mit Rang 9 Medien querverlinken | hoch |
| Kommunale Integrationsarchitektur | neu als Detailkonzept | Pilotkommunen und Toolkarten anschliessen | hoch |
| Wirkungsindikatoren | neu als Methodenpapier | Datenquellen pruefen und Dashboard vorbereiten | hoch |
| Toolkarten | neu als Portalblock | Links auf Demo in Vorbereitung setzen | mittel |
| SDG-/SDG+-Block | neu erstellt | auf jeder Unterseite integrieren | hoch |
| Politische Anschlussfaehigkeit | neu erstellt | Pflichtblock auf jeder Wirkungsfeldseite integrieren | hoch |
| Online-Volltexte | in HTML enthalten | vollstaendig online lesbar machen | hoch |
| Downloads | PDFs enthalten | Links pruefen und in Downloadseite einpflegen | hoch |
| Quellen und Glossarlinks | enthalten | externe Zahlen vor Livegang aktualisieren | hoch |

## Qualitaetsregel

Ein Text darf nur dann als Detailkonzept bezeichnet werden, wenn er ueber Zielbild, Problemstellung, Wirkungslogik, Datenquellen, Bewertungslogik, Umsetzungsoptionen, politische Anschlussfaehigkeit, SDG-/SDG+-Bezug, Zielkonflikte und Quellen verfuegt. Kurze Texte sind Ueberblicke, Teaser, Portaltexte oder Einfuehrungen.
