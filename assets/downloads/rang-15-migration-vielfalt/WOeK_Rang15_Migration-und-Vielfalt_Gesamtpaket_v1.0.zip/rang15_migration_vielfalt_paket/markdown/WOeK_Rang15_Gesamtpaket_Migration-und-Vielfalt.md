# Gesamtpaket Rang 15

## Migration und Vielfalt - alle Inhalte, Onlinefassungen und Langkonzepte

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026



# ZIP-Paket Rang 15 - Migration und Vielfalt

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026

Dieses Paket enthaelt die Arbeits- und Downloadstruktur fuer Rang 15 der Wirkungsoekonomie: Migration und Vielfalt.

## Ordner

- markdown: redaktionelle Quelltexte und Online-Volltextgrundlagen
- pdf: PDF-Downloads im Corporate-Design-Grundlayout der Wirkungsoekonomie
- onlinefassungen: HTML-Seiten fuer Website-Onlinefassungen
- daten: JSON-Index und Toolkarten

## Enthaltene Hauptbausteine

- Bestands- und Nachlieferliste
- Portalstartseite
- Konzeptpapier
- Gesamtdossier
- zehn Detailkonzepte im Langfassungsentwurf
- Wirkungsindikatoren
- Toolkarten
- SDG- und SDG+-Block
- Politische Anschlussfaehigkeit
- Quellen und Glossarlinks

## Qualitaetshinweis

Die Texte sind als veroeffentlichungsnahe Entwuerfe angelegt. Vor Livegang sollten externe Zahlen, URLs und Quellen mit Abrufdatum aktualisiert werden. Der Begriffsleitfaden vom 21. Mai 2026 bleibt fuehrend.




# Rang 15 - Bestands- und Nachlieferliste

## Migration und Vielfalt

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Ziel dieser Liste

Diese Liste trennt vorhandene Grundlagen von echten Nachlieferungen. Sie verhindert, dass kurze Grobtexte als Detailkonzepte ausgegeben werden. Rang 15 wird als Fachportal im Dossier-Niveau aufgebaut.

## Statusmatrix

| Baustein | Status | Massnahme | Prioritaet |
|---|---|---|---|
| Portalstartseite | neu erstellt im Paket | als Online-Volltext einpflegen | hoch |
| Konzeptpapier | vorhanden als Entwurf | als Kurz- und Einfuehrungspapier verwenden, nicht als Detailkonzept | hoch |
| Gesamtdossier | neu als Langfassungsentwurf | redaktionell vertiefen, Quellen aktualisieren, PDF verlinken | hoch |
| Migration als Wirkungsfeld | neu als Detailkonzept | Langfassung veroeffentlichen | hoch |
| Integration als Infrastruktur | neu als Detailkonzept | Langfassung veroeffentlichen | hoch |
| Vielfalt als Resilienzfaktor | neu als Detailkonzept | Langfassung veroeffentlichen | mittel |
| Zugehoerigkeit und Teilgabe | neu als Detailkonzept | Langfassung veroeffentlichen | hoch |
| Arbeitsmarkt und Fachkraefte | neu als Detailkonzept | mit Rang 6 Arbeit und Einkommen querverlinken | hoch |
| Bildung und Sprache | neu als Detailkonzept | mit Rang 8 Bildung querverlinken | hoch |
| Wohnen und Sozialraeume | neu als Detailkonzept | mit Rang 5 Wohnen und Stadt querverlinken | hoch |
| Gesundheit und Trauma | neu als Detailkonzept | mit Rang 10 Gesundheit und Pflege querverlinken | hoch |
| Diskurs und Polarisierung | neu als Detailkonzept | mit Rang 9 Medien querverlinken | hoch |
| Kommunale Integrationsarchitektur | neu als Detailkonzept | Pilotkommunen und Toolkarten anschliessen | hoch |
| Wirkungsindikatoren | neu als Methodenpapier | Datenquellen pruefen und Dashboard vorbereiten | hoch |
| Toolkarten | neu als Portalblock | Links auf Demo in Vorbereitung setzen | mittel |
| SDG-/SDG+-Block | neu erstellt | auf jeder Unterseite integrieren | hoch |
| Politische Anschlussfaehigkeit | neu erstellt | Pflichtblock auf jeder Wirkungsfeldseite integrieren | hoch |
| Online-Volltexte | in HTML enthalten | vollstaendig online lesbar machen | hoch |
| Downloads | PDFs enthalten | Links pruefen und in Downloadseite einpflegen | hoch |
| Quellen und Glossarlinks | enthalten | externe Zahlen vor Livegang aktualisieren | hoch |

## Qualitaetsregel

Ein Text darf nur dann als Detailkonzept bezeichnet werden, wenn er ueber Zielbild, Problemstellung, Wirkungslogik, Datenquellen, Bewertungslogik, Umsetzungsoptionen, politische Anschlussfaehigkeit, SDG-/SDG+-Bezug, Zielkonflikte und Quellen verfuegt. Kurze Texte sind Ueberblicke, Teaser, Portaltexte oder Einfuehrungen.




# Portalstartseite Rang 15

## Migration und Vielfalt - Wirkung gestalten statt Zugehoerigkeit dem Zufall ueberlassen

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Hero-Text

Migration ist kein Randthema moderner Gesellschaften. Sie beruehrt Arbeitsmarkt, Bildung, Wohnen, Gesundheit, Sicherheit, Demokratie, Medien, Kommunen, Familien und globale Gerechtigkeit. Sie kann Gesellschaften staerken, wenn Schutz, Integration, Teilgabe und faire Rahmenbedingungen gelingen. Sie kann aber auch Konflikte, Ueberforderung, Ausbeutung, Parallelstrukturen und Misstrauen verstaerken, wenn Systeme nicht vorbereitet sind.

Die Wirkungsoekonomie bewertet Migration deshalb nicht nach Parolen. Sie fragt, welche Zustaende sich veraendern, wer geschuetzt wird, wer belastet wird, welche Wirkung fuer Kommunen, Arbeitsmaerkte, Schulen, Quartiere und demokratische Stabilitaet entsteht und wo positive Netto-Wirkung oder Wirkungsrisiken sichtbar werden.

## Vier Kernfragen des Portals

1. Wie werden Schutz, Rechtsstaat und Menschenwuerde gesichert?
2. Welche Integrationsinfrastruktur braucht eine Kommune, damit Sprache, Bildung, Arbeit, Wohnen, Gesundheit und Teilgabe gelingen?
3. Unter welchen Bedingungen wird Vielfalt zu Resilienz, Innovation und demokratischer Lernfaehigkeit?
4. Wie schuetzen Medien, Politik und Zivilgesellschaft den oeffentlichen Diskurs vor Entmenschlichung, Desinformation und Polarisierung?

## Portalmodule

- Migration als Wirkungsfeld
- Integration als Infrastruktur
- Vielfalt als Resilienzfaktor
- Zugehoerigkeit und Teilgabe
- Arbeitsmarkt, Fachkraefte und demografische Stabilitaet
- Bildung, Sprache und Wirkungskompetenz
- Wohnen, Quartiere und Sozialraeume
- Gesundheit, Trauma und psychosoziale Stabilitaet
- Demokratie, Diskurs und Schutz vor Spaltung
- Medienframes, Angstnarrative und Desinformation
- Kommunale Integrationsarchitektur
- Wirkungsindikatoren fuer Integration und Vielfalt

## Leitgedanke

Schutz ohne Moeglichkeit macht Menschen abhaengig. Moeglichkeit ohne Schutz macht Menschen verletzlich. Erst beides zusammen erzeugt positive Netto-Wirkung.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.

## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Konzeptpapier Rang 15

## Migration und Vielfalt als Wirkungsfeld

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Executive Summary

Dieses Konzeptpapier ordnet Migration und Vielfalt als Wirkungsfeld der Wirkungsoekonomie ein. Migration wird nicht als eindimensionales Problem und nicht als automatisch positive Ressource verstanden. Sie wird als Bewegung von Menschen, Kompetenzen, Schutzbedarfen, Familien, Erwartungen, Rechten, Risiken und Moeglichkeiten analysiert. Entscheidend ist nicht die Parole, sondern die Netto-Wirkung auf Mensch, Planet und Demokratie.

Migration zeigt globale Ungleichgewichte, Arbeitskraeftebedarf, Schutzbeduerftigkeit, Bildungszugang, Wohnungsdruck, Klimarisiken, Gewalt, Familienbindung und Zukunftsfaehigkeit. Integration zeigt Systemfaehigkeit: Kann eine Gesellschaft Schutz gewaehren, Verfahren rechtsstaatlich gestalten, Sprache und Bildung ermoeglichen, Arbeit fair zugaenglich machen, Wohnen stabilisieren, Gesundheit sichern und demokratische Teilgabe oeffnen?

## Warum Rang 15 ein eigenes Portal braucht

Migration und Vielfalt sind Querschnittsfelder. Sie duerfen nicht nur in Sozialpolitik, Arbeitsmarktpolitik oder Sicherheitspolitik aufgeteilt werden. Migration wirkt in allen diesen Bereichen zugleich. Ein isolierter Blick erzeugt Fehlsteuerung. Ein rein arbeitsmarktpolitischer Blick uebersieht Schutz und Zugehoerigkeit. Ein rein sicherheitspolitischer Blick uebersieht Teilgabe und Resilienz. Ein rein moralischer Blick uebersieht kommunale Belastungsgrenzen und Zielkonflikte.

Die Wirkungsoekonomie bietet eine Systemlogik. Sie fragt nach Wirkpfaden, Daten, Mindestbedingungen, Zielkonflikten, Rueckkopplungen und politischer Korrektur. Damit kann sie die Debatte versachlichen, ohne sie zu entpolitisieren.

## Schutz und Moeglichkeit

Schutz meint Menschenwuerde, faire Verfahren, rechtliche Beratung, Schutz vor Gewalt, Schutz vor Ausbeutung, sichere Unterbringung und Zugang zu grundlegender Versorgung. Moeglichkeit meint Sprache, Bildung, Arbeit, Wohnen, Gesundheit, Kultur, Anerkennung von Kompetenzen und demokratische Teilgabe.

Diese beiden Seiten muessen gemeinsam betrachtet werden. Wer nur Schutz organisiert, aber keine Moeglichkeiten eroeffnet, erzeugt Abhaengigkeit. Wer nur Moeglichkeit fordert, aber Schutz vernachlaessigt, laesst Menschen in verletzlichen Positionen. Positive Netto-Wirkung entsteht dort, wo Schutz und Moeglichkeit systematisch zusammenspielen.

## Integration als Infrastruktur

Integration wird oft als Erwartung an einzelne Menschen formuliert. Wirkungsorientiert ist Integration jedoch eine Infrastrukturleistung. Sie entsteht aus Sprache, Bildung, Verwaltung, Wohnen, Arbeit, Gesundheit, Kultur, Teilgabe, Sozialraum und Diskurs. Wenn diese Elemente fehlen, entsteht nicht mangelnde Integrationsbereitschaft, sondern mangelnde Integrationsfaehigkeit des Systems.

Eine integrationsfaehige Kommune hat klare Anlaufstellen, verstaendliche Verfahren, fruehen Sprachzugang, passende Bildungswege, sichere Wohnraeume, arbeitsmarktnahe Qualifizierung, psychosoziale Versorgung, Kultur- und Begegnungsraeume, Konfliktmoderation und Beteiligungsformate.

## Vielfalt als Resilienzpotenzial

Vielfalt kann Innovation, Lernfaehigkeit, demografische Stabilitaet, Perspektivenbreite und demokratische Anpassungsfaehigkeit staerken. Sie wirkt aber nicht automatisch positiv. Ohne gemeinsame Regeln, Zugehoerigkeit, faire Chancen und Schutz vor Diskriminierung kann Vielfalt in Konkurrenz, Fragmentierung oder Misstrauen kippen.

Deshalb fragt dieses Portal nicht: Ist Vielfalt gut oder schlecht? Es fragt: Unter welchen Bedingungen erzeugt Vielfalt positive Netto-Wirkung?

## Umsetzung in der Website

Die Website muss Portalstartseite, Konzeptpapier, Gesamtdossier, Einzeldossiers, Detailkonzepte, Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Block, politische Anschlussfaehigkeit, Buchanker, Glossarlinks, Quellen, Druckfunktion und Querverlinkungen enthalten. Jeder Download braucht eine vollstaendige Onlinefassung. Jede Toolkarte braucht Beschreibung, Nutzen, Status und Link.

## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.

## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Gesamtdossier Rang 15

## Migration und Vielfalt in der Wirkungsoekonomie

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## 1. Executive Summary

Migration und Vielfalt sind gesellschaftliche Wirkungsfelder. Sie veraendern Zustaende in Kommunen, Familien, Arbeitsmaerkten, Schulen, Hochschulen, Pflege, Gesundheit, Wohnen, Kultur, Medien, Recht, Sicherheit und Demokratie. Diese Veraenderungen koennen positiv, negativ oder ambivalent sein. Positive Netto-Wirkung entsteht nicht durch Migration an sich, sondern durch die Art, wie Schutz, Verfahren, Integration, Teilgabe, Arbeitsmarkt, Wohnraum, Gesundheit und Diskurs gestaltet werden.

Das Gesamtdossier ordnet Rang 15 als Fachportal. Es liefert eine Systemarchitektur fuer Website, Downloads, Langkonzepte, Toolkarten und politische Anschlussfaehigkeit. Es ersetzt keine demokratische Entscheidung. Es macht Wirkungen sichtbar und korrigierbar.

## 2. Ausgangslage

Migration wird oeffentlich haeufig als moralischer oder sicherheitspolitischer Konflikt diskutiert. Die Wirkungsoekonomie verschiebt den Blick. Sie fragt nicht zuerst, welche Identitaet jemand hat, sondern welche Strukturen entstehen: Zugang oder Ausschluss, Schutz oder Verletzlichkeit, Bildung oder Abbruch, faire Arbeit oder Ausbeutung, Zugehoerigkeit oder Misstrauen, demokratische Beteiligung oder Entfremdung.

Damit wird Migration als Rueckkopplung sichtbar. Sie zeigt globale Ungleichgewichte, demografische Verschiebungen, Klimarisiken, Kriege, Arbeitskraeftenachfrage, Bildungsungleichheit und Schutzdefizite. Sie zeigt aber auch, ob eine Gesellschaft neue Zugehoerigkeit ermoeglichen kann.

## 3. Wirkungsraeume

### 3.1 Kommune

Kommunen sind der Ort, an dem Migration praktisch wirkt. Hier entstehen Schulplaetze, Wohnraumbedarf, Nachbarschaften, Konflikte, Vereine, Sprachkurse, Beratungsstellen, Gesundheitszugang und lokale Demokratie. Kommunale Ueberlastung ist keine abstrakte Meinung, sondern ein messbarer Zustand. Wirkungsorientierte Politik darf sie nicht ignorieren. Sie muss sie sichtbar machen und finanzieren.

### 3.2 Arbeitsmarkt

Migration kann Fachkraeftebedarf mindern, demografische Stabilitaet erhoehen und Betriebe sichern. Sie kann aber auch Ausbeutung, Lohndruck und prekare Arbeit verstaerken, wenn Schutz, Anerkennung und Qualifizierung fehlen. Arbeitsmarktintegration muss deshalb fair, schnell, rechtsstaatlich und kompetenzorientiert sein.

### 3.3 Bildung und Sprache

Sprache ist Zugangsinfrastruktur. Sie darf nicht nur als Sanktionspunkt behandelt werden. Bildung ist der zentrale Wirkpfad fuer Teilgabe, Selbstwirksamkeit und demokratische Stabilitaet. Schulische Uebergaenge, Erwachsenenbildung, Sprachmittlung und Elternarbeit sind entscheidende Hebel.

### 3.4 Wohnen und Sozialraum

Wohnen entscheidet, ob Integration im Alltag moeglich wird. Ueberbelegung, Segregation, fehlende Verkehrsanbindung und angespannte Quartiere erzeugen Wirkungsrisiken. Gute Sozialraeume verbinden Wohnen, Bildung, Gruen, Mobilitaet, Beratung, Kultur, Gesundheit und Sicherheit.

### 3.5 Gesundheit und psychosoziale Stabilitaet

Migration kann mit Belastung, Flucht, Verlust, Trauma, Unsicherheit und Sprachbarrieren verbunden sein. Gesundheitssysteme muessen Schutz, Praevention, Sprachmittlung und psychische Gesundheit einbeziehen. Traumaversorgung ist nicht nur humanitaer wichtig, sondern auch gesellschaftliche Resilienzpolitik.

### 3.6 Demokratie und Diskurs

Migration ist ein Resonanzthema. Es kann Zugehoerigkeit, Lernfaehigkeit und Solidaritaet staerken. Es kann aber auch Angstnarrative, Feindbilder, Desinformation und Polarisierung ausloesen. Diskursqualitaet ist deshalb kein Nebenthema, sondern SDG+-relevant.

## 4. Wirkungslogik

Wirkung entsteht ueber Pfade. Ein Beispiel: Eine Kommune eroeffnet fruehe Sprachkurse. Direkte Wirkung ist besserer Zugang zu Sprache. Indirekte Wirkung kann schnellerer Bildungs- oder Arbeitsmarktzugang sein. Systemische Wirkung kann sinkende Abhaengigkeit, hoeheres Vertrauen und geringeres Konfliktrisiko sein. Negative Nebenwirkungen koennen entstehen, wenn Kurse schlecht erreichbar sind, Frauen mit Care-Verantwortung ausgeschlossen werden oder Menschen lange warten muessen.

Ein zweites Beispiel: Qualifikationsanerkennung wird beschleunigt. Direkte Wirkung ist schnellerer Berufszugang. Indirekte Wirkung sind mehr Fachkraefte und hoehere Selbstwirksamkeit. Systemische Wirkung kann eine stabilere kommunale Wirtschaft sein. Risiken entstehen, wenn Anerkennung ohne Sprachbegleitung, Arbeitsschutz oder faire Vermittlung erfolgt.

## 5. Nichtkompensation und rote Linien

Positive Arbeitsmarktwirkung darf nicht Ausbeutung kompensieren. Kulturelle Vielfalt darf nicht Rechtsstaatsverletzung verdecken. Schnelle Verfahren duerfen nicht faire Verfahren ersetzen. Hohe Fachkraeftewirkung darf Schutzbeduerftigkeit nicht entwerten. Gewalt, Kinderrechtsverletzungen, Menschenhandel, Zwang, Diskriminierung und Entwuerdigung sind Wirkungsgrenzen.

## 6. Fachunterbereiche

### Migration als Wirkungsfeld

Migration ist Bewegung und Rueckkopplung. Sie zeigt, wo Lebensbedingungen nicht tragen, wo Schutz gebraucht wird und wo Arbeitsmaerkte Menschen brauchen. Sie muss differenziert betrachtet werden: Flucht, Arbeitsmigration, Familienmigration, Bildungsmigration, Binnenmobilitaet, temporäre Migration und zirkulaere Migration erzeugen unterschiedliche Wirkpfade.

### Integration als Infrastruktur

Integration gelingt dort, wo Systeme faehig sind, Zugang zu organisieren. Integrationsinfrastruktur besteht aus Sprache, Bildung, Arbeit, Wohnen, Gesundheit, Verwaltung, Rechtsschutz, Kultur, Begegnung und Beteiligung.

### Vielfalt als Resilienzfaktor

Vielfalt kann Perspektiven erhoehen, Innovation beguenstigen und Monokulturen verhindern. Resilienz entsteht aber nur, wenn Vielfalt in gemeinsame Regeln, faire Chancen und Zugehoerigkeit eingebettet ist.

### Zugehoerigkeit und Teilgabe

Zugehoerigkeit ist nicht identisch mit Assimilation. Sie entsteht, wenn Menschen sicher sind, gehoert werden, Verantwortung uebernehmen koennen und sich als Teil eines gemeinsamen demokratischen Raums erfahren.

### Diskurs und Medien

Medien und Plattformen formen Wirkungsraeume. Migration kann durch Quellenklarheit, Kontext und Wuerde berichtet werden. Sie kann aber auch durch Feindbilder, Schlagworte und algorithmische Verstaerkung polarisiert werden.

## 7. Daten- und Toolarchitektur

Das Portal enthaelt sechs Tools: Sozialraumprofil Migration und Vielfalt, Integrations-Infrastruktur-Score, Zugehoerigkeits- und Teilgabeindex, Diskursrisiko-Radar, Arbeitsmarkt-Wirkungsmonitor und Kommunale Integrationsarchitektur-Check. Diese Tools bewerten keine Menschen. Sie bewerten Strukturen und Raeume.

## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.

## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Detailkonzept Migration als Wirkungsfeld

## Rueckkopplung, Schutz, Moeglichkeit und Netto-Wirkung

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Migration wird oft als eindimensionales Problem, Ressource oder Identitaetsfrage behandelt. Das verkuerzt die Realitaet. Migration ist Bewegung von Menschen durch unterschiedliche Lebensbedingungen, Risiken, Chancen, Gewalt, Arbeit, Familie, Bildung und Klima. Sie ist ein Rueckkopplungssignal gesellschaftlicher und globaler Systeme.

Ziel dieses Detailkonzepts ist eine Bewertungslogik, die Migration differenziert, ohne Menschen zu bewerten. Bewertet werden Wirkpfade, Strukturen, Verfahren und Systemfolgen.

## 1. Problemstellung

Migration wird oft als eindimensionales Problem, Ressource oder Identitaetsfrage behandelt. Das verkuerzt die Realitaet. Migration ist Bewegung von Menschen durch unterschiedliche Lebensbedingungen, Risiken, Chancen, Gewalt, Arbeit, Familie, Bildung und Klima. Sie ist ein Rueckkopplungssignal gesellschaftlicher und globaler Systeme. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Ziel dieses Detailkonzepts ist eine Bewertungslogik, die Migration differenziert, ohne Menschen zu bewerten. Bewertet werden Wirkpfade, Strukturen, Verfahren und Systemfolgen. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Migrationstypen und Wirkpfade

Zu unterscheiden sind Flucht, Arbeitsmigration, Familienmigration, Bildungsmigration, temporäre Migration, zirkulaere Migration und Binnenmobilitaet. Jede Form hat andere Schutzbedarfe, Rechte, Zeitraeume und Integrationspfade. Eine Kommune braucht deshalb eine Typologie, die nicht stigmatisiert, sondern passende Zugangswege ermoeglicht.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Schutzbedarfe

Schutzbedarfe entstehen durch Gewalt, Verfolgung, Krieg, Ausbeutung, Menschenhandel, Verlust, Trauma, Armut, Minderjaehrigkeit, Behinderung, Schwangerschaft oder fehlende rechtliche Sicherheit. Wirkungsorientierte Politik misst, ob Schutz tatsaechlich ankommt.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Rueckkopplung globaler Ungleichgewichte

Migration zeigt, wo Lebensbedingungen nicht tragen. Klimarisiken, Wasserstress, Konflikte, wirtschaftliche Perspektivlosigkeit, autoritaere Systeme und fragile Staaten erzeugen Wanderungsdruck. Wirkungsorientiert ist auch die Reduktion von Fluchtursachen Teil der Bewertung.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Kommunale Wirkung

Kommunen erleben Migration als konkrete Nachfrage nach Wohnraum, Bildung, Verwaltung, Gesundheit, Beratung und Sicherheit. Wenn Kommunen ueberlastet werden, sinkt Wirkung. Wenn sie gut ausgestattet werden, kann Integration Systemfaehigkeit zeigen.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Netto-Wirkung

Positive Effekte wie Arbeitsmarktbeitrag, demografische Stabilisierung und kulturelle Resonanz duerfen negative Wirkungen wie Ausbeutung, Ueberlastung oder Entwuerdigung nicht verdecken. Die Bewertung muss Mindestbedingungen und rote Linien beachten.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Detailkonzept Integration als Infrastruktur

## Sprache, Bildung, Arbeit, Wohnen, Gesundheit und Teilgabe als Systemfaehigkeit

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Integration wird zu oft als individuelle Anpassungsleistung verstanden. Dadurch bleiben strukturelle Zugangsbarrieren unsichtbar. Wer keine Sprache, keinen sicheren Wohnraum, keine Kita, keine Gesundheitsversorgung, keine Anerkennung von Kompetenzen und keine verstaendliche Verwaltung bekommt, kann nicht einfach integriert werden.

Integration soll als oeffentliche, soziale und wirtschaftliche Infrastruktur beschrieben werden. Eine Gesellschaft ist integrationsfaehig, wenn sie Zugang organisiert und Teilgabe ermoeglicht.

## 1. Problemstellung

Integration wird zu oft als individuelle Anpassungsleistung verstanden. Dadurch bleiben strukturelle Zugangsbarrieren unsichtbar. Wer keine Sprache, keinen sicheren Wohnraum, keine Kita, keine Gesundheitsversorgung, keine Anerkennung von Kompetenzen und keine verstaendliche Verwaltung bekommt, kann nicht einfach integriert werden. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Integration soll als oeffentliche, soziale und wirtschaftliche Infrastruktur beschrieben werden. Eine Gesellschaft ist integrationsfaehig, wenn sie Zugang organisiert und Teilgabe ermoeglicht. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Sprache als Zugangsinfrastruktur

Sprache ist Schluessel zu Bildung, Arbeit, Gesundheit, Verwaltung, Nachbarschaft und Demokratie. Sprachkurse muessen frueh, erreichbar, qualitaetsgesichert, geschlechtersensibel und mit Kinderbetreuung kombinierbar sein.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Verwaltung als Ermöglichungssystem

Verwaltung wirkt. Unverstaendliche Verfahren, lange Wartezeiten und unklare Zuständigkeiten erzeugen Unsicherheit. Mehrsprachige Information, klare Fallwege und digitale Barrierefreiheit erzeugen Teilgabe.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Bildung und Uebergaenge

Integration entscheidet sich an Uebergaengen: Kita, Schule, Ausbildung, Hochschule, Arbeit. Jeder Bruch erhoeht Wirkungsrisiken. Bildungsmonitoring muss Uebergaenge sichtbar machen.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Gesundheit und Stabilitaet

Gesundheitszugang, Traumaversorgung, Praevention und Sprachmittlung sind Kernbestandteile von Integration. Gesundheit ist keine Nebenleistung, sondern Voraussetzung fuer Lernen, Arbeit und Zugehoerigkeit.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Infrastruktur-Score

Der Integrations-Infrastruktur-Score misst Zugangsqualitaet: Wartezeiten, Reichweite, Qualitaet, Niedrigschwelligkeit, Betroffenenbeteiligung, Datenqualitaet und Korrekturmechanismen.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Detailkonzept Vielfalt als Resilienzfaktor

## Perspektivenbreite, Lernfaehigkeit und demokratische Stabilitaet

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Vielfalt wird oeffentlich entweder romantisiert oder problematisiert. Beides ist wirkungsblind. Vielfalt ist ein Potenzial, kein automatischer Zustand positiver Wirkung. Sie kann Resilienz, Innovation und Lernfaehigkeit staerken, wenn sie in faire Regeln und Zugehoerigkeit eingebettet ist.

Das Konzept operationalisiert Vielfalt als Resilienzfaktor und benennt Bedingungen, Risiken und Indikatoren positiver Netto-Wirkung.

## 1. Problemstellung

Vielfalt wird oeffentlich entweder romantisiert oder problematisiert. Beides ist wirkungsblind. Vielfalt ist ein Potenzial, kein automatischer Zustand positiver Wirkung. Sie kann Resilienz, Innovation und Lernfaehigkeit staerken, wenn sie in faire Regeln und Zugehoerigkeit eingebettet ist. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Das Konzept operationalisiert Vielfalt als Resilienzfaktor und benennt Bedingungen, Risiken und Indikatoren positiver Netto-Wirkung. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Resilienz statt Symbolik

Resilienz entsteht, wenn Systeme mehr Perspektiven, Erfahrungen, Sprachen, Netzwerke und Loesungswege haben. Symbolische Diversitaet ohne reale Macht, Schutz und Teilgabe erzeugt keine stabile Wirkung.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Wirtschaft und Innovation

Diverse Teams koennen blinde Flecken reduzieren, Kundengruppen besser verstehen und neue Loesungen entwickeln. Wirkung entsteht aber nur mit fairer Fuehrung, Konfliktfaehigkeit und Schutz vor Diskriminierung.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Demokratie und Institutionen

Institutionen werden robuster, wenn sie unterschiedliche Lebensrealitaeten kennen und einbeziehen. Monokulturen erhoehen Risiko fuer blinde Entscheidungen.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Risiken der Fragmentierung

Vielfalt ohne gemeinsame demokratische Regeln, faire Ressourcenverteilung und Begegnungsraeume kann Fragmentierung, Konkurrenz und Misstrauen verstaerken. Diese Risiken muessen messbar gemacht werden.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Indikatoren

Messpunkte sind Zugang zu Fuehrung, Beteiligung, Diskriminierungsfaelle, Beschwerdewege, Vertrauen, Perspektivenvielfalt in Gremien, Diversitaet in Institutionen und Qualitaet der Konfliktmoderation.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Detailkonzept Zugehoerigkeit und Teilgabe

## Demokratische Selbstwirksamkeit als Wirkungsziel

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Teilhabe wird oft passiv verstanden: Menschen duerfen teilnehmen. Die Wirkungsoekonomie erweitert dies zu Teilgabe: Menschen koennen beitragen, Verantwortung uebernehmen, gehoert werden und die gemeinsame Ordnung mitgestalten.

Zugehoerigkeit soll als demokratische Wirkungsdimension sichtbar werden. Sie entsteht aus Schutz, Anerkennung, Selbstwirksamkeit, Verantwortung und resonanzfaehigen Raeumen.

## 1. Problemstellung

Teilhabe wird oft passiv verstanden: Menschen duerfen teilnehmen. Die Wirkungsoekonomie erweitert dies zu Teilgabe: Menschen koennen beitragen, Verantwortung uebernehmen, gehoert werden und die gemeinsame Ordnung mitgestalten. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Zugehoerigkeit soll als demokratische Wirkungsdimension sichtbar werden. Sie entsteht aus Schutz, Anerkennung, Selbstwirksamkeit, Verantwortung und resonanzfaehigen Raeumen. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Teilhabe und Teilgabe

Teilhabe bedeutet Zugang. Teilgabe bedeutet wirksames Mitgestalten. Ein Mensch kann formal teilhaben und trotzdem keine reale Wirkung im Gemeinwesen entfalten.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Selbstwirksamkeit

Wer erlebt, dass eigenes Handeln etwas veraendert, entwickelt Vertrauen. Selbstwirksamkeit ist deshalb eine demokratische Stabilitaetsbedingung.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Resonanzraeume

Bibliotheken, Vereine, Jugendzentren, Kulturhaeuser, Stadtteilfeste, Sport, Schulen und Nachbarschaftsorte sind Wirkungsraeume von Zugehoerigkeit.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Antidiskriminierung

Diskriminierung zerstoert Zugehoerigkeit. Schutzstrukturen, Beschwerdewege, Rechtsklarheit und institutionelle Lernfaehigkeit sind zentrale Indikatoren.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Teilgabeindex

Der Zugehoerigkeits- und Teilgabeindex misst Beteiligungszugang, Vertrauen, Selbstwirksamkeit, Vereins- und Kulturzugang, Beschwerdewege, demokratische Bildung und lokale Resonanzraeume.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Detailkonzept Arbeitsmarkt, Fachkraefte und demografische Stabilitaet

## Faire Arbeit, Qualifikationsanerkennung und Schutz vor Ausbeutung

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Viele Gesellschaften stehen vor demografischem Druck und Fachkraeftemangel. Migration kann hier positive Wirkung entfalten. Ohne faire Arbeit, Qualifikationsanerkennung und Schutz entstehen jedoch Ausbeutung, Lohndruck und Vertrauensverlust.

Das Konzept verbindet Arbeitsmarktintegration mit Wirkungslogik, fairer Arbeit und demografischer Stabilitaet.

## 1. Problemstellung

Viele Gesellschaften stehen vor demografischem Druck und Fachkraeftemangel. Migration kann hier positive Wirkung entfalten. Ohne faire Arbeit, Qualifikationsanerkennung und Schutz entstehen jedoch Ausbeutung, Lohndruck und Vertrauensverlust. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Das Konzept verbindet Arbeitsmarktintegration mit Wirkungslogik, fairer Arbeit und demografischer Stabilitaet. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Demografischer Wandel

Sinkende Erwerbsbevoelkerung, Alterung und Fachkraefteluecken erzeugen Systemrisiken. Arbeitsmigration kann diese Risiken mindern, wenn sie fair und planbar gestaltet wird.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Anerkennung von Kompetenzen

Lange Anerkennungsverfahren verschwenden Wirkleistung. Schnelle, faire und qualitaetsgesicherte Anerkennung erhoeht Arbeitsmarktwirkung.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Faire Arbeit

Arbeit wirkt nur positiv, wenn sie menschenwuerdig ist. Niedriglohn, Scheinselbststaendigkeit, Abhaengigkeit vom Arbeitgeber und fehlende Beschwerdewege erzeugen negative Wirkung.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Ausbildung und Uebergaenge

Ausbildung ist ein zentraler Wirkpfad. Betriebe, Berufsschulen, Kammern und Kommunen muessen Uebergaenge koordinieren.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Arbeitsmarkt-Wirkungsmonitor

Der Monitor misst Anerkennungsdauer, Ausbildungszugang, Erwerbsintegration, faire Arbeitsbedingungen, Branchenbedarf, Schutz vor Ausbeutung und langfristige Stabilitaet.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Detailkonzept Bildung, Sprache und Wirkungskompetenz

## Zugang, Lernen, Medienkompetenz und demokratische Mündigkeit

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Bildung entscheidet ueber die langfristige Wirkung von Migration. Fehlender Sprachzugang, spaete Einschulung, Uebergangsbrueche und fehlende Medienkompetenz erzeugen Risiken fuer Teilhabe und Demokratie.

Das Konzept gestaltet Bildung als Integrations- und Wirkungskompetenzsystem.

## 1. Problemstellung

Bildung entscheidet ueber die langfristige Wirkung von Migration. Fehlender Sprachzugang, spaete Einschulung, Uebergangsbrueche und fehlende Medienkompetenz erzeugen Risiken fuer Teilhabe und Demokratie. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Das Konzept gestaltet Bildung als Integrations- und Wirkungskompetenzsystem. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Fruehe Bildung

Fruehe Bildung verbindet Sprache, soziale Sicherheit, Elternarbeit und Gesundheitszugang. Sie wirkt langfristig auf Schule, Ausbildung, Gesundheit und Zugehoerigkeit.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Sprache ohne Sanktionismus

Sprache ist Pflicht und Moeglichkeit zugleich. Politisch darf Sprachlernen nicht nur als Sanktion, sondern als Zugangsinfrastruktur organisiert werden.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Schule und Uebergaenge

Willkommensklassen, Regelklassen, Schulsozialarbeit, Elternarbeit und Uebergang in Ausbildung muessen zusammen gedacht werden.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Civic Literacy und Medienkompetenz

Demokratische Orientierung, Quellenklarheit, digitale Selbstbestimmung und Wirkungskompetenz schuetzen vor Desinformation und Polarisierung.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Bildungsindikatoren

Messpunkte sind Zugangszeiten, Sprachfortschritt, Schuluebergaenge, Abschlussquoten, Medienkompetenz, Elternbeteiligung und Beteiligung an lokalen Bildungsnetzwerken.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Detailkonzept Wohnen, Quartiere und Sozialraeume

## Sozialraum als Integrations- und Resilienzarchitektur

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Integration findet nicht abstrakt statt, sondern in Raeumen. Wohnraummangel, Segregation, Ueberbelegung, fehlende Gruenflaechen, schlechte Mobilitaet und mangelnde Beratung erzeugen Wirkungsrisiken.

Das Konzept verbindet Migration mit Wohnungsmarkt, Quartierswirkung und Sozialraumprofilen.

## 1. Problemstellung

Integration findet nicht abstrakt statt, sondern in Raeumen. Wohnraummangel, Segregation, Ueberbelegung, fehlende Gruenflaechen, schlechte Mobilitaet und mangelnde Beratung erzeugen Wirkungsrisiken. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Das Konzept verbindet Migration mit Wohnungsmarkt, Quartierswirkung und Sozialraumprofilen. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Wohnen als Integrationsbedingung

Ohne stabilen Wohnraum fehlen Sicherheit, Lernen, Gesundheit und Nachbarschaft. Ueberbelegung wirkt auf Stress, Konflikte und Bildung.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Segregation und Mischung

Soziale Mischung ist kein Selbstzweck. Entscheidend sind Zugang, Nachbarschaft, Infrastruktur, Schutz und Konfliktmoderation.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Sozialraumprofil

Das Sozialraumprofil misst Wohnen, Mobilitaet, Gruen, Hitze, Luft, Versorgung, Bildung, Sicherheit, Gesundheit, Teilhabe, Digitalzugang und Integrationswirkung.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Quartierszentren

Nachbarschaftszentren, Bibliotheken, Sportorte, Kulturorte, Familienzentren und Beratungsstellen erzeugen Resonanzraeume.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Zielkonflikte

Aufnahmefaehigkeit, Mietdruck, Klimaanpassung, soziale Mischung und Bestandsschutz muessen offen abgewogen werden.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Detailkonzept Gesundheit, Trauma und psychosoziale Stabilitaet

## Gesundheit als Voraussetzung gelingender Integration

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Migration und Flucht koennen mit Trauma, Verlust, Gewalt, Unsicherheit, Armut und Sprachbarrieren verbunden sein. Gesundheitliche Risiken bleiben oft unsichtbar und wirken dann in Bildung, Arbeit, Familie und Demokratie weiter.

Das Konzept macht Gesundheit und psychosoziale Stabilitaet zu Kernbestandteilen wirkungsorientierter Migrationspolitik.

## 1. Problemstellung

Migration und Flucht koennen mit Trauma, Verlust, Gewalt, Unsicherheit, Armut und Sprachbarrieren verbunden sein. Gesundheitliche Risiken bleiben oft unsichtbar und wirken dann in Bildung, Arbeit, Familie und Demokratie weiter. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Das Konzept macht Gesundheit und psychosoziale Stabilitaet zu Kernbestandteilen wirkungsorientierter Migrationspolitik. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Gesundheitszugang

Gesundheitszugang muss rechtlich, sprachlich, raeumlich und kulturell erreichbar sein. Fehlender Zugang erzeugt spaetere Kosten und Leid.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Traumaversorgung

Trauma ist kein Randthema. Unbehandelte Belastungen koennen Lernen, Arbeit, Familie und Vertrauen beeintraechtigen. Niedrigschwellige Versorgung ist Praevention.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Sprachmittlung

Ohne Sprachmittlung sinkt Behandlungsqualitaet. Sie ist medizinische Infrastruktur, nicht Luxus.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Frauen, Kinder und vulnerable Gruppen

Schwangerschaft, Gewaltschutz, Kinderschutz, Behinderung, Alter, queere Lebenslagen und psychische Belastungen brauchen gezielte Schutzpfade.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Gesundheitsindikatoren

Messpunkte sind Zugang, Wartezeiten, Sprachmittlung, Praevention, psychosoziale Angebote, Gewalt- und Kinderschutz sowie Schnittstellen zu Bildung und Wohnen.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Detailkonzept Diskurs, Medienframes und Polarisierung

## Migration als Resonanzthema und SDG+-Wirkungsfeld

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Migration ist ein stark emotionalisiertes Diskursfeld. Sprache, Bilder, Tonalitaet, Plattformlogik und politische Frames koennen Zugehoerigkeit, Angst, Misstrauen oder Entmenschlichung verstaerken. Wirkung entsteht haeufig zuerst als Wirkungspotenzial.

Das Konzept entwickelt eine diskurs- und medienbezogene Wirkungslogik ohne Zensur und ohne Wahrheitsmonopol.

## 1. Problemstellung

Migration ist ein stark emotionalisiertes Diskursfeld. Sprache, Bilder, Tonalitaet, Plattformlogik und politische Frames koennen Zugehoerigkeit, Angst, Misstrauen oder Entmenschlichung verstaerken. Wirkung entsteht haeufig zuerst als Wirkungspotenzial. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Das Konzept entwickelt eine diskurs- und medienbezogene Wirkungslogik ohne Zensur und ohne Wahrheitsmonopol. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Frames und Resonanz

Frames strukturieren Wahrnehmung. Begriffe, Bilder und Wiederholungen koennen Handlungsschwellen veraendern. Deshalb ist praezise Sprache ein Wirkungsfaktor.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Desinformation

Falsche oder verzerrte Informationen ueber Migration koennen Misstrauen, Hass und politische Destabilisierung erzeugen. Quellenklarheit und Korrekturfaehigkeit sind demokratische Infrastruktur.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Medienverantwortung

Journalismus muss Probleme benennen koennen, ohne Menschen zu entmenschlichen. Kontext, Daten, Stimmenvielfalt und Quellenklarheit verbessern Wirkung.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Plattformlogik

Algorithmische Verstaerkung kann Empoerung belohnen. Ein Diskursrisiko-Radar darf nicht zensieren, aber Risiken, Hassdichte und Polarisierung sichtbar machen.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Schutzmechanismen

Transparenz, Moderation, Medienkompetenz, Beschwerdewege, Faktenchecks und demokratische Streitkultur sind zentrale Hebel.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Detailkonzept Kommunale Integrationsarchitektur

## Steuerung, Finanzierung, Daten und Beteiligung in Staedten und Gemeinden

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Kommunen tragen viele Wirkungen von Migration, haben aber oft zu wenig Steuerungsdaten, Personal, Finanzierung und Entscheidungsspielraum. Dadurch entsteht Ueberlastung und Vertrauensverlust.

Das Konzept beschreibt eine kommunale Architektur, die Integration, Sozialraum, Daten, Beteiligung und Finanzierung verbindet.

## 1. Problemstellung

Kommunen tragen viele Wirkungen von Migration, haben aber oft zu wenig Steuerungsdaten, Personal, Finanzierung und Entscheidungsspielraum. Dadurch entsteht Ueberlastung und Vertrauensverlust. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Das Konzept beschreibt eine kommunale Architektur, die Integration, Sozialraum, Daten, Beteiligung und Finanzierung verbindet. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Integrationszentren

Kommunen brauchen klare Anlaufstellen, die Sprache, Wohnen, Arbeit, Gesundheit, Bildung, Recht und Teilgabe koordinieren.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Wirkungsbudgets

Geld sollte nach Wirkung, Bedarf und Sozialraumrisiko fliessen. Kommunen mit hoeherem Integrationsdruck brauchen verlaessliche Mittel.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Daten und Datenschutz

Kommunale Daten muessen Sozialraeume sichtbar machen, ohne Menschen zu stigmatisieren. Datenschutz, Transparenz und Beteiligung sind Pflicht.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Beteiligung

Buergerraete, Jugendraete, Migrant:innenorganisationen, Vereine, Schulen und Unternehmen muessen als Co-Akteure einbezogen werden.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Krisen- und Konfliktmoderation

Fruehwarnsysteme, Gemeinwesenarbeit, lokale Konfliktmoderation und digitale Diskursbeobachtung koennen Eskalation verhindern.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Wirkungsindikatoren Rang 15

## Migration und Vielfalt messbar machen, ohne Menschen zu bewerten

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## Datenquellen nach Ebene

### Bundesebene

Moegliche Quellen sind Bevoelkerungsstatistik, Asyl- und Migrationsstatistik, Arbeitsmarktstatistik, Bildungsstatistik, Gesundheitsdaten und Wohnungsmarktindikatoren. Externe Zahlen muessen vor Veroeffentlichung aktualisiert werden.

### Landesebene

Laenderdaten betreffen Schule, Polizei, Hochschulen, Gesundheitsstrukturen, Anerkennungsverfahren und Verwaltungskapazitaeten.

### Kommunale Ebene

Kommunale Daten betreffen Sozialraeume, Wartezeiten, Beratungszugang, Kita- und Schulplaetze, Wohnraum, Gesundheit, Konfliktlagen, Kultur- und Vereinszugang sowie Beteiligung.

## Mindestschutz

Alle Indikatoren muessen so gestaltet sein, dass sie keine Personenbewertung, keine Herkunftsgruppenbewertung und keine Stigmatisierung erzeugen. Die Wirkungsoekonomie bewertet Strukturen, nicht den Wert von Menschen.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.

## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Toolkarten Rang 15

## Beschreibung, Nutzen, Status und Links

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Toolkarte 1: Sozialraumprofil Migration und Vielfalt

Beschreibung: Bewertet kommunale Sozialraeume nach Wohnen, Bildung, Gesundheit, Sicherheit, Teilhabe, Integration, Diversitaetswirkung und digitalem Zugang.

Nutzen: Macht sichtbar, wo Integration gelingt und wo Ueberlastung, Segregation oder Infrastrukturdefizite entstehen.

Status: Demo in Vorbereitung

Link: /tools/sozialraumprofil-migration-vielfalt/

## Toolkarte 2: Integrations-Infrastruktur-Score

Beschreibung: Prueft, ob eine Kommune oder Region ueber tragfaehige Integrationsinfrastruktur verfuegt: Sprache, Bildung, Verwaltung, Wohnen, Gesundheit, Arbeit und Partizipation.

Nutzen: Macht Integration steuerbar, ohne Menschen zu bewerten. Bewertet werden Strukturen, Zugänge und Systemfaehigkeit.

Status: Demo in Vorbereitung

Link: /tools/integrations-infrastruktur-score/

## Toolkarte 3: Zugehoerigkeits- und Teilgabeindex

Beschreibung: Misst, ob Menschen Zugang zu Beteiligung, Vereinen, Kultur, Bildung, Arbeit und lokalen Entscheidungsprozessen haben.

Nutzen: Zeigt, ob Demokratie im Alltag erfahrbar wird.

Status: Demo in Vorbereitung

Link: /tools/zugehoerigkeit-teilgabeindex/

## Toolkarte 4: Diskursrisiko-Radar Migration

Beschreibung: Beobachtet oeffentliche Narrative, Feindseligkeit, Polarisierung, Desinformation und Diskursqualitaet im Themenfeld Migration.

Nutzen: Fruehwarnsystem gegen Eskalation, Stigmatisierung und demokratische Destabilisierung.

Status: Demo in Vorbereitung

Link: /tools/diskursrisiko-radar-migration/

## Toolkarte 5: Arbeitsmarkt-Wirkungsmonitor Migration

Beschreibung: Bewertet Fachkraefteintegration, Qualifikationsanerkennung, faire Arbeit, Schutz vor Ausbeutung und Uebergaenge in Ausbildung.

Nutzen: Verknuepft Arbeitsmarktpolitik mit Wirkung auf Fachkraeftesicherung, Teilhabe und soziale Stabilitaet.

Status: Demo in Vorbereitung

Link: /tools/arbeitsmarkt-wirkungsmonitor-migration/

## Toolkarte 6: Kommunale Integrationsarchitektur-Check

Beschreibung: Prueft, ob Kommunen ueber koordinierte Strukturen fuer Integration, Gemeinwesenarbeit, Konfliktmoderation, Beteiligung und Datenmonitoring verfuegen.

Nutzen: Unterstuetzt Staedte und Gemeinden bei der Planung wirkungsorientierter Integrationspolitik.

Status: Demo in Vorbereitung

Link: /tools/kommunale-integrationsarchitektur-check/




# Politische Anschlussfaehigkeit Rang 15

## Migration und Vielfalt

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# SDG- und SDG+-Block Rang 15

## Migration und Vielfalt

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.




# Quellen und Glossarlinks Rang 15

## Migration und Vielfalt

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.

## Glossarlinks fuer die Website

- Wirkung
- Wirkungspotenzial
- Wirkungsrisiko
- Wirkungsraum
- Wirkungsfeld
- Resonanzraum
- Wirkungsbewertung
- Netto-Wirkung
- Positive Netto-Wirkung
- Transformationswirkung
- Wirkungslenkung
- Wirkungsarchitektur
- Teilhabe
- Teilgabe
- SDG+
- Reverse Merit Order
- Nichtkompensationsprinzip
- Wirkungsrat
- Wirkungskompetenz


