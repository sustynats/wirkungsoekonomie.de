# Detailkonzept Gesundheit, Trauma und psychosoziale Stabilitaet

## Gesundheit als Voraussetzung gelingender Integration

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.
## Executive Summary

Migration und Flucht koennen mit Trauma, Verlust, Gewalt, Unsicherheit, Armut und Sprachbarrieren verbunden sein. Gesundheitliche Risiken bleiben oft unsichtbar und wirken dann in Bildung, Arbeit, Familie und Demokratie weiter.

Das Konzept macht Gesundheit und psychosoziale Stabilitaet zu Kernbestandteilen wirkungsorientierter Migrationspolitik.

## 1. Problemstellung

Migration und Flucht koennen mit Trauma, Verlust, Gewalt, Unsicherheit, Armut und Sprachbarrieren verbunden sein. Gesundheitliche Risiken bleiben oft unsichtbar und wirken dann in Bildung, Arbeit, Familie und Demokratie weiter. Die bisherige Debatte arbeitet haeufig mit Kategorien, die fuer oeffentliche Erregung geeignet sind, aber wenig Steuerungswissen erzeugen. Die Wirkungsoekonomie verlangt deshalb eine andere Prueffrage: Welche Zustaende veraendern sich, bei wem, in welchem Zeitraum, mit welchen Nebenwirkungen und unter welchen Mindestbedingungen?

## 2. Zielbild

Das Konzept macht Gesundheit und psychosoziale Stabilitaet zu Kernbestandteilen wirkungsorientierter Migrationspolitik. Das Zielbild ist kein Kontrollsystem ueber Menschen. Es ist eine Architektur fuer bessere Rueckkopplung. Politik, Verwaltung, Wirtschaft und Zivilgesellschaft sollen erkennen, welche Massnahmen Schutz, Moeglichkeit, Zugehoerigkeit und Stabilitaet erhoehen und welche Massnahmen Wirkungsrisiken erzeugen.

## 3. Wirkungslogik

Wirkungslogik bedeutet, eine Handlung nicht nur nach Absicht und Output zu betrachten. Entscheidend ist die Zustandsveraenderung. Direkte Wirkung, indirekte Wirkung und systemische Wirkung muessen getrennt werden. Eine Massnahme kann kurzfristig entlasten und langfristig neue Abhaengigkeit erzeugen. Sie kann lokal helfen und an anderer Stelle Ueberlastung verstaerken. Darum braucht jedes Detailkonzept Mindestbedingungen, Daten, Zielkonflikte und Korrekturschleifen.

## 4. Gesundheitszugang

Gesundheitszugang muss rechtlich, sprachlich, raeumlich und kulturell erreichbar sein. Fehlender Zugang erzeugt spaetere Kosten und Leid.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 5. Traumaversorgung

Trauma ist kein Randthema. Unbehandelte Belastungen koennen Lernen, Arbeit, Familie und Vertrauen beeintraechtigen. Niedrigschwellige Versorgung ist Praevention.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 6. Sprachmittlung

Ohne Sprachmittlung sinkt Behandlungsqualitaet. Sie ist medizinische Infrastruktur, nicht Luxus.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 7. Frauen, Kinder und vulnerable Gruppen

Schwangerschaft, Gewaltschutz, Kinderschutz, Behinderung, Alter, queere Lebenslagen und psychische Belastungen brauchen gezielte Schutzpfade.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 8. Gesundheitsindikatoren

Messpunkte sind Zugang, Wartezeiten, Sprachmittlung, Praevention, psychosoziale Angebote, Gewalt- und Kinderschutz sowie Schnittstellen zu Bildung und Wohnen.

Praktisch bedeutet das: Es braucht klare Verantwortlichkeiten, messbare Zugangsqualitaet, Schutz vor Diskriminierung, Beteiligung betroffener Gruppen und eine Evaluation, die nicht nur Zaehldaten, sondern Zustandsveraenderungen betrachtet.

## 9. Beispielhafte Berechnungslogik

Eine einfache Scorecard kann vier Ebenen pruefen: Zugang, Schutz, Teilgabe und Systemstabilitaet. Jede Ebene wird von -3 bis +3 bewertet. Die Bewertung erfolgt nicht als Durchschnitt, wenn rote Linien betroffen sind. Menschenwuerde, Kinderrechte, Schutz vor Gewalt, Schutz vor Ausbeutung, Rechtsstaatlichkeit und demokratische Stabilitaet sind Mindestbedingungen.

| Ebene | -3 | 0 | +3 |
|---|---|---|---|
| Zugang | systematisch blockiert | formal vorhanden | niedrigschwellig, erreichbar, wirksam |
| Schutz | Verletzung oder fehlender Schutz | Mindestschutz vorhanden | proaktiver Schutz und Beschwerdewege |
| Teilgabe | Ausschluss und Unsichtbarkeit | passive Teilnahme | aktive Mitgestaltung |
| Stabilitaet | Polarisierung oder Ueberlastung | keine klare Veraenderung | Vertrauen, Resilienz und Korrekturfaehigkeit steigen |


## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.
## Umsetzungspfad

1. Bestandsaufnahme bestehender Strukturen.
2. Auswahl von drei bis fuenf Pilotkommunen oder Pilotorganisationen.
3. Aufbau eines einfachen Wirkungsdashboards.
4. Beteiligung von Verwaltung, Zivilgesellschaft, Wirtschaft und betroffenen Menschen.
5. Jaehrliche Wirkungsberichte mit Korrekturmassnahmen.
6. Uebertragung erfolgreicher Muster auf weitere Sozialraeume.


## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.
