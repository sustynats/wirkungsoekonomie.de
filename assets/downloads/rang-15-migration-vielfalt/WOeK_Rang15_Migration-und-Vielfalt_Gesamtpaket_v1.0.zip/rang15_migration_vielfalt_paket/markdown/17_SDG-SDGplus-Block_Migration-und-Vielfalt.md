# SDG- und SDG+-Block Rang 15

## Migration und Vielfalt

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.
