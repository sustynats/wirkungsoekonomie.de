# Gesamtdossier Rang 15

## Migration und Vielfalt in der Wirkungsoekonomie

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Begriffsgrundlage

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt. In diesem Portal werden nicht Menschen bewertet, sondern Strukturen, Verfahren, Programme, Raeume, Produkte, Organisationen und politische Entscheidungen.

Positive Wirkung liegt vor, wenn eine Veraenderung auf SDGs, Agenda 2030 und SDG+ einzahlt. Negative Wirkung liegt vor, wenn eine Veraenderung diesen Rahmen schwaecht, blockiert oder zerstoert. Ziel der Wirkungsoekonomie ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Wirkungspotenzial ist noch keine eingetretene Wirkung. Gerade bei Migration, Medien, Sprache, Zugehoerigkeit und Diskurs entstehen zuerst Moeglichkeitsraeume, Erwartungen, Resonanz, Vertrauen oder Misstrauen. Erst wenn sich daraus reale Zustaende veraendern, wird von eingetretener Wirkung gesprochen.

SDG+ ist keine offizielle UN-Kategorie. SDG+ ist eine transparente Erweiterung der Wirkungsoekonomie fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## 1. Executive Summary

Migration und Vielfalt sind gesellschaftliche Wirkungsfelder. Sie veraendern Zustaende in Kommunen, Familien, Arbeitsmaerkten, Schulen, Hochschulen, Pflege, Gesundheit, Wohnen, Kultur, Medien, Recht, Sicherheit und Demokratie. Diese Veraenderungen koennen positiv, negativ oder ambivalent sein. Positive Netto-Wirkung entsteht nicht durch Migration an sich, sondern durch die Art, wie Schutz, Verfahren, Integration, Teilgabe, Arbeitsmarkt, Wohnraum, Gesundheit und Diskurs gestaltet werden.

Das Gesamtdossier ordnet Rang 15 als Fachportal. Es liefert eine Systemarchitektur fuer Website, Downloads, Langkonzepte, Toolkarten und politische Anschlussfaehigkeit. Es ersetzt keine demokratische Entscheidung. Es macht Wirkungen sichtbar und korrigierbar.

## 2. Ausgangslage

Migration wird oeffentlich haeufig als moralischer oder sicherheitspolitischer Konflikt diskutiert. Die Wirkungsoekonomie verschiebt den Blick. Sie fragt nicht zuerst, welche Identitaet jemand hat, sondern welche Strukturen entstehen: Zugang oder Ausschluss, Schutz oder Verletzlichkeit, Bildung oder Abbruch, faire Arbeit oder Ausbeutung, Zugehoerigkeit oder Misstrauen, demokratische Beteiligung oder Entfremdung.

Damit wird Migration als Rueckkopplung sichtbar. Sie zeigt globale Ungleichgewichte, demografische Verschiebungen, Klimarisiken, Kriege, Arbeitskraeftenachfrage, Bildungsungleichheit und Schutzdefizite. Sie zeigt aber auch, ob eine Gesellschaft neue Zugehoerigkeit ermoeglichen kann.

## 3. Wirkungsraeume

### 3.1 Kommune

Kommunen sind der Ort, an dem Migration praktisch wirkt. Hier entstehen Schulplaetze, Wohnraumbedarf, Nachbarschaften, Konflikte, Vereine, Sprachkurse, Beratungsstellen, Gesundheitszugang und lokale Demokratie. Kommunale Ueberlastung ist keine abstrakte Meinung, sondern ein messbarer Zustand. Wirkungsorientierte Politik darf sie nicht ignorieren. Sie muss sie sichtbar machen und finanzieren.

### 3.2 Arbeitsmarkt

Migration kann Fachkraeftebedarf mindern, demografische Stabilitaet erhoehen und Betriebe sichern. Sie kann aber auch Ausbeutung, Lohndruck und prekare Arbeit verstaerken, wenn Schutz, Anerkennung und Qualifizierung fehlen. Arbeitsmarktintegration muss deshalb fair, schnell, rechtsstaatlich und kompetenzorientiert sein.

### 3.3 Bildung und Sprache

Sprache ist Zugangsinfrastruktur. Sie darf nicht nur als Sanktionspunkt behandelt werden. Bildung ist der zentrale Wirkpfad fuer Teilgabe, Selbstwirksamkeit und demokratische Stabilitaet. Schulische Uebergaenge, Erwachsenenbildung, Sprachmittlung und Elternarbeit sind entscheidende Hebel.

### 3.4 Wohnen und Sozialraum

Wohnen entscheidet, ob Integration im Alltag moeglich wird. Ueberbelegung, Segregation, fehlende Verkehrsanbindung und angespannte Quartiere erzeugen Wirkungsrisiken. Gute Sozialraeume verbinden Wohnen, Bildung, Gruen, Mobilitaet, Beratung, Kultur, Gesundheit und Sicherheit.

### 3.5 Gesundheit und psychosoziale Stabilitaet

Migration kann mit Belastung, Flucht, Verlust, Trauma, Unsicherheit und Sprachbarrieren verbunden sein. Gesundheitssysteme muessen Schutz, Praevention, Sprachmittlung und psychische Gesundheit einbeziehen. Traumaversorgung ist nicht nur humanitaer wichtig, sondern auch gesellschaftliche Resilienzpolitik.

### 3.6 Demokratie und Diskurs

Migration ist ein Resonanzthema. Es kann Zugehoerigkeit, Lernfaehigkeit und Solidaritaet staerken. Es kann aber auch Angstnarrative, Feindbilder, Desinformation und Polarisierung ausloesen. Diskursqualitaet ist deshalb kein Nebenthema, sondern SDG+-relevant.

## 4. Wirkungslogik

Wirkung entsteht ueber Pfade. Ein Beispiel: Eine Kommune eroeffnet fruehe Sprachkurse. Direkte Wirkung ist besserer Zugang zu Sprache. Indirekte Wirkung kann schnellerer Bildungs- oder Arbeitsmarktzugang sein. Systemische Wirkung kann sinkende Abhaengigkeit, hoeheres Vertrauen und geringeres Konfliktrisiko sein. Negative Nebenwirkungen koennen entstehen, wenn Kurse schlecht erreichbar sind, Frauen mit Care-Verantwortung ausgeschlossen werden oder Menschen lange warten muessen.

Ein zweites Beispiel: Qualifikationsanerkennung wird beschleunigt. Direkte Wirkung ist schnellerer Berufszugang. Indirekte Wirkung sind mehr Fachkraefte und hoehere Selbstwirksamkeit. Systemische Wirkung kann eine stabilere kommunale Wirtschaft sein. Risiken entstehen, wenn Anerkennung ohne Sprachbegleitung, Arbeitsschutz oder faire Vermittlung erfolgt.

## 5. Nichtkompensation und rote Linien

Positive Arbeitsmarktwirkung darf nicht Ausbeutung kompensieren. Kulturelle Vielfalt darf nicht Rechtsstaatsverletzung verdecken. Schnelle Verfahren duerfen nicht faire Verfahren ersetzen. Hohe Fachkraeftewirkung darf Schutzbeduerftigkeit nicht entwerten. Gewalt, Kinderrechtsverletzungen, Menschenhandel, Zwang, Diskriminierung und Entwuerdigung sind Wirkungsgrenzen.

## 6. Fachunterbereiche

### Migration als Wirkungsfeld

Migration ist Bewegung und Rueckkopplung. Sie zeigt, wo Lebensbedingungen nicht tragen, wo Schutz gebraucht wird und wo Arbeitsmaerkte Menschen brauchen. Sie muss differenziert betrachtet werden: Flucht, Arbeitsmigration, Familienmigration, Bildungsmigration, Binnenmobilitaet, temporäre Migration und zirkulaere Migration erzeugen unterschiedliche Wirkpfade.

### Integration als Infrastruktur

Integration gelingt dort, wo Systeme faehig sind, Zugang zu organisieren. Integrationsinfrastruktur besteht aus Sprache, Bildung, Arbeit, Wohnen, Gesundheit, Verwaltung, Rechtsschutz, Kultur, Begegnung und Beteiligung.

### Vielfalt als Resilienzfaktor

Vielfalt kann Perspektiven erhoehen, Innovation beguenstigen und Monokulturen verhindern. Resilienz entsteht aber nur, wenn Vielfalt in gemeinsame Regeln, faire Chancen und Zugehoerigkeit eingebettet ist.

### Zugehoerigkeit und Teilgabe

Zugehoerigkeit ist nicht identisch mit Assimilation. Sie entsteht, wenn Menschen sicher sind, gehoert werden, Verantwortung uebernehmen koennen und sich als Teil eines gemeinsamen demokratischen Raums erfahren.

### Diskurs und Medien

Medien und Plattformen formen Wirkungsraeume. Migration kann durch Quellenklarheit, Kontext und Wuerde berichtet werden. Sie kann aber auch durch Feindbilder, Schlagworte und algorithmische Verstaerkung polarisiert werden.

## 7. Daten- und Toolarchitektur

Das Portal enthaelt sechs Tools: Sozialraumprofil Migration und Vielfalt, Integrations-Infrastruktur-Score, Zugehoerigkeits- und Teilgabeindex, Diskursrisiko-Radar, Arbeitsmarkt-Wirkungsmonitor und Kommunale Integrationsarchitektur-Check. Diese Tools bewerten keine Menschen. Sie bewerten Strukturen und Raeume.

## Indikatoren und Bewertungslogik

Die Indikatoren dienen nicht der Bewertung einzelner Menschen. Sie dienen der Bewertung von Strukturen, Verfahren, Programmen, Organisationen und Sozialraeumen. Jeder Indikator braucht Datenquelle, Zeitraum, Bezugsebene, Interpretationsgrenze und Schutzregel gegen Stigmatisierung.

| Indikatorfamilie | Leitfrage | Beispielhafte Messpunkte | Schutzregel |
|---|---|---|---|
| Schutz und Rechtsstaat | Werden Menschen rechtsstaatlich, sicher und wuerdevoll behandelt? | Verfahrensdauer, Zugang zu Beratung, Schutz vor Gewalt, Beschwerdewege | Keine Bewertung nach Herkunft oder Religion |
| Sprache und Bildung | Entstehen reale Zugangswege? | Kurszugang, Wartezeiten, Abschlussquoten, Uebergang Schule-Beruf | Kontextdaten statt Schuldzuweisung |
| Arbeit und Qualifikation | Wird Teilgabe am Arbeitsmarkt moeglich? | Anerkennungsdauer, Ausbildungszugang, faire Arbeit, Schutz vor Ausbeutung | Keine Abwertung unbezahlter Care-Arbeit |
| Wohnen und Sozialraum | Traegt der Raum Integration? | Mietbelastung, Segregation, Zugang zu Gruen, Kitas, Verkehr, Beratung | Sozialraum bewerten, nicht Bewohnergruppen |
| Gesundheit und Stabilitaet | Werden Koerper und Psyche geschuetzt? | Gesundheitszugang, Traumaversorgung, Sprachmittlung, Praevention | Gesundheitsdaten besonders schuetzen |
| Teilgabe und Zugehoerigkeit | Wird Demokratie im Alltag erfahrbar? | Beteiligung, Vereine, Kultur, lokale Gremien, Vertrauen | Keine Gesinnungsmessung |
| Diskurs und Medien | Wird oeffentliche Resonanz stabilisiert? | Hassdichte, Desinformation, Quellenklarheit, Polarisierungsrisiken | Keine Zensur, transparente Kriterien |

### Scorelogik

Eine einfache Einstiegslogik arbeitet mit sieben Stufen von -3 bis +3. -3 beschreibt hoch schaedliche oder entwuedernde Systemwirkung, -2 erhebliche Belastung, -1 erkennbare negative Wirkung, 0 neutrale oder nicht belegte Wirkung, +1 gute Wirkung, +2 sehr gute Wirkung und +3 transformative Wirkung. Kritische rote Linien wie Menschenwuerde, Gewalt, Kinderrechte, Ausbeutung, Rechtsstaatsverletzung und demokratische Destabilisierung duerfen nicht durch gute Werte an anderer Stelle aufgerechnet werden.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.

## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.
