# Politische Anschlussfaehigkeit Rang 15

## Migration und Vielfalt

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026


## Politische Anschlussfaehigkeit und Umsetzungsoptionen

### Aufgabe der Politik

Die Aufgabe der Politik besteht nicht darin, Migration oder Vielfalt pauschal als gut oder schlecht zu etikettieren. Aufgabe der Politik ist es, Rahmenbedingungen zu schaffen, unter denen Schutz, Rechtsstaat, Integration, Teilgabe, kommunale Stabilitaet und gesellschaftliche Resilienz gelingen koennen. Die Wirkungsoekonomie liefert dafuer einen Bewertungs- und Steuerungsrahmen. Sie ist kein fertiges Parteiprogramm.

### Politische Rahmenbedingungen

Politische Rahmenbedingungen umfassen faire und schnelle Verfahren, rechtssichere Entscheidungen, kommunale Finanzierung, Sprach- und Bildungszugang, Arbeitsmarktintegration, Schutz vor Ausbeutung, Antidiskriminierung, sichere Unterbringung, Gesundheitszugang, Konfliktmoderation, demokratische Beteiligung und transparente Daten.

### Ausgestaltungsspielraum

Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Schwerpunkte bei Arbeitsmigration, Flucht, Familiennachzug, Rueckkehrpolitik, kommunaler Finanzierung, Qualifikationsanerkennung, Staatsangehoerigkeitsrecht, Sicherheit, Integrationspflichten und Beteiligungsformaten setzen. Wirkungsorientiert ist eine Politik nicht deshalb, weil sie eine bestimmte parteipolitische Linie verfolgt, sondern weil sie ihre Folgen sichtbar macht, Zielkonflikte offenlegt und Korrektur ermoeglicht.

### Zielkonflikte

Zu pruefen sind Zielkonflikte zwischen Schutzbeduerftigkeit und Steuerungsfaehigkeit, Aufnahmebereitschaft und kommunalen Belastungsgrenzen, Fachkraeftebedarf und Brain Drain, schneller Integration und Verwaltungsrealitaet, Sicherheit und Grundrechten, Diskursfreiheit und Schutz vor Hass, kultureller Vielfalt und gemeinsamen Rechtsgrundlagen sowie Wohnraummangel und Aufnahmefaehigkeit.

### Rollenverteilung

Der Bund gestaltet Rechtsrahmen, Finanzierung, Verfahren und Arbeitsmarktregeln. Laender verantworten Bildung, Verwaltung, Polizei, Hochschulen und Teile der Gesundheitsstruktur. Kommunen gestalten Sozialraum, Wohnen, Integration, Beteiligung und Gemeinwesenarbeit. Wirtschaft schafft faire Arbeit und Ausbildung. Zivilgesellschaft ermoeglicht Begegnung und Beratung. Medien schuetzen Quellenklarheit und Diskursqualitaet. Wissenschaft evaluiert. Betroffene Menschen sind nicht nur Zielgruppe, sondern Co-Autorinnen und Co-Autoren gelingender Integration.

### Evaluation und Korrektur

Evaluation prueft regelmaessig, ob Teilhabe steigt, kommunale Ueberlastung sinkt, Sprach- und Bildungszugang besser werden, Arbeitsmarktintegration gelingt, vulnerable Gruppen geschuetzt werden, Ausbeutung abnimmt, institutionelles Vertrauen waechst, Polarisierung sinkt und Fluchtursachen langfristig adressiert werden. Ergebnisse muessen oeffentlich, verstaendlich und korrigierbar sein.

### Schutz vor Technokratie

Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie macht Folgen sichtbar. Bewertet werden Strukturen und Programme, nicht Menschen. Es braucht Datenschutz, Betroffenenbeteiligung, Widerspruchsmoeglichkeiten, unabhaengige Evaluation, methodische Transparenz und klare Grenzen gegen Personenbewertung, Social-Credit-Logik und Herkunftsstigmatisierung.

## SDG- und SDG+-Bezug

### Relevante SDGs

- SDG 1 - Keine Armut: Schutz vor Armut, Vermeidung prekaerer Lebenslagen, Zugang zu sozialen Sicherungssystemen.
- SDG 3 - Gesundheit und Wohlergehen: Gesundheitszugang, Traumaversorgung, Praevention, psychosoziale Stabilitaet.
- SDG 4 - Hochwertige Bildung: Sprache, Schule, Ausbildung, Erwachsenenbildung, Wirkungskompetenz.
- SDG 5 - Geschlechtergleichstellung: Schutz von Frauen und Maedchen, Zugang zu Bildung und Arbeit, Schutz vor Gewalt.
- SDG 8 - Menschenwuerdige Arbeit: faire Beschaeftigung, Schutz vor Ausbeutung, Anerkennung von Kompetenzen.
- SDG 10 - Weniger Ungleichheiten: Abbau struktureller Barrieren, Antidiskriminierung, gleiche Chancen.
- SDG 11 - Nachhaltige Staedte und Gemeinden: Wohnen, Quartiere, Sozialraeume, kommunale Infrastruktur.
- SDG 16 - Frieden, Gerechtigkeit und starke Institutionen: Rechtsstaat, faire Verfahren, institutionelles Vertrauen.
- SDG 17 - Partnerschaften: Kooperation zwischen Bund, Laendern, Kommunen, Zivilgesellschaft, Wirtschaft, Wissenschaft und internationalen Akteuren.

### SDG+-Dimensionen

- Demokratiequalitaet
- Medienqualitaet
- Rechtsstaatlichkeit
- Diskursfaehigkeit
- institutionelles Vertrauen
- gesellschaftlicher Zusammenhalt
- digitale Selbstbestimmung
- Schutz vor Desinformation
- Schutz vor algorithmischer Polarisierung
- Narrativpluralitaet

## Quellenrahmen und Anschlussdokumente

### Interne Referenzen der Wirkungsoekonomie

- Fuehrender Begriffsleitfaden der Wirkungsoekonomie, Version 1.0, Stand 21. Mai 2026.
- Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, insbesondere Kapitel 73 zu Migration und gesellschaftlicher Zugehoerigkeit.
- Systemmodell der Wirkungsoekonomie, Ordnungskarte Mensch, Planet und Demokratie.
- Working-Paper Wirkungssteuergesetz und Wirkungsarchitektur.
- Portallogik der Wirkungsoekonomie fuer Online-Volltexte, Downloads, Toolkarten, SDG-/SDG+-Bloecke und politische Anschlussfaehigkeit.

### Externe Anschlussquellen

- Vereinte Nationen: Agenda 2030 und Sustainable Development Goals.
- International Organization for Migration: World Migration Report.
- UNHCR: Global Trends und Daten zu Flucht und Vertreibung.
- Statistisches Bundesamt: Daten zu Migration, Bevoelkerung, Arbeitsmarkt, Bildung, Wohnen und Gesundheit.
- BAMF: Forschung zu Migration, Integration und Asyl sowie Integrationskurse.
- OECD und Europaeische Kommission: Indicators of Immigrant Integration.
- Kommunale Sozialberichterstattung, Bildungsberichte, Gesundheitsberichte und Wohnungsmarktberichte.

Hinweis: Fuer oeffentliche Endfassungen muessen externe Zahlen jeweils vor Veroeffentlichung aktualisiert und mit Abrufdatum dokumentiert werden.
