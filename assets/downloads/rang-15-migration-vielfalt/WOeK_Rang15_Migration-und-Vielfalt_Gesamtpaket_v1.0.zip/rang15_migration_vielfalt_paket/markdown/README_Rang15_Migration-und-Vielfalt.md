# ZIP-Paket Rang 15 - Migration und Vielfalt

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Status: Entwurf fuer Website, Akademie, Portal und Download
Stand: 24. Mai 2026

Dieses Paket enthaelt die Arbeits- und Downloadstruktur fuer Rang 15 der Wirkungsoekonomie: Migration und Vielfalt.

## Ordner

- markdown: redaktionelle Quelltexte und Online-Volltextgrundlagen
- pdf: PDF-Downloads im Corporate-Design-Grundlayout der Wirkungsoekonomie
- onlinefassungen: HTML-Seiten fuer Website-Onlinefassungen
- daten: JSON-Index und Toolkarten

## Enthaltene Hauptbausteine

- Bestands- und Nachlieferliste
- Portalstartseite
- Konzeptpapier
- Gesamtdossier
- zehn Detailkonzepte im Langfassungsentwurf
- Wirkungsindikatoren
- Toolkarten
- SDG- und SDG+-Block
- Politische Anschlussfaehigkeit
- Quellen und Glossarlinks

## Qualitaetshinweis

Die Texte sind als veroeffentlichungsnahe Entwuerfe angelegt. Vor Livegang sollten externe Zahlen, URLs und Quellen mit Abrufdatum aktualisiert werden. Der Begriffsleitfaden vom 21. Mai 2026 bleibt fuehrend.
