# Konzeptpapier Rang 17

## Digitalisierung, KI und Wirkungsdatenräume

**Autorin:** Natalie Weber  
**Referenz:** Wirkungsökonomie  
**Version:** 1.0  
**Stand:** Mai 2026  
**Status:** Langfassungsentwurf

## Kurzfassung
Konzeptpapier im Dossier-Niveau

## Inhaltsverzeichnis
1. Executive Summary
2. Warum Rang 17 nötig ist
3. Maßstabskrise der Digitalisierung
4. Leitthese
5. Architekturmodell
6. Daten von Berichten zu Entscheidungen
7. Digital Product Passport
8. Wirkungsdatenräume
9. KI-Governance
10. Algorithmische Fairness
11. Cyberresilienz
12. Plattformlogik
13. Wirkungsscanner
14. Datenqualität und Assurance
15. Politische Anschlussfähigkeit
16. Umsetzungspfad
17. Zielkonflikte
18. SDG-/SDG+-Bezug
19. Quellenrahmen
20. Fachunterbereich: Digitale Produktpässe als Produktgedächtnis
21. Fachunterbereich: Wirkungsdatenräume
22. Fachunterbereich: KI-Governance
23. Fachunterbereich: Algorithmische Fairness und digitale Rechte
24. Fachunterbereich: Digitale Souveränität
25. Fachunterbereich: Cyberresilienz der Wirkungsarchitektur
26. Fachunterbereich: Plattformlogik und Resonanzräume
27. Fachunterbereich: Wirkungsscanner und Bürger:innen-Instrumente
28. Fachunterbereich: Interoperabilität, Register und Schnittstellen
29. Fachunterbereich: Audit, Assurance und Datenqualität

## 1. Executive Summary

Wirkung wird in diesem Portal neutral und relational verwendet. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Digitalisierung, KI und Datenräume werden deshalb nicht nach Neuheitsgrad, Marktwert oder Geschwindigkeit bewertet, sondern danach, ob sie bessere Wahrnehmung, Rückkopplung, Lernfähigkeit, Rechtsschutz, Transparenz und demokratische Kontrolle ermöglichen.

Das Konzeptpapier zeigt, warum Digitalisierung in der Wirkungsökonomie nicht zuerst als Effizienzprogramm verstanden wird. Ein schlechter analoger Prozess bleibt auch digital ein schlechter Prozess. Eine digitale Verwaltung ohne bessere Datenlogik erzeugt nur schnellere Blindleistung. KI ohne Verantwortungsarchitektur automatisiert Fehler. Produktpässe ohne Validierung werden zu neuen Etiketten. Datenräume ohne Rechte werden zu Machtkonzentration. Der entscheidende Maßstab lautet: Verbessert Digitalisierung Wahrnehmung, Rückkopplung, Lernfähigkeit, Rechtsschutz und demokratische Kontrolle?


## 2. Warum Rang 17 nötig ist

Die Wirkungsökonomie kann nicht allein analog funktionieren. Wenn Wirkung sichtbar, vergleichbar, prüfbar und rückkoppelbar werden soll, braucht sie digitale Strukturen. Dazu gehören Datenräume, Schnittstellen, Register, Produktpässe, KI-Governance, algorithmische Fairness, digitale Rechte, Cyberresilienz und Interoperabilität. Ohne diese Infrastruktur bleibt Wirkung in Berichten stecken. Mit ihr kann Wirkung in Entscheidungen zurückkehren.


## 3. Maßstabskrise der Digitalisierung

Viele Digitalisierungsprojekte messen Erfolg an Anzahl der Nutzer:innen, eingesparter Zeit, Automatisierungsgrad, Datenmenge oder Kostenreduktion. Diese Größen sind nicht wertlos, aber sie messen nicht automatisch Wirkung. Ein System kann schnell, günstig und digital sein und trotzdem Menschen ausschließen, falsche Daten verstärken, demokratische Kontrolle schwächen oder neue Abhängigkeiten schaffen.


## 4. Leitthese

Digitalisierung ist das Nervensystem der Wirkungsökonomie. Ein Nervensystem erzeugt nicht selbst Sinn. Es nimmt Zustände wahr, überträgt Signale, ermöglicht Reaktionen und macht Lernen möglich. Digitale Infrastrukturen sollen Wirkung nicht ersetzen, sondern wahrnehmbar, prüfbar, versionierbar und entscheidungsrelevant machen.


## 5. Architekturmodell

Die Architektur besteht aus fünf Schichten: Wirkungsdaten, Identitäten und Register, Anwendungen, Governance und Rückkopplung. Wirkungsdaten umfassen Messwerte, Qualitätsklassen, Quellen und Unsicherheiten. Identitäten und Register umfassen WÖk-IDs, Produkt-IDs, Prüfstatus und Signaturen. Anwendungen umfassen DPP-Viewer, Wirkungsscanner, KI-Audit und Plattformradar. Governance umfasst Rechte, Rollen, Haftung und Widerspruch. Rückkopplung betrifft Preise, Steuern, Beschaffung, Kapitalzugang, Versicherung, Förderung und politische Evaluation.


## 6. Daten von Berichten zu Entscheidungen

Heute liegen viele Nachhaltigkeits- und Wirkungsdaten in Berichten, Fragebögen, Audits, Zertifikaten, Tabellen und Datenbanken. Sie sind vorhanden, aber nicht entscheidungsrelevant genug. Die WÖk verschiebt die Frage: Nicht nur was wurde offengelegt, sondern welche Entscheidung muss sich dadurch verändern? Diese Verschiebung macht Daten zu Steuerungsdaten.


## 7. Digital Product Passport

Der DPP ist kein Marketingetikett. Er ist das Produktgedächtnis einer Wirkungskette. Er muss Rohstoffe, Herstellung, Transport, Nutzung, Reparatur, Wiederverwendung, Recycling und Ende lesbar machen. Für die Wirkungsökonomie wird er erst wertvoll, wenn er mit WÖk-IDs, Scorecards, Datenqualitätsklassen, Zugriffsrechten und Wirkungsscanner verbunden wird.


## 8. Wirkungsdatenräume

Ein Wirkungsdatenraum ist kein zentraler Datenspeicher. Er ist eine föderierte Infrastruktur aus Standards, Rollen, Rechten, Schnittstellen, Nachweisen, Prüfwegen und Datenqualitätsklassen. Er verbindet Daten, ohne Datenmacht zentral zu monopolisieren. Bürger:innen brauchen verständliche Ergebnisinformationen, Prüfer:innen Nachweise, Unternehmen Lieferkettendaten, Banken Risikodaten, Verwaltungen Steuerungsdaten und Wissenschaft Forschungszugänge.


## 9. KI-Governance

KI ist Werkzeug, nicht Akteur. Sie kann Wirkung sichtbar machen, Zusammenhänge analysieren, Prüfprozesse unterstützen und Frühwarnsignale erkennen. Sie darf aber nicht die Hoheit über Wirkungslogik, Bewertungsmaßstäbe oder demokratische Entscheidungen übernehmen. WÖk-IDs, Benchmarks, Reverse Merit Order, Nichtkompensation und Datenqualitätsklassen müssen öffentlich, versioniert, überprüfbar und anfechtbar bleiben.


## 10. Algorithmische Fairness

Algorithmische Fairness bedeutet nicht nur technische Entbiasung. Sie umfasst Zugang, Erklärbarkeit, Widerspruch, Nichtdiskriminierung, Datenminimierung, Zweckbindung, Menschenaufsicht, Fehlerkorrektur und Schutz vor verdeckter Sortierung. Faire Algorithmen müssen nicht nur statistisch funktionieren. Sie müssen in ihren Wirkungen auf Mensch, Planet und Demokratie verantwortbar sein.


## 11. Cyberresilienz

Wenn Produktpässe, Wirkungsdatenräume, Steuerlogiken, Register, Beschaffung, Kapitalmarkt, Versicherung und Verwaltung digital verbunden werden, wird Cyberresilienz selbst zur Wirkungsbedingung. Manipulierte Daten können falsche Preise, falsche Steuern, falsche Investitionen und falsche politische Bewertungen erzeugen. Cyberresilienz schützt Vertrauen, Verwaltung, Märkte und demokratische Handlungsfähigkeit.


## 12. Plattformlogik

Plattformen sind nicht nur private Marktplätze. Sie sind Resonanzräume. Ihre Reichweitenlogiken verändern Aufmerksamkeit, Vertrauen, Sprache, Zugehörigkeit, Feindbilder, Polarisierung und politische Handlungsfähigkeit. Rang 17 muss deshalb Plattformlogik als Wirkungsarchitektur erfassen: Welche Inhalte werden verstärkt? Welche Korrekturwege gibt es? Wie wird Desinformation begrenzt, ohne legitime Debatte zu unterdrücken?


## 13. Wirkungsscanner

Der Wirkungsscanner macht komplexe Daten alltagstauglich. Er darf Menschen nicht überwachen und keine private Lebensführung bewerten. Er übersetzt Produktdaten, Scorecards, Unsicherheiten und Verbesserungsoptionen in verständliche Signale. Er dient Verbraucher:innen, öffentlicher Beschaffung, Unternehmen und Bildung.


## 14. Datenqualität und Assurance

Datenqualität ist der Schutz vor Wirkungssimulation. Jede Zahl braucht Herkunft, Aktualität, Prüftiefe, Unsicherheitsklasse, Verantwortlichkeit und Korrekturweg. Ungeprüfte Daten dürfen nicht so wirken wie geprüfte Daten. Fehlende Daten dürfen nicht automatisch zu besseren Bewertungen führen.


## 15. Politische Anschlussfähigkeit

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext und keine technokratische Steuerungsmaschine. Sie liefert einen Bewertungs- und Steuerungsrahmen. Parteien, Parlamente, Verwaltungen, Unternehmen und Zivilgesellschaft behalten Ausgestaltungsspielraum. Entscheidend ist, ob digitale Regeln, KI-Systeme, Datenräume, Plattformen und Produktpässe überprüfbar positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugen. Digitale Wirkungssteuerung darf keine private Lebensführung überwachen, keine Menschen klassifizieren, keine Gesinnung messen und keine Social-Credit-Logik erzeugen. Bewertet werden Produkte, Organisationen, Systeme, Prozesse, Kapitalflüsse, öffentliche Maßnahmen und Infrastrukturen. Wo Menschen betroffen sind, gelten Datenschutz, Rechtsschutz, Widerspruch, Transparenz und menschliche Entscheidungspflicht.


## 16. Umsetzungspfad

Die Einführung beginnt mit Pilotbereichen, in denen Datenanschluss und politischer Nutzen hoch sind: DPP-pflichtige Produktgruppen, öffentliche Beschaffung, kommunale Energie- und Gebäudedaten, Förderprogramme, Lieferketten und kritische Infrastrukturen. Jede Pilotierung braucht Nebenwirkungsanalyse, Datenschutzprüfung, Nutzerfeedback, Wirkungsindikatoren, Fehlerkorrektur und jährliche Evaluation.


## 17. Zielkonflikte

Zielkonflikte bleiben: Transparenz vs. Geschäftsgeheimnis, Datenzugang vs. Datenschutz, Automatisierung vs. Rechtsschutz, Innovation vs. Vorsorge, Plattformfreiheit vs. Schutz vor Desinformation, Produkttransparenz vs. Belastung kleiner Unternehmen, Cybersecurity vs. Usability. Die WÖk löst diese Zielkonflikte nicht automatisch. Sie macht sie sichtbar und demokratisch bearbeitbar.


## 18. SDG-/SDG+-Bezug

Rang 17 verbindet besonders SDG 4, SDG 8, SDG 9, SDG 10, SDG 12, SDG 13, SDG 16 und SDG 17. Digitalisierung kann Bildung, Arbeit, Infrastruktur, nachhaltige Produktion, Klimatransparenz, starke Institutionen und Partnerschaften unterstützen. Dieselben Systeme können diese Ziele aber auch schwächen, wenn sie Ausschluss, Überwachung, Desinformation, Machtkonzentration, Energieverschwendung oder manipulative Plattformlogiken verstärken. SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt, digitale Selbstbestimmung, algorithmische Fairness und Schutz vor Desinformation.


## 19. Quellenrahmen

Der externe Anschlussrahmen umfasst den EU AI Act, den Digital Product Passport im Rahmen der ESPR, Data Act, Data Governance Act, Cyber Resilience Act, NIST AI RMF, NIST Cybersecurity Framework 2.0 und die UN Agenda 2030. Diese Quellen liefern regulatorische, technische und normative Anschlussstellen. Sie ersetzen nicht die Wirkungslogik, sondern werden in der Wirkungsökonomie als Daten-, Rechts- und Governance-Bezugspunkte genutzt.


## 20. Fachunterbereich: Digitale Produktpässe als Produktgedächtnis

DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Produkttransparenz entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung braucht Produkttransparenz eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Produkttransparenz dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 21. Fachunterbereich: Wirkungsdatenräume

Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Datenrückkopplung entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit braucht Datenrückkopplung eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Datenrückkopplung dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 22. Fachunterbereich: KI-Governance

KI als Werkzeug der Wirkung, nicht als neuer Kompass muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Verantwortung entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für KI als Werkzeug der Wirkung, nicht als neuer Kompass braucht Verantwortung eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu KI als Werkzeug der Wirkung, nicht als neuer Kompass. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Verantwortung dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für KI als Werkzeug der Wirkung, nicht als neuer Kompass sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 23. Fachunterbereich: Algorithmische Fairness und digitale Rechte

Schutz vor Sortierung, Ausschluss und Manipulation muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Fairness entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Schutz vor Sortierung, Ausschluss und Manipulation braucht Fairness eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Schutz vor Sortierung, Ausschluss und Manipulation. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Fairness dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Schutz vor Sortierung, Ausschluss und Manipulation sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 24. Fachunterbereich: Digitale Souveränität

Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Souveränität entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume braucht Souveränität eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Souveränität dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 25. Fachunterbereich: Cyberresilienz der Wirkungsarchitektur

Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Resilienz entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung braucht Resilienz eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Resilienz dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 26. Fachunterbereich: Plattformlogik und Resonanzräume

Digitale Öffentlichkeit als Wirkungsraum muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Diskursqualität entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Digitale Öffentlichkeit als Wirkungsraum braucht Diskursqualität eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Digitale Öffentlichkeit als Wirkungsraum. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Diskursqualität dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Digitale Öffentlichkeit als Wirkungsraum sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 27. Fachunterbereich: Wirkungsscanner und Bürger:innen-Instrumente

Produktwirkung verständlich machen ohne private Lebensführung zu überwachen muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Verständlichkeit entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Produktwirkung verständlich machen ohne private Lebensführung zu überwachen braucht Verständlichkeit eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Produktwirkung verständlich machen ohne private Lebensführung zu überwachen. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Verständlichkeit dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Produktwirkung verständlich machen ohne private Lebensführung zu überwachen sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 28. Fachunterbereich: Interoperabilität, Register und Schnittstellen

Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Anschlussfähigkeit entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen braucht Anschlussfähigkeit eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Anschlussfähigkeit dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 29. Fachunterbereich: Audit, Assurance und Datenqualität

Schutz vor Wirkungssimulation und Scheingenauigkeit muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Prüfbarkeit entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Schutz vor Wirkungssimulation und Scheingenauigkeit braucht Prüfbarkeit eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Schutz vor Wirkungssimulation und Scheingenauigkeit. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Prüfbarkeit dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Schutz vor Wirkungssimulation und Scheingenauigkeit sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## Quellen und Anschlussstellen
### Interne Quellen
- Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands. Das Standardwerk der Wirkungsökonomie, Manuskriptfassung 2026, Teil XIII - Digitalisierung, KI und Wirkungsdatenräume.
- Natalie Weber: Systemmodell der Wirkungsökonomie. Die systemische Ordnungskarte Mensch-Planet-Demokratie, 2025.
- Natalie Weber: Technische Leitlinien zum Wirkungssteuergesetz (WUStG), Vollversion Extended, August 2025.
- Natalie Weber: WP Produkte - Produktbesteuerung durch Wirkung, 2025.
- Natalie Weber: Wirkungsoekonomie in der Lieferkette, September 2025.
### Externe Anschlussstellen
- European Commission: AI Act - Shaping Europe's digital future. Offizielle Informationen zum EU AI Act, Inkrafttreten 1. August 2024, stufenweise Anwendung bis 2026 und GPAI-Pflichten ab 2025.
- European Commission: Digital Product Passport unter der Ecodesign for Sustainable Products Regulation (ESPR), Informationen 2024/2025.
- EUR-Lex: Regulation (EU) 2023/2854 - Data Act, harmonised rules on fair access to and use of data.
- EUR-Lex: Regulation (EU) 2022/868 - Data Governance Act, European data governance and common European data spaces.
- EUR-Lex: Regulation (EU) 2024/2847 - Cyber Resilience Act, horizontal cybersecurity requirements for products with digital elements.
- NIST: Artificial Intelligence Risk Management Framework, 2023; NIST Cybersecurity Framework 2.0, 2024.
- United Nations: Transforming our world - The 2030 Agenda for Sustainable Development and Sustainable Development Goals.