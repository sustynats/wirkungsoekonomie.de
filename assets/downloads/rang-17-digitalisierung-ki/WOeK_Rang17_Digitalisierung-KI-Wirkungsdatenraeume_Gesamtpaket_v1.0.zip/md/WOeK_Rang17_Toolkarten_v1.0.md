# Toolkarten Rang 17

## Digitale Werkzeuge der Wirkungsökonomie

**Autorin:** Natalie Weber  
**Referenz:** Wirkungsökonomie  
**Version:** 1.0  
**Stand:** Mai 2026  
**Status:** Entwurf

## Kurzfassung
Toolkarten

## Inhaltsverzeichnis
1. Toolkarten
2. Wirkungsdatenraum-Explorer
3. DPP-Viewer
4. KI-Impact-Audit
5. Plattform-Wirkungsradar
6. Cyberresilienz-Check
7. Algorithmic-Fairness-Scanner
8. Wirkungsscanner für Produkte
9. Lieferketten-Wirkungsmonitor

## 1. Toolkarten

Die Toolkarten beschreiben erste Anwendungen. Sie sind als Demo in Vorbereitung zu kennzeichnen, solange keine produktive Implementierung existiert.


## 2. Wirkungsdatenraum-Explorer

Zeigt Rollen, Datenquellen, Zugriffsebenen, Datenqualitätsklassen und Wirkungsflüsse in einem Datenraum. Nutzen: macht Datenräume verständlich und prüfbar. Zielgruppe: Verwaltung, Unternehmen, Prüfer:innen, Forschung. Status: Demo in Vorbereitung.


## 3. DPP-Viewer

Übersetzt Produktpassdaten in verständliche Wirkungsinformationen. Nutzen: macht Produktwirkung entlang des Lebenszyklus sichtbar. Zielgruppe: Verbraucher:innen, Handel, Beschaffung, Prüfer:innen. Status: Demo in Vorbereitung.


## 4. KI-Impact-Audit

Prüft KI-Systeme nach Zweck, Daten, Modellgrenzen, Bias, Transparenz, Energiebedarf, Rechtsschutz und menschlicher Aufsicht. Nutzen: verhindert automatisierte Blindleistung. Status: Demo in Vorbereitung.


## 5. Plattform-Wirkungsradar

Bewertet Reichweitenlogik, Moderation, Desinformationsrisiken und Diskurswirkung. Nutzen: stärkt Medienqualität und demokratische Resilienz. Status: Demo in Vorbereitung.


## 6. Cyberresilienz-Check

Prüft Wiederherstellbarkeit, Identitäten, Backup, Notfallprozesse, Registerschutz und Datenintegrität. Nutzen: schützt digitale Wirkungsarchitektur. Status: Demo in Vorbereitung.


## 7. Algorithmic-Fairness-Scanner

Prüft Diskriminierungsrisiken, Erklärbarkeit, Widerspruchswege und Datenminimierung. Nutzen: schützt Rechte und Vertrauen. Status: Demo in Vorbereitung.


## 8. Wirkungsscanner für Produkte

Macht Produktwirkung aus DPP und Scorecard nutzbar, ohne Menschen zu überwachen. Nutzen: unterstützt Kauf, Beschaffung, Vergleich und Bildung. Status: Demo in Vorbereitung.


## 9. Lieferketten-Wirkungsmonitor

Verbindet Lieferkettendaten, WÖk-IDs, DPP und Scorecards. Nutzen: macht Risiken und Verbesserungswege sichtbar. Status: Demo in Vorbereitung.


## Quellen und Anschlussstellen
### Interne Quellen
- Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands. Das Standardwerk der Wirkungsökonomie, Manuskriptfassung 2026, Teil XIII - Digitalisierung, KI und Wirkungsdatenräume.
- Natalie Weber: Systemmodell der Wirkungsökonomie. Die systemische Ordnungskarte Mensch-Planet-Demokratie, 2025.
- Natalie Weber: Technische Leitlinien zum Wirkungssteuergesetz (WUStG), Vollversion Extended, August 2025.
- Natalie Weber: WP Produkte - Produktbesteuerung durch Wirkung, 2025.
- Natalie Weber: Wirkungsoekonomie in der Lieferkette, September 2025.
### Externe Anschlussstellen
- European Commission: AI Act - Shaping Europe's digital future. Offizielle Informationen zum EU AI Act, Inkrafttreten 1. August 2024, stufenweise Anwendung bis 2026 und GPAI-Pflichten ab 2025.
- European Commission: Digital Product Passport unter der Ecodesign for Sustainable Products Regulation (ESPR), Informationen 2024/2025.
- EUR-Lex: Regulation (EU) 2023/2854 - Data Act, harmonised rules on fair access to and use of data.
- EUR-Lex: Regulation (EU) 2022/868 - Data Governance Act, European data governance and common European data spaces.
- EUR-Lex: Regulation (EU) 2024/2847 - Cyber Resilience Act, horizontal cybersecurity requirements for products with digital elements.
- NIST: Artificial Intelligence Risk Management Framework, 2023; NIST Cybersecurity Framework 2.0, 2024.
- United Nations: Transforming our world - The 2030 Agenda for Sustainable Development and Sustainable Development Goals.