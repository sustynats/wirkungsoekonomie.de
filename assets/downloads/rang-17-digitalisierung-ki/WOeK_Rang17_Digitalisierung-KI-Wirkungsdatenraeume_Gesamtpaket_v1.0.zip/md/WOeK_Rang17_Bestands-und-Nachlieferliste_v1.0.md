# Bestands- und Nachlieferliste Rang 17

## Digitalisierung, KI und Wirkungsdatenräume

**Autorin:** Natalie Weber  
**Referenz:** Wirkungsökonomie  
**Version:** 1.0  
**Stand:** Mai 2026  
**Status:** Arbeits- und Abnahmeliste

## Kurzfassung
Operative Kontrollliste

## Inhaltsverzeichnis
1. Einordnung
2. Qualitätsentscheidung
3. Abnahme

## Tabelle

| Baustein | Status | Website-Aufgabe |
| --- | --- | --- |
| Portalstartseite | erstellt | Online einbauen, Downloadlinks setzen |
| Konzeptpapier | Langfassung erstellt | PDF und DOCX verlinken |
| Gesamtdossier | Langfassungsentwurf erstellt | Online-Volltext und Downloads |
| 10 Detailkonzepte | Langfassungen erstellt | Nicht als Grobkonzepte behandeln |
| Toolkarten | erstellt | Demo-Status und Links |
| Wirkungsindikatoren | erstellt | Tabellen responsiv ausgeben |
| SDG-/SDG+-Block | erstellt | Auf allen Unterseiten integrieren |
| Politische Anschlussfähigkeit | erstellt | Pflichtblock auf allen Wirkungsfeldseiten |
| CodeX-Anweisung | erstellt | Website-Integration ausführen |

## 1. Einordnung

Diese Liste kontrolliert, ob Rang 17 wirklich als Fachbereich und nicht als Dateisammlung umgesetzt wird. Sie markiert die Paketbestandteile und die Website-Pflichten.


## 2. Qualitätsentscheidung

Kurze Digitalisierungsnotizen sind keine Detailkonzepte. Rang 17 braucht Langfassungen, weil Datenräume, KI, DPP, Cyberresilienz, Plattformlogik, digitale Rechte und Auditlogik eigene Fachunterbereiche sind.


## 3. Abnahme

Der Rang ist erst abgeschlossen, wenn Online-Volltexte, PDF-Downloads, DOCX-Downloads, ZIP, Toolkarten, SDG-/SDG+-Block, politische Anschlussfähigkeit, Querverlinkungen, mobile UX und Linkcheck funktionieren.


## Quellen und Anschlussstellen
### Interne Quellen
- Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands. Das Standardwerk der Wirkungsökonomie, Manuskriptfassung 2026, Teil XIII - Digitalisierung, KI und Wirkungsdatenräume.
- Natalie Weber: Systemmodell der Wirkungsökonomie. Die systemische Ordnungskarte Mensch-Planet-Demokratie, 2025.
- Natalie Weber: Technische Leitlinien zum Wirkungssteuergesetz (WUStG), Vollversion Extended, August 2025.
- Natalie Weber: WP Produkte - Produktbesteuerung durch Wirkung, 2025.
- Natalie Weber: Wirkungsoekonomie in der Lieferkette, September 2025.
### Externe Anschlussstellen
- European Commission: AI Act - Shaping Europe's digital future. Offizielle Informationen zum EU AI Act, Inkrafttreten 1. August 2024, stufenweise Anwendung bis 2026 und GPAI-Pflichten ab 2025.
- European Commission: Digital Product Passport unter der Ecodesign for Sustainable Products Regulation (ESPR), Informationen 2024/2025.
- EUR-Lex: Regulation (EU) 2023/2854 - Data Act, harmonised rules on fair access to and use of data.
- EUR-Lex: Regulation (EU) 2022/868 - Data Governance Act, European data governance and common European data spaces.
- EUR-Lex: Regulation (EU) 2024/2847 - Cyber Resilience Act, horizontal cybersecurity requirements for products with digital elements.
- NIST: Artificial Intelligence Risk Management Framework, 2023; NIST Cybersecurity Framework 2.0, 2024.
- United Nations: Transforming our world - The 2030 Agenda for Sustainable Development and Sustainable Development Goals.