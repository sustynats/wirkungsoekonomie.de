# Quellen und Glossarlinks Rang 17

## Interne und externe Anschlussstellen

**Autorin:** Natalie Weber  
**Referenz:** Wirkungsökonomie  
**Version:** 1.0  
**Stand:** Mai 2026  
**Status:** Entwurf

## Kurzfassung
Quellen und Glossar

## Inhaltsverzeichnis
1. Interne Quellen
2. Externe Quellen
3. Glossarlinks

## 1. Interne Quellen

Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

Natalie Weber: Die neue Ordnung des Wohlstands. Das Standardwerk der Wirkungsökonomie, Manuskriptfassung 2026, Teil XIII - Digitalisierung, KI und Wirkungsdatenräume.

Natalie Weber: Systemmodell der Wirkungsökonomie. Die systemische Ordnungskarte Mensch-Planet-Demokratie, 2025.

Natalie Weber: Technische Leitlinien zum Wirkungssteuergesetz (WUStG), Vollversion Extended, August 2025.

Natalie Weber: WP Produkte - Produktbesteuerung durch Wirkung, 2025.

Natalie Weber: Wirkungsoekonomie in der Lieferkette, September 2025.


## 2. Externe Quellen

European Commission: AI Act - Shaping Europe's digital future. Offizielle Informationen zum EU AI Act, Inkrafttreten 1. August 2024, stufenweise Anwendung bis 2026 und GPAI-Pflichten ab 2025.

European Commission: Digital Product Passport unter der Ecodesign for Sustainable Products Regulation (ESPR), Informationen 2024/2025.

EUR-Lex: Regulation (EU) 2023/2854 - Data Act, harmonised rules on fair access to and use of data.

EUR-Lex: Regulation (EU) 2022/868 - Data Governance Act, European data governance and common European data spaces.

EUR-Lex: Regulation (EU) 2024/2847 - Cyber Resilience Act, horizontal cybersecurity requirements for products with digital elements.

NIST: Artificial Intelligence Risk Management Framework, 2023; NIST Cybersecurity Framework 2.0, 2024.

United Nations: Transforming our world - The 2030 Agenda for Sustainable Development and Sustainable Development Goals.


## 3. Glossarlinks

Wirkung, Wirkungspotenzial, Wirkungsrisiko, Wirkungsraum, Wirkungsempfänger, Netto-Wirkung, positive Netto-Wirkung, Transformationswirkung, Wirkungslenkung, Wirkungsarchitektur, WÖk-ID, Reverse Merit Order, SDG+, Wirkungsrat, Wirkungskompetenz.

