# Detailkonzept - Cyberresilienz der Wirkungsarchitektur

## Register, Produktpässe, Krankenhäuser, Energie, Zahlungssysteme und Datenräume

**Autorin:** Natalie Weber  
**Referenz:** Wirkungsökonomie  
**Version:** 1.0  
**Stand:** Mai 2026  
**Status:** Langfassungsentwurf

## Kurzfassung
Langfassung zu Cyberresilienz der Wirkungsarchitektur

## Inhaltsverzeichnis
1. Executive Summary
2. Ausgangsproblem
3. Wirkungsraum
4. Wirkungsmechanismen
5. Datenarchitektur
6. Indikatoren und Scorelogik
7. Beispielhafte Anwendung
8. Governance und Verantwortung
9. Zielkonflikte
10. Umsetzungspfad
11. Berechnungslogik und Datenformel
12. Datenquellen im Detail
13. Rollenverteilung
14. Praxisbeispiel 1 - Öffentliche Beschaffung
15. Praxisbeispiel 2 - Unternehmen und Lieferkette
16. Praxisbeispiel 3 - Bürger:innen und Wirkungsscanner
17. Risikomatrix
18. Finanzsystem, Versicherung und Kapitalzugang
19. Evaluation und Korrektur
20. Politische Anschlussfähigkeit
21. SDG-/SDG+-Bezug
22. Website- und Downloadfassung
23. Quellenrahmen

## 1. Executive Summary

Wirkung wird in diesem Portal neutral und relational verwendet. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Digitalisierung, KI und Datenräume werden deshalb nicht nach Neuheitsgrad, Marktwert oder Geschwindigkeit bewertet, sondern danach, ob sie bessere Wahrnehmung, Rückkopplung, Lernfähigkeit, Rechtsschutz, Transparenz und demokratische Kontrolle ermöglichen.

Dieses Detailkonzept behandelt Cyberresilienz der Wirkungsarchitektur als Fachunterbereich von Rang 17. Es ist eine Langfassung für Website, Akademie, Download und politische Anschlussfähigkeit. Der Fokus liegt auf Register, Produktpässe, Krankenhäuser, Energie, Zahlungssysteme und Datenräume.


## 2. Ausgangsproblem

Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung wird häufig zu eng verstanden. Entweder erscheint es als technisches Tool, als Compliance-Pflicht oder als Innovationsversprechen. Für die Wirkungsökonomie reicht das nicht. Der zentrale Maßstab ist, ob Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung Wirkungsblindheit reduziert oder verstärkt.

Die typische Fehlsteuerung entsteht, wenn Daten gesammelt werden, ohne Entscheidungsfolgen zu verändern. Dann entstehen Berichte, Dashboards und Kennzahlen, aber keine Rückkopplung. Eine zweite Fehlsteuerung entsteht, wenn automatische Systeme Entscheidungen treffen oder vorbereiten, ohne dass Verantwortung, Widerspruch und Korrektur klar geregelt sind.

Dritte Fehlsteuerung ist die Scheingenauigkeit. Digitale Daten wirken präzise, können aber lückenhaft, ungleich, veraltet, manipuliert oder aus falschen Anreizen entstanden sein. Deshalb braucht dieses Detailkonzept nicht nur Technik, sondern Datenqualität, Governance und Schutzmechanismen.


## 3. Wirkungsraum

Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Resilienz entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Der Wirkungsraum umfasst direkte und indirekte Empfänger:innen: Unternehmen, Verwaltungen, Prüfer:innen, Bürger:innen, Verbraucher:innen, Lieferketten, Kommunen, Kapitalgeber, Versicherungen, Forschung, Medien und künftige Generationen. Auch Nicht-Handeln wirkt: Wenn Daten nicht verbunden werden, bleiben Schäden unsichtbar; wenn Rechte fehlen, wird Transparenz zur Machtasymmetrie.

Wirkung kann verzögert eintreten. Ein fehlerhaftes Register erzeugt vielleicht zunächst nur kleine Unstimmigkeiten, kann später aber falsche Förderung, falsche Steuerklasse, falsche Kreditentscheidung oder falsches öffentliches Vertrauen erzeugen. Deshalb braucht Rang 17 nicht nur Output-Kennzahlen, sondern Frühwarn- und Resilienzindikatoren.


## 4. Wirkungsmechanismen

Für Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung braucht Resilienz eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Der wichtigste Mechanismus ist Rückkopplung. Daten müssen nicht nur gesammelt, sondern in Entscheidungskontexte zurückgeführt werden. Ein Produktpass verändert erst dann Wirkung, wenn Beschaffung, Preis, Reparatur, Recycling, Kapitalzugang oder Kund:inneninformation reagieren. Ein KI-Audit verändert erst dann Wirkung, wenn Modellgrenzen zu Korrekturen führen.

Der zweite Mechanismus ist Nichtkompensation. Gute technische Effizienz darf keine schweren Schäden verdecken. Ein schnelles KI-System mit diskriminierenden Ergebnissen bleibt problematisch. Ein DPP mit guter CO2-Bilanz, aber nicht prüfbarer Lieferkette bleibt unvollständig. Ein Datenraum mit hoher Datendichte, aber fehlendem Rechtsschutz bleibt riskant.


## 5. Datenarchitektur

Die Datenarchitektur muss Quellen, Semantik, Rollen, Rechte, Schnittstellen, Prüfstatus, Datenqualitätsklassen und Versionierung enthalten. Sie darf nicht nur die Daten selbst speichern, sondern muss erklären, woher sie stammen, wer sie geprüft hat, wie aktuell sie sind, welche Unsicherheiten bestehen und welche Entscheidung sie beeinflussen dürfen.

Für kleinere Akteure braucht es abgestufte Prüftiefe. Gleiche Grundlogik bedeutet nicht gleiche Berichtslast. Kleine Unternehmen, Kommunen oder Vereine benötigen Standardwerte, Hilfstools, Sammelprüfungen und Beratungsangebote. Sonst erzeugt die Wirkungsarchitektur neue Ungleichheit.

Datenminimierung bleibt Pflicht. Die WÖk benötigt Wirkungsdaten, keine Totalerfassung. Wo personenbezogene Daten betroffen sind, gelten Zweckbindung, Schutz, Löschung, Pseudonymisierung, Zugriffsbeschränkung und Rechtsschutz. Die Architektur muss beweisen, dass sie mit möglichst wenig Eingriff möglichst hohe Systemwirkung erzielt.


## 6. Indikatoren und Scorelogik

Mögliche Indikatoren für Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.

Die Indikatoren sollten nicht isoliert verwendet werden. Ein hoher Interoperabilitätsgrad ist wertlos, wenn Daten falsch sind. Eine hohe KI-Genauigkeit ist wertlos, wenn Betroffene keine Entscheidung anfechten können. Eine niedrige Wiederherstellungszeit ist unzureichend, wenn Datenintegrität nicht gesichert ist.

Deshalb braucht jedes Detailkonzept einen Mindestindikatorensatz: Datenherkunft, Datenqualität, Prüfstatus, Rechtsschutz, Zugänglichkeit, Nutzbarkeit, Korrekturweg, Energie- und Ressourcenwirkung, Sicherheitsniveau und demokratische Kontrollfähigkeit. Für jede Anwendung werden die relevanten Unterindikatoren ausgewählt.


## 7. Beispielhafte Anwendung

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Resilienz dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Zweiter Anwendungsfall: Ein Unternehmen nutzt die Architektur für Lieferketten. In der alten Logik werden Lieferantendaten gesammelt, um Fragebögen zu erfüllen. In der Wirkungsökonomie werden sie in Beschaffung, Risiko, Finanzierung, Produktentwicklung und Verbesserungspfade zurückgeführt. Lieferant:innen mit schwacher Datenlage werden nicht automatisch ausgeschlossen, sondern erhalten klare Verbesserungspfade, sofern keine roten Linien verletzt sind.

Dritter Anwendungsfall: Eine öffentliche Stelle nutzt digitale Prüfungen in Förderprogrammen. Das System darf nicht nur Betrugsrisiken reduzieren, sondern muss Zugänglichkeit, Fehlerkorrektur und Widerspruch sichern. Sonst wird Effizienz zur Zugangshürde.


## 8. Governance und Verantwortung

Verantwortung bleibt menschlich, organisatorisch und institutionell. Digitale Systeme können Vorschläge machen, Muster erkennen oder Prüfpfade dokumentieren. Sie tragen aber keine Verantwortung. Verantwortlich sind Anbieter, Betreiber, Auftraggeber, Prüfer:innen, Behörden und politische Instanzen.

Governance braucht klare Rollen: Datenerzeuger, Datenhalter, Datenprüfer, Datenraum-Betreiber, öffentliche Aufsicht, Wirkungsrat, Betroffene, Nutzer:innen und Beschwerdestellen. Jede Rolle braucht Rechte und Pflichten. Ohne Rollenmodell wird Datenraum zu Machtkonzentration.

Auch Haftung muss geklärt werden. Wenn ein Fehler im Datenraum zu falscher Bewertung führt, braucht es Korrektur und Verantwortlichkeit. Wenn ein KI-System diskriminiert, muss der Betreiber nicht auf das Modell zeigen können. Wenn ein Produktpass manipuliert wird, muss die Prüfkette rekonstruierbar sein.


## 9. Zielkonflikte

Zielkonflikte sind unvermeidbar. Transparenz kann mit Geschäftsgeheimnissen kollidieren. Datenzugang kann Datenschutz berühren. Automatisierung kann Effizienz erhöhen und Rechtsschutz schwächen. Cybersicherheit kann Nutzbarkeit erschweren. Plattformregulierung kann Desinformation begrenzen und Meinungsfreiheit berühren.

Die Wirkungsökonomie löst diese Konflikte nicht durch Behauptung. Sie ordnet sie. Jeder Zielkonflikt braucht eine dokumentierte Abwägung, einen Schutzmechanismus, eine Evaluationspflicht und eine Möglichkeit zur Korrektur. Politische Entscheidung bleibt politisch, aber sie wird wirkungsinformierter.

Wichtig ist, dass Zielkonflikte nicht als Ausrede für Nicht-Handeln dienen. Auch Nicht-Handeln erzeugt Wirkung: unsichtbare Lieferkettenrisiken, unklare KI-Haftung, wachsende Plattformmacht oder schwache Cyberresilienz.


## 10. Umsetzungspfad

Phase 1: Wirkungsraum und Rechtsrahmen klären. Phase 2: Datenquellen, Datenqualität und Rollen definieren. Phase 3: Prototyp mit begrenztem Anwendungsfall bauen. Phase 4: Audit, Betroffenenfeedback und Nebenwirkungsanalyse. Phase 5: öffentliche Dokumentation. Phase 6: Skalierung mit Korrekturschleifen.

Die Pilotierung sollte dort beginnen, wo Nutzen hoch und Risiken beherrschbar sind: DPP-Pilotprodukte, kommunale Beschaffung, öffentliche Förderprogramme, Lieferkettenmonitoring, Gebäudedaten, Energieinfrastruktur oder freiwillige Unternehmensscorecards. Kritische Bereiche wie Gesundheit, soziale Sicherung, Justiz oder Migration brauchen besonders strenge Schutzstandards.

Die Umsetzung braucht Schulung. Wirkungskompetenz ist nicht nur ein technisches Thema. Verwaltungen, Unternehmen, Prüfer:innen, Journalist:innen und Bürger:innen müssen verstehen, was ein Score aussagt und was nicht, wo Unsicherheit liegt und wie Korrektur funktioniert.


## 11. Berechnungslogik und Datenformel

Die Bewertungslogik kann nicht aus einer einzigen Zahl bestehen. Sie verbindet Mindestanforderungen, rote Linien, Datenqualitätsklassen und Kontextindikatoren. Eine vereinfachte Arbeitsformel lautet: Wirkungswert = geprüfte Zustandsveränderung mal Datenqualität mal Relevanz im Wirkungsraum, begrenzt durch rote Linien und Nichtkompensation. Diese Formel ist keine starre Mathematik, sondern eine transparente Struktur, um Scheingenauigkeit zu vermeiden.

Für den Fachbereich {title} muss jede Bewertung dokumentieren, welche Indikatoren genutzt wurden, welche Daten fehlen, welche Unsicherheit besteht und welche Entscheidung an die Bewertung gekoppelt ist. Ein hoher Wert ist nur belastbar, wenn die Datenquelle prüfbar ist. Ein niedriger Wert muss einen Verbesserungspfad auslösen, sofern keine rote Linie verletzt ist.

Die Reverse Merit Order schützt vor Schönrechnung. Ein digitales System darf nicht als positiv gelten, wenn es zwar Effizienz erzeugt, aber Rechtsschutz ausschließt, Diskriminierung automatisiert, Daten unprüfbar macht oder Cyberrisiken ignoriert.


## 12. Datenquellen im Detail

Relevante Datenquellen sind technische Dokumentationen, Auditberichte, Produktpassdaten, Schnittstellenprotokolle, Sicherheitsberichte, KI-Model-Cards, Datenblätter, Impact Assessments, öffentliche Statistiken, Lieferkettendaten, Beschaffungsdaten, Fördermitteldaten, Nutzungsfeedback und wissenschaftliche Evaluationen.

Diese Quellen müssen in Datenqualitätsklassen geordnet werden. Klasse A beschreibt unabhängig geprüfte, aktuelle und maschinenlesbare Daten. Klasse B beschreibt plausibilisierte Daten mit begrenzter Prüfung. Klasse C beschreibt Selbstauskünfte oder historische Daten. Klasse D beschreibt Schätzung oder fehlende Daten. Die Bewertung muss offen zeigen, auf welcher Klasse sie beruht.

Datenquellen brauchen Verantwortliche. Wer Daten liefert, wer sie prüft, wer sie verändert und wer sie nutzt, muss nachvollziehbar sein. Ohne Verantwortlichkeit entsteht keine Wirkungsarchitektur, sondern eine Datenkulisse.


## 13. Rollenverteilung

Die Rollenverteilung umfasst Betreiber, Datenerzeuger, Prüfer:innen, Aufsicht, Betroffene, Nutzer:innen, Forschung und politische Instanzen. Jede Rolle braucht Rechte, Pflichten und Grenzen. Betreiber dürfen nicht zugleich alleinige Prüfer ihrer eigenen Wirkung sein. Prüfer:innen brauchen Zugang, aber keine unnötige Datenmacht. Nutzer:innen brauchen verständliche Informationen. Betroffene brauchen Rechtsschutz.

Für Unternehmen bedeutet das: Datenverantwortung gehört in Governance, Risiko, Beschaffung, Produktentwicklung und Compliance. Für Kommunen bedeutet es: Datenräume brauchen Verwaltungszuständigkeit, Datenschutz, Sozialraumwissen und Beteiligung. Für den Staat bedeutet es: Standards müssen öffentlich sein, damit sie nicht von einzelnen Plattformen oder Konzernen kontrolliert werden.

Die Rollenverteilung verhindert, dass digitale Infrastruktur politisch unsichtbar wird. Wer Wirkung steuert, übt Macht aus. Diese Macht muss demokratisch begrenzt und fachlich geprüft werden.


## 14. Praxisbeispiel 1 - Öffentliche Beschaffung

Eine Kommune beschafft digitale Geräte, Energieanlagen oder Bauprodukte. In der alten Logik zählen Preis, Lieferfähigkeit und formale Anforderungen. In der Wirkungsökonomie werden Produktpassdaten, Reparierbarkeit, Cyberresilienz, Lieferkettenrisiken, Energiebedarf, Datenqualität und Nutzungsdauer einbezogen.

Der Nutzen liegt nicht in Bürokratie, sondern in besseren Entscheidungen. Ein günstiges Produkt kann teuer werden, wenn es kurze Lebensdauer, Sicherheitsrisiken oder schlechte Reparierbarkeit hat. Ein teureres Produkt kann positive Netto-Wirkung erzeugen, wenn es langlebig, sicher, reparierbar und emissionsarm ist.

Das Beispiel zeigt, dass digitale Wirkungsdaten nicht nur Nachhaltigkeitsberichte füllen. Sie verändern Beschaffung, Lebenszykluskosten, Risiko und öffentliche Verantwortung.


## 15. Praxisbeispiel 2 - Unternehmen und Lieferkette

Ein Unternehmen will Lieferkettenrisiken besser steuern. Es sammelt nicht nur Zertifikate, sondern verbindet Produktpässe, Lieferantendaten, WÖk-IDs, Auditstatus und Verbesserungsmaßnahmen. Aus Daten wird ein Wirkpfad: Risiko erkennen, Lieferant unterstützen, Produkt verbessern, Finanzierung sichern, Kund:innen informieren.

Die Wirkung entsteht erst, wenn die Daten in Einkauf, Produktentwicklung, Finanzierung und Management zurückkehren. Ein Datenraum ohne Rückkopplung wäre nur ein weiteres Archiv. Ein Datenraum mit Rückkopplung verändert Handlungen.

Auch hier gilt Schutz vor Ausschluss: Kleine Lieferant:innen dürfen nicht automatisch verdrängt werden, nur weil ihre Datenqualität niedriger ist. Sie brauchen Übergangsfristen und Unterstützung, solange keine schweren roten Linien verletzt sind.


## 16. Praxisbeispiel 3 - Bürger:innen und Wirkungsscanner

Bürger:innen können nicht vor jedem Kauf eine Lebenszyklusanalyse lesen. Der Wirkungsscanner übersetzt komplexe Produktdaten in verständliche Signale. Er zeigt Wirkungsklasse, Datenqualität, wichtigste Risiken, Verbesserungsoptionen und Unsicherheit.

Der Scanner darf keine Menschen bewerten. Er bewertet Produkte, Angebote oder öffentliche Maßnahmen. Er darf nicht tracken, wer was kauft, um daraus Personenprofile zu bauen. Die Wirkungsökonomie trennt Produktwirkung von Personenbewertung.

Damit stärkt der Scanner Freiheit. Menschen erhalten bessere Informationen, ohne moralisch überfordert oder überwacht zu werden.


## 17. Risikomatrix

Die wichtigsten Risiken sind Datenmanipulation, Scheingenauigkeit, zentrale Datenmacht, Diskriminierung, Cyberangriffe, falsche Automatisierung, Überlastung kleiner Akteure, unklare Haftung und politische Vereinnahmung. Jedes Risiko braucht Gegenmaßnahmen.

Datenmanipulation wird durch Audit-Trails, Signaturen und unabhängige Prüfung begrenzt. Scheingenauigkeit wird durch Unsicherheitsklassen begrenzt. Datenmacht wird durch föderierte Architektur und Rollenrechte begrenzt. Diskriminierung wird durch Fairnessprüfungen und Widerspruch begrenzt. Cyberrisiken werden durch Resilienzstandards begrenzt.

Die Risikomatrix gehört auf die Website, weil sie Vertrauen schafft. Ein System, das seine eigenen Risiken offenlegt, wirkt glaubwürdiger als ein System, das technische Perfektion behauptet.


## 18. Finanzsystem, Versicherung und Kapitalzugang

Rang 17 ist auch für Banken, Versicherungen und Investoren relevant. Wirkungsdaten sind Risikodaten. Wer Daten zu Emissionen, Lieferketten, Cyberresilienz, Wasserstress, Reparierbarkeit, KI-Governance oder Plattformrisiken sichtbar macht, verändert Kreditprüfung, Versicherbarkeit und Kapitalzugang.

Positive Wirkung kann Finanzierungskosten senken, wenn Risiken sinken und Geschäftsmodelle resilienter werden. Negative Wirkung kann Risikoaufschläge erzeugen. Unklare Daten können zu Prüfauflagen führen. Damit wird Digitalisierung zur Brücke zwischen Wirkung und Finanzsystem.

Diese Logik darf nicht zur automatischen Kapitalbestrafung kleiner Akteure führen. Deshalb braucht es Übergang, Beratung, Standardwerte und proportionale Prüfungen.


## 19. Evaluation und Korrektur

Jede digitale Wirkungsarchitektur muss regelmäßig evaluiert werden. Evaluation fragt nicht nur, ob das System genutzt wird, sondern ob es Zustände verbessert: bessere Datenqualität, weniger Bürokratie, schnellere Korrektur, weniger Diskriminierung, höhere Resilienz, bessere Beschaffung, mehr Vertrauen.

Korrektur ist Pflicht. Wenn ein Indikator falsche Anreize setzt, muss er angepasst werden. Wenn ein Modell diskriminiert, muss es gestoppt oder überarbeitet werden. Wenn ein Datenraum Macht konzentriert, müssen Rollen und Rechte verändert werden.

Versionierung ist kein Nebenthema. Jede Änderung an Scorecards, WÖk-IDs, Datenklassen oder Bewertungsschwellen muss nachvollziehbar sein. Nur so bleibt demokratische Kontrolle möglich.


## 20. Politische Anschlussfähigkeit

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext und keine technokratische Steuerungsmaschine. Sie liefert einen Bewertungs- und Steuerungsrahmen. Parteien, Parlamente, Verwaltungen, Unternehmen und Zivilgesellschaft behalten Ausgestaltungsspielraum. Entscheidend ist, ob digitale Regeln, KI-Systeme, Datenräume, Plattformen und Produktpässe überprüfbar positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugen. Digitale Wirkungssteuerung darf keine private Lebensführung überwachen, keine Menschen klassifizieren, keine Gesinnung messen und keine Social-Credit-Logik erzeugen. Bewertet werden Produkte, Organisationen, Systeme, Prozesse, Kapitalflüsse, öffentliche Maßnahmen und Infrastrukturen. Wo Menschen betroffen sind, gelten Datenschutz, Rechtsschutz, Widerspruch, Transparenz und menschliche Entscheidungspflicht.


## 21. SDG-/SDG+-Bezug

Rang 17 verbindet besonders SDG 4, SDG 8, SDG 9, SDG 10, SDG 12, SDG 13, SDG 16 und SDG 17. Digitalisierung kann Bildung, Arbeit, Infrastruktur, nachhaltige Produktion, Klimatransparenz, starke Institutionen und Partnerschaften unterstützen. Dieselben Systeme können diese Ziele aber auch schwächen, wenn sie Ausschluss, Überwachung, Desinformation, Machtkonzentration, Energieverschwendung oder manipulative Plattformlogiken verstärken. SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt, digitale Selbstbestimmung, algorithmische Fairness und Schutz vor Desinformation.


## 22. Website- und Downloadfassung

Die Websitefassung zu Cyberresilienz der Wirkungsarchitektur muss vollständig online lesbar sein. Sie braucht ein mobil funktionierendes Inhaltsverzeichnis, Abschnitte mit Ankerlinks, Downloadbuttons für PDF und DOCX, Druckfunktion, Glossarlinks, Quellenblock und Querverlinkungen zu Staat, Recht & Demokratie, Medien & Öffentlichkeit, Sicherheit & Resilienz, Wirtschaft & Unternehmen, Produkte & Konsum und Impact Controlling.

Die Downloadfassung muss im Corporate Design der Wirkungsökonomie erscheinen. Pflichtangaben: Titel, Untertitel, Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Inhaltsverzeichnis, Quellen, Glossarlinks und Hinweis auf die Onlinefassung.


## 23. Quellenrahmen

Der externe Anschlussrahmen umfasst den EU AI Act, den Digital Product Passport im Rahmen der ESPR, Data Act, Data Governance Act, Cyber Resilience Act, NIST AI RMF, NIST Cybersecurity Framework 2.0 und die UN Agenda 2030. Diese Quellen liefern regulatorische, technische und normative Anschlussstellen. Sie ersetzen nicht die Wirkungslogik, sondern werden in der Wirkungsökonomie als Daten-, Rechts- und Governance-Bezugspunkte genutzt.


## Quellen und Anschlussstellen
### Interne Quellen
- Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands. Das Standardwerk der Wirkungsökonomie, Manuskriptfassung 2026, Teil XIII - Digitalisierung, KI und Wirkungsdatenräume.
- Natalie Weber: Systemmodell der Wirkungsökonomie. Die systemische Ordnungskarte Mensch-Planet-Demokratie, 2025.
- Natalie Weber: Technische Leitlinien zum Wirkungssteuergesetz (WUStG), Vollversion Extended, August 2025.
- Natalie Weber: WP Produkte - Produktbesteuerung durch Wirkung, 2025.
- Natalie Weber: Wirkungsoekonomie in der Lieferkette, September 2025.
### Externe Anschlussstellen
- European Commission: AI Act - Shaping Europe's digital future. Offizielle Informationen zum EU AI Act, Inkrafttreten 1. August 2024, stufenweise Anwendung bis 2026 und GPAI-Pflichten ab 2025.
- European Commission: Digital Product Passport unter der Ecodesign for Sustainable Products Regulation (ESPR), Informationen 2024/2025.
- EUR-Lex: Regulation (EU) 2023/2854 - Data Act, harmonised rules on fair access to and use of data.
- EUR-Lex: Regulation (EU) 2022/868 - Data Governance Act, European data governance and common European data spaces.
- EUR-Lex: Regulation (EU) 2024/2847 - Cyber Resilience Act, horizontal cybersecurity requirements for products with digital elements.
- NIST: Artificial Intelligence Risk Management Framework, 2023; NIST Cybersecurity Framework 2.0, 2024.
- United Nations: Transforming our world - The 2030 Agenda for Sustainable Development and Sustainable Development Goals.