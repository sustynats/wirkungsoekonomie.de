# Rang 17 - Digitalisierung, KI und Wirkungsdatenräume

## Portalstartseite und Online-Einstieg

**Autorin:** Natalie Weber  
**Referenz:** Wirkungsökonomie  
**Version:** 1.0  
**Stand:** Mai 2026  
**Status:** Entwurf für Website und Downloads

## Inhaltsverzeichnis
1. Kernidee
2. Portalbereiche
3. Pflichtgrenze
4. Politische Anschlussfähigkeit
5. SDG-/SDG+-Bezug

## Tabelle

| P |
| --- |

## Tabelle

| o |
| --- |

## Tabelle

| r |
| --- |

## Tabelle

| t |
| --- |

## Tabelle

| a |
| --- |

## Tabelle

| l |
| --- |

## Tabelle

| s |
| --- |

## Tabelle

| t |
| --- |

## Tabelle

| a |
| --- |

## Tabelle

| r |
| --- |

## Tabelle

| t |
| --- |

## Tabelle

| s |
| --- |

## Tabelle

| e |
| --- |

## Tabelle

| i |
| --- |

## Tabelle

| t |
| --- |

## Tabelle

| e |
| --- |

## Tabelle

|   |
| --- |

## Tabelle

| f |
| --- |

## Tabelle

| ü |
| --- |

## Tabelle

| r |
| --- |

## Tabelle

|   |
| --- |

## Tabelle

| R |
| --- |

## Tabelle

| a |
| --- |

## Tabelle

| n |
| --- |

## Tabelle

| g |
| --- |

## Tabelle

|   |
| --- |

## Tabelle

| 1 |
| --- |

## Tabelle

| 7 |
| --- |

## 1. Kernidee

Wirkung wird in diesem Portal neutral und relational verwendet. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Digitalisierung, KI und Datenräume werden deshalb nicht nach Neuheitsgrad, Marktwert oder Geschwindigkeit bewertet, sondern danach, ob sie bessere Wahrnehmung, Rückkopplung, Lernfähigkeit, Rechtsschutz, Transparenz und demokratische Kontrolle ermöglichen.

Rang 17 bildet die digitale Infrastrukturschicht der Wirkungsökonomie. Ohne Datenräume, Produktpässe, Schnittstellen, Register, Audit-Trails, KI-Governance, Cyberresilienz und digitale Rechte bleibt Wirkung Bericht, Schätzung oder Einzelprüfung. Mit einer klug gestalteten digitalen Architektur kann Wirkung in Entscheidungen zurückkehren: in Beschaffung, Finanzierung, Versicherung, Produktentwicklung, Steuerung, öffentliche Haushalte, Verwaltung und politische Evaluation.


## 2. Portalbereiche

Die Portalstruktur umfasst Konzeptpapier, Gesamtdossier, zehn Detailkonzepte, Toolkarten, Wirkungsindikatoren, SDG-/SDG+-Block, politische Anschlussfähigkeit, Quellen, Glossarlinks, Downloads, Online-Volltexte und CodeX-Anweisung.

- Digitale Produktpässe
- Wirkungsdatenräume
- KI-Governance
- Algorithmische Fairness
- Digitale Souveränität
- Cyberresilienz
- Plattformlogik
- Wirkungsscanner
- Interoperabilität und Register
- Audit, Assurance und Datenqualität

## 3. Pflichtgrenze

Digitalisierung darf nicht zum neuen blinden Kompass werden. Daten brauchen Rechte. KI braucht Verantwortung. Produktpässe brauchen Validierung. Plattformen brauchen Transparenz. Register brauchen Rechtsschutz. Cyberresilienz braucht Freiheit. Digitale Souveränität braucht demokratische Kontrolle.


## 4. Politische Anschlussfähigkeit

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext und keine technokratische Steuerungsmaschine. Sie liefert einen Bewertungs- und Steuerungsrahmen. Parteien, Parlamente, Verwaltungen, Unternehmen und Zivilgesellschaft behalten Ausgestaltungsspielraum. Entscheidend ist, ob digitale Regeln, KI-Systeme, Datenräume, Plattformen und Produktpässe überprüfbar positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugen. Digitale Wirkungssteuerung darf keine private Lebensführung überwachen, keine Menschen klassifizieren, keine Gesinnung messen und keine Social-Credit-Logik erzeugen. Bewertet werden Produkte, Organisationen, Systeme, Prozesse, Kapitalflüsse, öffentliche Maßnahmen und Infrastrukturen. Wo Menschen betroffen sind, gelten Datenschutz, Rechtsschutz, Widerspruch, Transparenz und menschliche Entscheidungspflicht.


## 5. SDG-/SDG+-Bezug

Rang 17 verbindet besonders SDG 4, SDG 8, SDG 9, SDG 10, SDG 12, SDG 13, SDG 16 und SDG 17. Digitalisierung kann Bildung, Arbeit, Infrastruktur, nachhaltige Produktion, Klimatransparenz, starke Institutionen und Partnerschaften unterstützen. Dieselben Systeme können diese Ziele aber auch schwächen, wenn sie Ausschluss, Überwachung, Desinformation, Machtkonzentration, Energieverschwendung oder manipulative Plattformlogiken verstärken. SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt, digitale Selbstbestimmung, algorithmische Fairness und Schutz vor Desinformation.


## Quellen und Anschlussstellen
### Interne Quellen
- Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands. Das Standardwerk der Wirkungsökonomie, Manuskriptfassung 2026, Teil XIII - Digitalisierung, KI und Wirkungsdatenräume.
- Natalie Weber: Systemmodell der Wirkungsökonomie. Die systemische Ordnungskarte Mensch-Planet-Demokratie, 2025.
- Natalie Weber: Technische Leitlinien zum Wirkungssteuergesetz (WUStG), Vollversion Extended, August 2025.
- Natalie Weber: WP Produkte - Produktbesteuerung durch Wirkung, 2025.
- Natalie Weber: Wirkungsoekonomie in der Lieferkette, September 2025.
### Externe Anschlussstellen
- European Commission: AI Act - Shaping Europe's digital future. Offizielle Informationen zum EU AI Act, Inkrafttreten 1. August 2024, stufenweise Anwendung bis 2026 und GPAI-Pflichten ab 2025.
- European Commission: Digital Product Passport unter der Ecodesign for Sustainable Products Regulation (ESPR), Informationen 2024/2025.
- EUR-Lex: Regulation (EU) 2023/2854 - Data Act, harmonised rules on fair access to and use of data.
- EUR-Lex: Regulation (EU) 2022/868 - Data Governance Act, European data governance and common European data spaces.
- EUR-Lex: Regulation (EU) 2024/2847 - Cyber Resilience Act, horizontal cybersecurity requirements for products with digital elements.
- NIST: Artificial Intelligence Risk Management Framework, 2023; NIST Cybersecurity Framework 2.0, 2024.
- United Nations: Transforming our world - The 2030 Agenda for Sustainable Development and Sustainable Development Goals.