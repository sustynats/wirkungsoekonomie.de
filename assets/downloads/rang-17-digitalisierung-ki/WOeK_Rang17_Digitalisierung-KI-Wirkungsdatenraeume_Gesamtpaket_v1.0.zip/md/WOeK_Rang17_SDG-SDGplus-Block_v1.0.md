# SDG-/SDG+-Block Rang 17

## Digitalisierung, KI und Wirkungsdatenräume

**Autorin:** Natalie Weber  
**Referenz:** Wirkungsökonomie  
**Version:** 1.0  
**Stand:** Mai 2026  
**Status:** Entwurf

## Kurzfassung
SDG- und SDG+-Bezug

## Inhaltsverzeichnis
1. SDG-Bezug
2. SDG 4, 8, 9 und 10
3. SDG 12, 13, 16 und 17
4. SDG+

## 1. SDG-Bezug

Rang 17 verbindet besonders SDG 4, SDG 8, SDG 9, SDG 10, SDG 12, SDG 13, SDG 16 und SDG 17. Digitalisierung kann Bildung, Arbeit, Infrastruktur, nachhaltige Produktion, Klimatransparenz, starke Institutionen und Partnerschaften unterstützen. Dieselben Systeme können diese Ziele aber auch schwächen, wenn sie Ausschluss, Überwachung, Desinformation, Machtkonzentration, Energieverschwendung oder manipulative Plattformlogiken verstärken. SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt, digitale Selbstbestimmung, algorithmische Fairness und Schutz vor Desinformation.


## 2. SDG 4, 8, 9 und 10

Digitale Bildung, faire Arbeit, Innovation, Infrastruktur und Abbau von Ungleichheiten sind zentrale Wirkungsfelder. Rang 17 prüft, ob digitale Systeme Menschen befähigen oder ausschließen, ob sie Arbeit fairer machen oder Kontrolle verdichten, ob sie Innovation demokratisch verfügbar machen oder Monopole stärken.


## 3. SDG 12, 13, 16 und 17

Produktpässe, Datenräume und Wirkungsscanner verbinden nachhaltige Produktion, Klimatransparenz, starke Institutionen und Partnerschaften. Digitale Instrumente können Lieferketten, Emissionen und Materialflüsse sichtbar machen, aber nur, wenn Daten valide, zugänglich und prüfbar sind.


## 4. SDG+

SDG+ erweitert den Blick auf Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung. Diese Felder sind für Rang 17 zentral.


## Quellen und Anschlussstellen
### Interne Quellen
- Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands. Das Standardwerk der Wirkungsökonomie, Manuskriptfassung 2026, Teil XIII - Digitalisierung, KI und Wirkungsdatenräume.
- Natalie Weber: Systemmodell der Wirkungsökonomie. Die systemische Ordnungskarte Mensch-Planet-Demokratie, 2025.
- Natalie Weber: Technische Leitlinien zum Wirkungssteuergesetz (WUStG), Vollversion Extended, August 2025.
- Natalie Weber: WP Produkte - Produktbesteuerung durch Wirkung, 2025.
- Natalie Weber: Wirkungsoekonomie in der Lieferkette, September 2025.
### Externe Anschlussstellen
- European Commission: AI Act - Shaping Europe's digital future. Offizielle Informationen zum EU AI Act, Inkrafttreten 1. August 2024, stufenweise Anwendung bis 2026 und GPAI-Pflichten ab 2025.
- European Commission: Digital Product Passport unter der Ecodesign for Sustainable Products Regulation (ESPR), Informationen 2024/2025.
- EUR-Lex: Regulation (EU) 2023/2854 - Data Act, harmonised rules on fair access to and use of data.
- EUR-Lex: Regulation (EU) 2022/868 - Data Governance Act, European data governance and common European data spaces.
- EUR-Lex: Regulation (EU) 2024/2847 - Cyber Resilience Act, horizontal cybersecurity requirements for products with digital elements.
- NIST: Artificial Intelligence Risk Management Framework, 2023; NIST Cybersecurity Framework 2.0, 2024.
- United Nations: Transforming our world - The 2030 Agenda for Sustainable Development and Sustainable Development Goals.