# Wirkungsindikatoren Rang 17

## WÖk-IDs, Datenqualität und digitale Wirkungsarchitektur

**Autorin:** Natalie Weber  
**Referenz:** Wirkungsökonomie  
**Version:** 1.0  
**Stand:** Mai 2026  
**Status:** Entwurf

## Kurzfassung
Indikatorenübersicht

## Inhaltsverzeichnis
1. Einordnung
2. Bewertungslogik
3. Rote Linien
4. Anwendung

## Tabelle

| WÖk-ID-Familie | Indikator | Datenquelle | Wirkungsbezug |
| --- | --- | --- | --- |
| WOK-DIG-101 | Datenqualitätsklasse | Audit, DPP, Register | Prüfbarkeit |
| WOK-DIG-102 | Interoperabilitätsgrad | API, Standards | Bürokratieabbau |
| WOK-DIG-103 | Widerspruchs- und Korrekturweg | Governance-Dokumentation | Rechtsschutz |
| WOK-AI-101 | Modelltransparenz | KI-Dokumentation | Demokratische Kontrolle |
| WOK-AI-102 | Bias-Prüfstatus | Audit, Testdaten | Nichtdiskriminierung |
| WOK-CY-101 | Wiederherstellungszeit | BCM, Sicherheitsberichte | Resilienz |
| WOK-DPP-101 | DPP-Abdeckung Lebenszyklus | Produktpass | Produktwirkung |
| WOK-PLAT-101 | Algorithmische Reichweitentransparenz | Plattformdaten | Medienqualität |
| WOK-SCAN-101 | Verständlichkeit Wirkungssignal | UX-Test, Barrierefreiheit | Teilhabe |

## 1. Einordnung

Die Wirkungsindikatoren für Rang 17 bewerten Datenarchitekturen, Produktpässe, KI-Systeme, Plattformlogiken, Cyberresilienz, Register, Schnittstellen und Governance-Prozesse. Sie dienen nicht der Personenbewertung.


## 2. Bewertungslogik

Jeder Indikator benötigt Wirkungsraum, Datenquelle, Datenqualitätsklasse, Prüffrequenz, Verantwortlichkeit, SDG-/SDG+-Bezug und Korrekturweg. Fehlende Daten dürfen nicht automatisch zu guten Bewertungen führen.


## 3. Rote Linien

Nicht akzeptabel sind Social-Credit-Logik, verdeckte Personenklassifikation, nicht anfechtbare automatisierte Entscheidungen, manipulative Plattformsteuerung, ungeprüfte KI in kritischen Bereichen, zentrale Datenmacht ohne Rechtsschutz und Produktpässe ohne Validierung.


## 4. Anwendung

Indikatoren werden in Scorecards und Toolkarten übersetzt. Sie müssen mobil lesbar, versioniert und in Onlinefassungen erläutert werden.


## Quellen und Anschlussstellen
### Interne Quellen
- Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands. Das Standardwerk der Wirkungsökonomie, Manuskriptfassung 2026, Teil XIII - Digitalisierung, KI und Wirkungsdatenräume.
- Natalie Weber: Systemmodell der Wirkungsökonomie. Die systemische Ordnungskarte Mensch-Planet-Demokratie, 2025.
- Natalie Weber: Technische Leitlinien zum Wirkungssteuergesetz (WUStG), Vollversion Extended, August 2025.
- Natalie Weber: WP Produkte - Produktbesteuerung durch Wirkung, 2025.
- Natalie Weber: Wirkungsoekonomie in der Lieferkette, September 2025.
### Externe Anschlussstellen
- European Commission: AI Act - Shaping Europe's digital future. Offizielle Informationen zum EU AI Act, Inkrafttreten 1. August 2024, stufenweise Anwendung bis 2026 und GPAI-Pflichten ab 2025.
- European Commission: Digital Product Passport unter der Ecodesign for Sustainable Products Regulation (ESPR), Informationen 2024/2025.
- EUR-Lex: Regulation (EU) 2023/2854 - Data Act, harmonised rules on fair access to and use of data.
- EUR-Lex: Regulation (EU) 2022/868 - Data Governance Act, European data governance and common European data spaces.
- EUR-Lex: Regulation (EU) 2024/2847 - Cyber Resilience Act, horizontal cybersecurity requirements for products with digital elements.
- NIST: Artificial Intelligence Risk Management Framework, 2023; NIST Cybersecurity Framework 2.0, 2024.
- United Nations: Transforming our world - The 2030 Agenda for Sustainable Development and Sustainable Development Goals.