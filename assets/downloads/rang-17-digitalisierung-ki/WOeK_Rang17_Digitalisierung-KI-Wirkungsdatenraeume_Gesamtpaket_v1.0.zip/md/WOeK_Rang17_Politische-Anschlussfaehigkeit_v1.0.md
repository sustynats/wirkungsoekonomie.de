# Politische Anschlussfähigkeit Rang 17

## Umsetzungsoptionen, Zielkonflikte und Schutz vor Technokratie

**Autorin:** Natalie Weber  
**Referenz:** Wirkungsökonomie  
**Version:** 1.0  
**Stand:** Mai 2026  
**Status:** Entwurf

## Kurzfassung
Politische Anschlussfähigkeit

## Inhaltsverzeichnis
1. Aufgabe der Politik
2. Rahmenbedingungen
3. Zielkonflikte
4. Rollenverteilung
5. Schutz vor Technokratie

## 1. Aufgabe der Politik

Politik muss digitale Infrastrukturen so rahmen, dass sie Rückkopplung ermöglichen, Rechte schützen und Machtkonzentration begrenzen. Sie darf Digitalisierung nicht nur als Standortpolitik verstehen, sondern als Wirkungsarchitektur für Demokratie, Wirtschaft, Verwaltung, Produktverantwortung und Resilienz.


## 2. Rahmenbedingungen

Benötigt werden Datenschutz, Datenzugang, Interoperabilität, KI-Aufsicht, Plattformtransparenz, Cyberresilienz, öffentliche Standards, Registerrecht, Auditpflichten und Widerspruchswege. Öffentliche Beschaffung muss digitale Wirkungskriterien aufnehmen.


## 3. Zielkonflikte

Innovation vs. Vorsorge, Transparenz vs. Geschäftsgeheimnisse, Datenzugang vs. Datenschutz, KI-Effizienz vs. Rechtsschutz, Produkttransparenz vs. kleine Unternehmen, Plattformfreiheit vs. Desinformationsschutz, Sicherheit vs. Freiheitsrechte.


## 4. Rollenverteilung

Der Bund setzt Rechtsrahmen und Standards. Länder und Kommunen pilotieren Verwaltung, Bildung und Beschaffung. Unternehmen liefern Daten und verbessern Systeme. Prüfer:innen sichern Datenqualität. Wissenschaft evaluiert. Zivilgesellschaft kontrolliert. Bürger:innen erhalten verständliche Informationen und Widerspruchsrechte.


## 5. Schutz vor Technokratie

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext und keine technokratische Steuerungsmaschine. Sie liefert einen Bewertungs- und Steuerungsrahmen. Parteien, Parlamente, Verwaltungen, Unternehmen und Zivilgesellschaft behalten Ausgestaltungsspielraum. Entscheidend ist, ob digitale Regeln, KI-Systeme, Datenräume, Plattformen und Produktpässe überprüfbar positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugen. Digitale Wirkungssteuerung darf keine private Lebensführung überwachen, keine Menschen klassifizieren, keine Gesinnung messen und keine Social-Credit-Logik erzeugen. Bewertet werden Produkte, Organisationen, Systeme, Prozesse, Kapitalflüsse, öffentliche Maßnahmen und Infrastrukturen. Wo Menschen betroffen sind, gelten Datenschutz, Rechtsschutz, Widerspruch, Transparenz und menschliche Entscheidungspflicht.


## Quellen und Anschlussstellen
### Interne Quellen
- Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands. Das Standardwerk der Wirkungsökonomie, Manuskriptfassung 2026, Teil XIII - Digitalisierung, KI und Wirkungsdatenräume.
- Natalie Weber: Systemmodell der Wirkungsökonomie. Die systemische Ordnungskarte Mensch-Planet-Demokratie, 2025.
- Natalie Weber: Technische Leitlinien zum Wirkungssteuergesetz (WUStG), Vollversion Extended, August 2025.
- Natalie Weber: WP Produkte - Produktbesteuerung durch Wirkung, 2025.
- Natalie Weber: Wirkungsoekonomie in der Lieferkette, September 2025.
### Externe Anschlussstellen
- European Commission: AI Act - Shaping Europe's digital future. Offizielle Informationen zum EU AI Act, Inkrafttreten 1. August 2024, stufenweise Anwendung bis 2026 und GPAI-Pflichten ab 2025.
- European Commission: Digital Product Passport unter der Ecodesign for Sustainable Products Regulation (ESPR), Informationen 2024/2025.
- EUR-Lex: Regulation (EU) 2023/2854 - Data Act, harmonised rules on fair access to and use of data.
- EUR-Lex: Regulation (EU) 2022/868 - Data Governance Act, European data governance and common European data spaces.
- EUR-Lex: Regulation (EU) 2024/2847 - Cyber Resilience Act, horizontal cybersecurity requirements for products with digital elements.
- NIST: Artificial Intelligence Risk Management Framework, 2023; NIST Cybersecurity Framework 2.0, 2024.
- United Nations: Transforming our world - The 2030 Agenda for Sustainable Development and Sustainable Development Goals.