# Gesamtdossier Rang 17

## Digitalisierung, KI und Wirkungsdatenräume

**Autorin:** Natalie Weber  
**Referenz:** Wirkungsökonomie  
**Version:** 1.0  
**Stand:** Mai 2026  
**Status:** Langfassungsentwurf

## Kurzfassung
Gesamtdossier im Dossier-Niveau

## Inhaltsverzeichnis
1. Executive Summary
2. Begriffslogik
3. Digitale Produktpässe als Produktgedächtnis - Wirkungsraum
4. Digitale Produktpässe als Produktgedächtnis - Umsetzung und Governance
5. Digitale Produktpässe als Produktgedächtnis - Website- und Downloadanforderungen
6. Wirkungsdatenräume - Wirkungsraum
7. Wirkungsdatenräume - Umsetzung und Governance
8. Wirkungsdatenräume - Website- und Downloadanforderungen
9. KI-Governance - Wirkungsraum
10. KI-Governance - Umsetzung und Governance
11. KI-Governance - Website- und Downloadanforderungen
12. Algorithmische Fairness und digitale Rechte - Wirkungsraum
13. Algorithmische Fairness und digitale Rechte - Umsetzung und Governance
14. Algorithmische Fairness und digitale Rechte - Website- und Downloadanforderungen
15. Digitale Souveränität - Wirkungsraum
16. Digitale Souveränität - Umsetzung und Governance
17. Digitale Souveränität - Website- und Downloadanforderungen
18. Cyberresilienz der Wirkungsarchitektur - Wirkungsraum
19. Cyberresilienz der Wirkungsarchitektur - Umsetzung und Governance
20. Cyberresilienz der Wirkungsarchitektur - Website- und Downloadanforderungen
21. Plattformlogik und Resonanzräume - Wirkungsraum
22. Plattformlogik und Resonanzräume - Umsetzung und Governance
23. Plattformlogik und Resonanzräume - Website- und Downloadanforderungen
24. Wirkungsscanner und Bürger:innen-Instrumente - Wirkungsraum
25. Wirkungsscanner und Bürger:innen-Instrumente - Umsetzung und Governance
26. Wirkungsscanner und Bürger:innen-Instrumente - Website- und Downloadanforderungen
27. Interoperabilität, Register und Schnittstellen - Wirkungsraum
28. Interoperabilität, Register und Schnittstellen - Umsetzung und Governance
29. Interoperabilität, Register und Schnittstellen - Website- und Downloadanforderungen
30. Audit, Assurance und Datenqualität - Wirkungsraum
31. Audit, Assurance und Datenqualität - Umsetzung und Governance
32. Audit, Assurance und Datenqualität - Website- und Downloadanforderungen
33. Politische Anschlussfähigkeit
34. SDG-/SDG+-Bezug
35. Quellenrahmen

## 1. Executive Summary

Wirkung wird in diesem Portal neutral und relational verwendet. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Digitalisierung, KI und Datenräume werden deshalb nicht nach Neuheitsgrad, Marktwert oder Geschwindigkeit bewertet, sondern danach, ob sie bessere Wahrnehmung, Rückkopplung, Lernfähigkeit, Rechtsschutz, Transparenz und demokratische Kontrolle ermöglichen.

Das Gesamtdossier beschreibt Rang 17 als digitale Infrastrukturschicht der Wirkungsökonomie. Es verbindet Digital Product Passports, Wirkungsdatenräume, KI-Governance, algorithmische Fairness, digitale Souveränität, Cyberresilienz, Plattformlogik, Wirkungsscanner, Interoperabilität, Register, Audit und politische Anschlussfähigkeit zu einer gemeinsamen Architektur.


## 2. Begriffslogik

Digitalisierung ist nicht gleich Wirkung. Eine App, ein Dashboard, ein KI-Modell oder ein Datenraum erzeugen erst dann positive Wirkung, wenn reale Zustände verbessert werden. Deshalb unterscheidet das Dossier Wirkungspotenzial, Wirkungsrisiko, tatsächliche Wirkung, Wirkungsbewertung, Netto-Wirkung und Transformationswirkung.


## 3. Digitale Produktpässe als Produktgedächtnis - Wirkungsraum

DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Produkttransparenz entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung braucht Produkttransparenz eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Produkttransparenz dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 4. Digitale Produktpässe als Produktgedächtnis - Umsetzung und Governance

Der Umsetzungspfad für DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung beginnt mit einer klaren Abgrenzung des Wirkungsraums. Danach werden Datenquellen, rechtliche Grundlagen, Rollen, Verantwortlichkeiten und Korrekturwege festgelegt. Erst danach darf die technische Umsetzung beginnen. Diese Reihenfolge schützt davor, dass Technik die Governance ersetzt.

Für DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung braucht es mindestens drei Kontrollformen: interne Verantwortlichkeit, externe Prüfung und demokratische oder öffentliche Nachvollziehbarkeit. Interne Verantwortlichkeit bedeutet klare Rollen. Externe Prüfung bedeutet unabhängige Audits. Öffentliche Nachvollziehbarkeit bedeutet verständliche Informationen, die nicht nur Expert:innen zugänglich sind.

Der wichtigste Schutz ist die Nichtverwechslung von Daten und Wahrheit. Daten sind Hinweise auf Zustände, keine automatische Bewertung. Bewertung braucht Referenzrahmen, Kontext, Unsicherheitssprache und Widerspruch. Deshalb muss DPP, WÖk-ID, Datenqualität und Wirkungsscanner für Produktwirkung versioniert, prüfbar und korrigierbar bleiben.


## 5. Digitale Produktpässe als Produktgedächtnis - Website- und Downloadanforderungen

Für die Website muss Digitale Produktpässe als Produktgedächtnis als vollständige Onlinefassung erscheinen. Ein Teaser reicht nicht. Die Seite braucht Inhaltsverzeichnis, Downloadlink zu PDF und DOCX, Quellenblock, Glossarlinks, SDG-/SDG+-Block, politische Anschlussfähigkeit, mobile Tabellen und Querverlinkungen.

Als Download muss Digitale Produktpässe als Produktgedächtnis im Corporate Design der Wirkungsökonomie bereitstehen: Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Quellen, Glossarlinks und Verweis auf die Onlinefassung. Keine CodeX-Anweisungen oder internen Arbeitsnotizen dürfen öffentlich sichtbar sein.


## 6. Wirkungsdatenräume - Wirkungsraum

Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Datenrückkopplung entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit braucht Datenrückkopplung eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Datenrückkopplung dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 7. Wirkungsdatenräume - Umsetzung und Governance

Der Umsetzungspfad für Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit beginnt mit einer klaren Abgrenzung des Wirkungsraums. Danach werden Datenquellen, rechtliche Grundlagen, Rollen, Verantwortlichkeiten und Korrekturwege festgelegt. Erst danach darf die technische Umsetzung beginnen. Diese Reihenfolge schützt davor, dass Technik die Governance ersetzt.

Für Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit braucht es mindestens drei Kontrollformen: interne Verantwortlichkeit, externe Prüfung und demokratische oder öffentliche Nachvollziehbarkeit. Interne Verantwortlichkeit bedeutet klare Rollen. Externe Prüfung bedeutet unabhängige Audits. Öffentliche Nachvollziehbarkeit bedeutet verständliche Informationen, die nicht nur Expert:innen zugänglich sind.

Der wichtigste Schutz ist die Nichtverwechslung von Daten und Wahrheit. Daten sind Hinweise auf Zustände, keine automatische Bewertung. Bewertung braucht Referenzrahmen, Kontext, Unsicherheitssprache und Widerspruch. Deshalb muss Föderierte Dateninfrastruktur für Wirtschaft, Staat, Kapital und Öffentlichkeit versioniert, prüfbar und korrigierbar bleiben.


## 8. Wirkungsdatenräume - Website- und Downloadanforderungen

Für die Website muss Wirkungsdatenräume als vollständige Onlinefassung erscheinen. Ein Teaser reicht nicht. Die Seite braucht Inhaltsverzeichnis, Downloadlink zu PDF und DOCX, Quellenblock, Glossarlinks, SDG-/SDG+-Block, politische Anschlussfähigkeit, mobile Tabellen und Querverlinkungen.

Als Download muss Wirkungsdatenräume im Corporate Design der Wirkungsökonomie bereitstehen: Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Quellen, Glossarlinks und Verweis auf die Onlinefassung. Keine CodeX-Anweisungen oder internen Arbeitsnotizen dürfen öffentlich sichtbar sein.


## 9. KI-Governance - Wirkungsraum

KI als Werkzeug der Wirkung, nicht als neuer Kompass muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Verantwortung entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für KI als Werkzeug der Wirkung, nicht als neuer Kompass braucht Verantwortung eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu KI als Werkzeug der Wirkung, nicht als neuer Kompass. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Verantwortung dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für KI als Werkzeug der Wirkung, nicht als neuer Kompass sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 10. KI-Governance - Umsetzung und Governance

Der Umsetzungspfad für KI als Werkzeug der Wirkung, nicht als neuer Kompass beginnt mit einer klaren Abgrenzung des Wirkungsraums. Danach werden Datenquellen, rechtliche Grundlagen, Rollen, Verantwortlichkeiten und Korrekturwege festgelegt. Erst danach darf die technische Umsetzung beginnen. Diese Reihenfolge schützt davor, dass Technik die Governance ersetzt.

Für KI als Werkzeug der Wirkung, nicht als neuer Kompass braucht es mindestens drei Kontrollformen: interne Verantwortlichkeit, externe Prüfung und demokratische oder öffentliche Nachvollziehbarkeit. Interne Verantwortlichkeit bedeutet klare Rollen. Externe Prüfung bedeutet unabhängige Audits. Öffentliche Nachvollziehbarkeit bedeutet verständliche Informationen, die nicht nur Expert:innen zugänglich sind.

Der wichtigste Schutz ist die Nichtverwechslung von Daten und Wahrheit. Daten sind Hinweise auf Zustände, keine automatische Bewertung. Bewertung braucht Referenzrahmen, Kontext, Unsicherheitssprache und Widerspruch. Deshalb muss KI als Werkzeug der Wirkung, nicht als neuer Kompass versioniert, prüfbar und korrigierbar bleiben.


## 11. KI-Governance - Website- und Downloadanforderungen

Für die Website muss KI-Governance als vollständige Onlinefassung erscheinen. Ein Teaser reicht nicht. Die Seite braucht Inhaltsverzeichnis, Downloadlink zu PDF und DOCX, Quellenblock, Glossarlinks, SDG-/SDG+-Block, politische Anschlussfähigkeit, mobile Tabellen und Querverlinkungen.

Als Download muss KI-Governance im Corporate Design der Wirkungsökonomie bereitstehen: Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Quellen, Glossarlinks und Verweis auf die Onlinefassung. Keine CodeX-Anweisungen oder internen Arbeitsnotizen dürfen öffentlich sichtbar sein.


## 12. Algorithmische Fairness und digitale Rechte - Wirkungsraum

Schutz vor Sortierung, Ausschluss und Manipulation muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Fairness entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Schutz vor Sortierung, Ausschluss und Manipulation braucht Fairness eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Schutz vor Sortierung, Ausschluss und Manipulation. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Fairness dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Schutz vor Sortierung, Ausschluss und Manipulation sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 13. Algorithmische Fairness und digitale Rechte - Umsetzung und Governance

Der Umsetzungspfad für Schutz vor Sortierung, Ausschluss und Manipulation beginnt mit einer klaren Abgrenzung des Wirkungsraums. Danach werden Datenquellen, rechtliche Grundlagen, Rollen, Verantwortlichkeiten und Korrekturwege festgelegt. Erst danach darf die technische Umsetzung beginnen. Diese Reihenfolge schützt davor, dass Technik die Governance ersetzt.

Für Schutz vor Sortierung, Ausschluss und Manipulation braucht es mindestens drei Kontrollformen: interne Verantwortlichkeit, externe Prüfung und demokratische oder öffentliche Nachvollziehbarkeit. Interne Verantwortlichkeit bedeutet klare Rollen. Externe Prüfung bedeutet unabhängige Audits. Öffentliche Nachvollziehbarkeit bedeutet verständliche Informationen, die nicht nur Expert:innen zugänglich sind.

Der wichtigste Schutz ist die Nichtverwechslung von Daten und Wahrheit. Daten sind Hinweise auf Zustände, keine automatische Bewertung. Bewertung braucht Referenzrahmen, Kontext, Unsicherheitssprache und Widerspruch. Deshalb muss Schutz vor Sortierung, Ausschluss und Manipulation versioniert, prüfbar und korrigierbar bleiben.


## 14. Algorithmische Fairness und digitale Rechte - Website- und Downloadanforderungen

Für die Website muss Algorithmische Fairness und digitale Rechte als vollständige Onlinefassung erscheinen. Ein Teaser reicht nicht. Die Seite braucht Inhaltsverzeichnis, Downloadlink zu PDF und DOCX, Quellenblock, Glossarlinks, SDG-/SDG+-Block, politische Anschlussfähigkeit, mobile Tabellen und Querverlinkungen.

Als Download muss Algorithmische Fairness und digitale Rechte im Corporate Design der Wirkungsökonomie bereitstehen: Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Quellen, Glossarlinks und Verweis auf die Onlinefassung. Keine CodeX-Anweisungen oder internen Arbeitsnotizen dürfen öffentlich sichtbar sein.


## 15. Digitale Souveränität - Wirkungsraum

Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Souveränität entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume braucht Souveränität eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Souveränität dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 16. Digitale Souveränität - Umsetzung und Governance

Der Umsetzungspfad für Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume beginnt mit einer klaren Abgrenzung des Wirkungsraums. Danach werden Datenquellen, rechtliche Grundlagen, Rollen, Verantwortlichkeiten und Korrekturwege festgelegt. Erst danach darf die technische Umsetzung beginnen. Diese Reihenfolge schützt davor, dass Technik die Governance ersetzt.

Für Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume braucht es mindestens drei Kontrollformen: interne Verantwortlichkeit, externe Prüfung und demokratische oder öffentliche Nachvollziehbarkeit. Interne Verantwortlichkeit bedeutet klare Rollen. Externe Prüfung bedeutet unabhängige Audits. Öffentliche Nachvollziehbarkeit bedeutet verständliche Informationen, die nicht nur Expert:innen zugänglich sind.

Der wichtigste Schutz ist die Nichtverwechslung von Daten und Wahrheit. Daten sind Hinweise auf Zustände, keine automatische Bewertung. Bewertung braucht Referenzrahmen, Kontext, Unsicherheitssprache und Widerspruch. Deshalb muss Daten, Infrastrukturen und Standards als demokratische Gestaltungsräume versioniert, prüfbar und korrigierbar bleiben.


## 17. Digitale Souveränität - Website- und Downloadanforderungen

Für die Website muss Digitale Souveränität als vollständige Onlinefassung erscheinen. Ein Teaser reicht nicht. Die Seite braucht Inhaltsverzeichnis, Downloadlink zu PDF und DOCX, Quellenblock, Glossarlinks, SDG-/SDG+-Block, politische Anschlussfähigkeit, mobile Tabellen und Querverlinkungen.

Als Download muss Digitale Souveränität im Corporate Design der Wirkungsökonomie bereitstehen: Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Quellen, Glossarlinks und Verweis auf die Onlinefassung. Keine CodeX-Anweisungen oder internen Arbeitsnotizen dürfen öffentlich sichtbar sein.


## 18. Cyberresilienz der Wirkungsarchitektur - Wirkungsraum

Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Resilienz entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung braucht Resilienz eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Resilienz dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 19. Cyberresilienz der Wirkungsarchitektur - Umsetzung und Governance

Der Umsetzungspfad für Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung beginnt mit einer klaren Abgrenzung des Wirkungsraums. Danach werden Datenquellen, rechtliche Grundlagen, Rollen, Verantwortlichkeiten und Korrekturwege festgelegt. Erst danach darf die technische Umsetzung beginnen. Diese Reihenfolge schützt davor, dass Technik die Governance ersetzt.

Für Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung braucht es mindestens drei Kontrollformen: interne Verantwortlichkeit, externe Prüfung und demokratische oder öffentliche Nachvollziehbarkeit. Interne Verantwortlichkeit bedeutet klare Rollen. Externe Prüfung bedeutet unabhängige Audits. Öffentliche Nachvollziehbarkeit bedeutet verständliche Informationen, die nicht nur Expert:innen zugänglich sind.

Der wichtigste Schutz ist die Nichtverwechslung von Daten und Wahrheit. Daten sind Hinweise auf Zustände, keine automatische Bewertung. Bewertung braucht Referenzrahmen, Kontext, Unsicherheitssprache und Widerspruch. Deshalb muss Digitale Stabilität als Voraussetzung für Wirkung, Vertrauen und Verwaltung versioniert, prüfbar und korrigierbar bleiben.


## 20. Cyberresilienz der Wirkungsarchitektur - Website- und Downloadanforderungen

Für die Website muss Cyberresilienz der Wirkungsarchitektur als vollständige Onlinefassung erscheinen. Ein Teaser reicht nicht. Die Seite braucht Inhaltsverzeichnis, Downloadlink zu PDF und DOCX, Quellenblock, Glossarlinks, SDG-/SDG+-Block, politische Anschlussfähigkeit, mobile Tabellen und Querverlinkungen.

Als Download muss Cyberresilienz der Wirkungsarchitektur im Corporate Design der Wirkungsökonomie bereitstehen: Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Quellen, Glossarlinks und Verweis auf die Onlinefassung. Keine CodeX-Anweisungen oder internen Arbeitsnotizen dürfen öffentlich sichtbar sein.


## 21. Plattformlogik und Resonanzräume - Wirkungsraum

Digitale Öffentlichkeit als Wirkungsraum muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Diskursqualität entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Digitale Öffentlichkeit als Wirkungsraum braucht Diskursqualität eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Digitale Öffentlichkeit als Wirkungsraum. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Diskursqualität dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Digitale Öffentlichkeit als Wirkungsraum sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 22. Plattformlogik und Resonanzräume - Umsetzung und Governance

Der Umsetzungspfad für Digitale Öffentlichkeit als Wirkungsraum beginnt mit einer klaren Abgrenzung des Wirkungsraums. Danach werden Datenquellen, rechtliche Grundlagen, Rollen, Verantwortlichkeiten und Korrekturwege festgelegt. Erst danach darf die technische Umsetzung beginnen. Diese Reihenfolge schützt davor, dass Technik die Governance ersetzt.

Für Digitale Öffentlichkeit als Wirkungsraum braucht es mindestens drei Kontrollformen: interne Verantwortlichkeit, externe Prüfung und demokratische oder öffentliche Nachvollziehbarkeit. Interne Verantwortlichkeit bedeutet klare Rollen. Externe Prüfung bedeutet unabhängige Audits. Öffentliche Nachvollziehbarkeit bedeutet verständliche Informationen, die nicht nur Expert:innen zugänglich sind.

Der wichtigste Schutz ist die Nichtverwechslung von Daten und Wahrheit. Daten sind Hinweise auf Zustände, keine automatische Bewertung. Bewertung braucht Referenzrahmen, Kontext, Unsicherheitssprache und Widerspruch. Deshalb muss Digitale Öffentlichkeit als Wirkungsraum versioniert, prüfbar und korrigierbar bleiben.


## 23. Plattformlogik und Resonanzräume - Website- und Downloadanforderungen

Für die Website muss Plattformlogik und Resonanzräume als vollständige Onlinefassung erscheinen. Ein Teaser reicht nicht. Die Seite braucht Inhaltsverzeichnis, Downloadlink zu PDF und DOCX, Quellenblock, Glossarlinks, SDG-/SDG+-Block, politische Anschlussfähigkeit, mobile Tabellen und Querverlinkungen.

Als Download muss Plattformlogik und Resonanzräume im Corporate Design der Wirkungsökonomie bereitstehen: Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Quellen, Glossarlinks und Verweis auf die Onlinefassung. Keine CodeX-Anweisungen oder internen Arbeitsnotizen dürfen öffentlich sichtbar sein.


## 24. Wirkungsscanner und Bürger:innen-Instrumente - Wirkungsraum

Produktwirkung verständlich machen ohne private Lebensführung zu überwachen muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Verständlichkeit entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Produktwirkung verständlich machen ohne private Lebensführung zu überwachen braucht Verständlichkeit eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Produktwirkung verständlich machen ohne private Lebensführung zu überwachen. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Verständlichkeit dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Produktwirkung verständlich machen ohne private Lebensführung zu überwachen sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 25. Wirkungsscanner und Bürger:innen-Instrumente - Umsetzung und Governance

Der Umsetzungspfad für Produktwirkung verständlich machen ohne private Lebensführung zu überwachen beginnt mit einer klaren Abgrenzung des Wirkungsraums. Danach werden Datenquellen, rechtliche Grundlagen, Rollen, Verantwortlichkeiten und Korrekturwege festgelegt. Erst danach darf die technische Umsetzung beginnen. Diese Reihenfolge schützt davor, dass Technik die Governance ersetzt.

Für Produktwirkung verständlich machen ohne private Lebensführung zu überwachen braucht es mindestens drei Kontrollformen: interne Verantwortlichkeit, externe Prüfung und demokratische oder öffentliche Nachvollziehbarkeit. Interne Verantwortlichkeit bedeutet klare Rollen. Externe Prüfung bedeutet unabhängige Audits. Öffentliche Nachvollziehbarkeit bedeutet verständliche Informationen, die nicht nur Expert:innen zugänglich sind.

Der wichtigste Schutz ist die Nichtverwechslung von Daten und Wahrheit. Daten sind Hinweise auf Zustände, keine automatische Bewertung. Bewertung braucht Referenzrahmen, Kontext, Unsicherheitssprache und Widerspruch. Deshalb muss Produktwirkung verständlich machen ohne private Lebensführung zu überwachen versioniert, prüfbar und korrigierbar bleiben.


## 26. Wirkungsscanner und Bürger:innen-Instrumente - Website- und Downloadanforderungen

Für die Website muss Wirkungsscanner und Bürger:innen-Instrumente als vollständige Onlinefassung erscheinen. Ein Teaser reicht nicht. Die Seite braucht Inhaltsverzeichnis, Downloadlink zu PDF und DOCX, Quellenblock, Glossarlinks, SDG-/SDG+-Block, politische Anschlussfähigkeit, mobile Tabellen und Querverlinkungen.

Als Download muss Wirkungsscanner und Bürger:innen-Instrumente im Corporate Design der Wirkungsökonomie bereitstehen: Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Quellen, Glossarlinks und Verweis auf die Onlinefassung. Keine CodeX-Anweisungen oder internen Arbeitsnotizen dürfen öffentlich sichtbar sein.


## 27. Interoperabilität, Register und Schnittstellen - Wirkungsraum

Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Anschlussfähigkeit entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen braucht Anschlussfähigkeit eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Anschlussfähigkeit dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 28. Interoperabilität, Register und Schnittstellen - Umsetzung und Governance

Der Umsetzungspfad für Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen beginnt mit einer klaren Abgrenzung des Wirkungsraums. Danach werden Datenquellen, rechtliche Grundlagen, Rollen, Verantwortlichkeiten und Korrekturwege festgelegt. Erst danach darf die technische Umsetzung beginnen. Diese Reihenfolge schützt davor, dass Technik die Governance ersetzt.

Für Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen braucht es mindestens drei Kontrollformen: interne Verantwortlichkeit, externe Prüfung und demokratische oder öffentliche Nachvollziehbarkeit. Interne Verantwortlichkeit bedeutet klare Rollen. Externe Prüfung bedeutet unabhängige Audits. Öffentliche Nachvollziehbarkeit bedeutet verständliche Informationen, die nicht nur Expert:innen zugänglich sind.

Der wichtigste Schutz ist die Nichtverwechslung von Daten und Wahrheit. Daten sind Hinweise auf Zustände, keine automatische Bewertung. Bewertung braucht Referenzrahmen, Kontext, Unsicherheitssprache und Widerspruch. Deshalb muss Die technische Ordnung hinter WÖk-IDs, Produktpässen und Datenräumen versioniert, prüfbar und korrigierbar bleiben.


## 29. Interoperabilität, Register und Schnittstellen - Website- und Downloadanforderungen

Für die Website muss Interoperabilität, Register und Schnittstellen als vollständige Onlinefassung erscheinen. Ein Teaser reicht nicht. Die Seite braucht Inhaltsverzeichnis, Downloadlink zu PDF und DOCX, Quellenblock, Glossarlinks, SDG-/SDG+-Block, politische Anschlussfähigkeit, mobile Tabellen und Querverlinkungen.

Als Download muss Interoperabilität, Register und Schnittstellen im Corporate Design der Wirkungsökonomie bereitstehen: Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Quellen, Glossarlinks und Verweis auf die Onlinefassung. Keine CodeX-Anweisungen oder internen Arbeitsnotizen dürfen öffentlich sichtbar sein.


## 30. Audit, Assurance und Datenqualität - Wirkungsraum

Schutz vor Wirkungssimulation und Scheingenauigkeit muss in der Wirkungsökonomie nicht nur technisch, sondern systemisch gelesen werden. Der Aspekt Prüfbarkeit entscheidet darüber, ob ein digitales Instrument lediglich Aktivität erzeugt oder tatsächlich Zustände verbessert. Eine digitale Lösung kann Prozesse beschleunigen und dennoch negative Netto-Wirkung erzeugen, wenn sie Fehler automatisiert, Zuständigkeiten verschleiert, Menschen ausschließt oder Datenmacht zentralisiert. Umgekehrt kann dieselbe Technologie positive Wirkung entfalten, wenn sie Transparenz schafft, Datenqualität erhöht, Entscheidungen überprüfbar macht und Korrektur ermöglicht.

Für Schutz vor Wirkungssimulation und Scheingenauigkeit braucht Prüfbarkeit eine klare Architektur aus Datenquelle, Datenqualitätsklasse, Zugriffsrecht, Prüfstatus, Versionierung, Widerspruchsweg und Verantwortlichkeit. Ohne diese Architektur entsteht Scheingenauigkeit. Zahlen wirken objektiv, obwohl sie unvollständig, veraltet, interessengeleitet oder nicht prüfbar sein können. Deshalb ist die zentrale Frage nicht nur, welche Daten vorhanden sind, sondern welche Entscheidung durch diese Daten verändert wird und wer diese Veränderung kontrollieren kann.

Ein Beispiel: Eine Kommune, ein Unternehmen oder eine öffentliche Beschaffung nutzt ein digitales Dashboard zu Schutz vor Wirkungssimulation und Scheingenauigkeit. In einer oberflächlichen Digitalisierungslogik zählt, ob das Dashboard modern aussieht und Daten zusammenführt. In der Wirkungsökonomie zählt, ob Prüfbarkeit dadurch besser gesteuert wird: Werden Risiken früher erkannt? Werden Betroffene geschützt? Sinkt Bürokratie? Werden Entscheidungen erklärbar? Gibt es analoge Ausweichwege? Können falsche Daten korrigiert werden? Wird die Wirkung öffentlich verständlich?

Mögliche Indikatoren für Schutz vor Wirkungssimulation und Scheingenauigkeit sind Datenaktualität, Prüftiefe, Fehlerquote, Korrekturzeit, Widerspruchszugang, Interoperabilität, Barrierefreiheit, Energiebedarf, Bias-Prüfstatus, Wiederherstellungszeit, Datenherkunft und Nachweisabdeckung. Sie müssen mit SDGs und SDG+ verknüpft werden. Entscheidend ist die Netto-Wirkung: Ein guter technischer Wert darf keine rote Linie verdecken, etwa Diskriminierung, fehlenden Rechtsschutz, manipulative Reichweitensteuerung oder nicht kontrollierbare Datenmacht.


## 31. Audit, Assurance und Datenqualität - Umsetzung und Governance

Der Umsetzungspfad für Schutz vor Wirkungssimulation und Scheingenauigkeit beginnt mit einer klaren Abgrenzung des Wirkungsraums. Danach werden Datenquellen, rechtliche Grundlagen, Rollen, Verantwortlichkeiten und Korrekturwege festgelegt. Erst danach darf die technische Umsetzung beginnen. Diese Reihenfolge schützt davor, dass Technik die Governance ersetzt.

Für Schutz vor Wirkungssimulation und Scheingenauigkeit braucht es mindestens drei Kontrollformen: interne Verantwortlichkeit, externe Prüfung und demokratische oder öffentliche Nachvollziehbarkeit. Interne Verantwortlichkeit bedeutet klare Rollen. Externe Prüfung bedeutet unabhängige Audits. Öffentliche Nachvollziehbarkeit bedeutet verständliche Informationen, die nicht nur Expert:innen zugänglich sind.

Der wichtigste Schutz ist die Nichtverwechslung von Daten und Wahrheit. Daten sind Hinweise auf Zustände, keine automatische Bewertung. Bewertung braucht Referenzrahmen, Kontext, Unsicherheitssprache und Widerspruch. Deshalb muss Schutz vor Wirkungssimulation und Scheingenauigkeit versioniert, prüfbar und korrigierbar bleiben.


## 32. Audit, Assurance und Datenqualität - Website- und Downloadanforderungen

Für die Website muss Audit, Assurance und Datenqualität als vollständige Onlinefassung erscheinen. Ein Teaser reicht nicht. Die Seite braucht Inhaltsverzeichnis, Downloadlink zu PDF und DOCX, Quellenblock, Glossarlinks, SDG-/SDG+-Block, politische Anschlussfähigkeit, mobile Tabellen und Querverlinkungen.

Als Download muss Audit, Assurance und Datenqualität im Corporate Design der Wirkungsökonomie bereitstehen: Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand, Status, Kurzfassung, Quellen, Glossarlinks und Verweis auf die Onlinefassung. Keine CodeX-Anweisungen oder internen Arbeitsnotizen dürfen öffentlich sichtbar sein.


## 33. Politische Anschlussfähigkeit

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext und keine technokratische Steuerungsmaschine. Sie liefert einen Bewertungs- und Steuerungsrahmen. Parteien, Parlamente, Verwaltungen, Unternehmen und Zivilgesellschaft behalten Ausgestaltungsspielraum. Entscheidend ist, ob digitale Regeln, KI-Systeme, Datenräume, Plattformen und Produktpässe überprüfbar positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugen. Digitale Wirkungssteuerung darf keine private Lebensführung überwachen, keine Menschen klassifizieren, keine Gesinnung messen und keine Social-Credit-Logik erzeugen. Bewertet werden Produkte, Organisationen, Systeme, Prozesse, Kapitalflüsse, öffentliche Maßnahmen und Infrastrukturen. Wo Menschen betroffen sind, gelten Datenschutz, Rechtsschutz, Widerspruch, Transparenz und menschliche Entscheidungspflicht.


## 34. SDG-/SDG+-Bezug

Rang 17 verbindet besonders SDG 4, SDG 8, SDG 9, SDG 10, SDG 12, SDG 13, SDG 16 und SDG 17. Digitalisierung kann Bildung, Arbeit, Infrastruktur, nachhaltige Produktion, Klimatransparenz, starke Institutionen und Partnerschaften unterstützen. Dieselben Systeme können diese Ziele aber auch schwächen, wenn sie Ausschluss, Überwachung, Desinformation, Machtkonzentration, Energieverschwendung oder manipulative Plattformlogiken verstärken. SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt, digitale Selbstbestimmung, algorithmische Fairness und Schutz vor Desinformation.


## 35. Quellenrahmen

Der externe Anschlussrahmen umfasst den EU AI Act, den Digital Product Passport im Rahmen der ESPR, Data Act, Data Governance Act, Cyber Resilience Act, NIST AI RMF, NIST Cybersecurity Framework 2.0 und die UN Agenda 2030. Diese Quellen liefern regulatorische, technische und normative Anschlussstellen. Sie ersetzen nicht die Wirkungslogik, sondern werden in der Wirkungsökonomie als Daten-, Rechts- und Governance-Bezugspunkte genutzt.


## Quellen und Anschlussstellen
### Interne Quellen
- Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands. Das Standardwerk der Wirkungsökonomie, Manuskriptfassung 2026, Teil XIII - Digitalisierung, KI und Wirkungsdatenräume.
- Natalie Weber: Systemmodell der Wirkungsökonomie. Die systemische Ordnungskarte Mensch-Planet-Demokratie, 2025.
- Natalie Weber: Technische Leitlinien zum Wirkungssteuergesetz (WUStG), Vollversion Extended, August 2025.
- Natalie Weber: WP Produkte - Produktbesteuerung durch Wirkung, 2025.
- Natalie Weber: Wirkungsoekonomie in der Lieferkette, September 2025.
### Externe Anschlussstellen
- European Commission: AI Act - Shaping Europe's digital future. Offizielle Informationen zum EU AI Act, Inkrafttreten 1. August 2024, stufenweise Anwendung bis 2026 und GPAI-Pflichten ab 2025.
- European Commission: Digital Product Passport unter der Ecodesign for Sustainable Products Regulation (ESPR), Informationen 2024/2025.
- EUR-Lex: Regulation (EU) 2023/2854 - Data Act, harmonised rules on fair access to and use of data.
- EUR-Lex: Regulation (EU) 2022/868 - Data Governance Act, European data governance and common European data spaces.
- EUR-Lex: Regulation (EU) 2024/2847 - Cyber Resilience Act, horizontal cybersecurity requirements for products with digital elements.
- NIST: Artificial Intelligence Risk Management Framework, 2023; NIST Cybersecurity Framework 2.0, 2024.
- United Nations: Transforming our world - The 2030 Agenda for Sustainable Development and Sustainable Development Goals.