# Downloadstruktur Rang 16

**Untertitel:** PDFs, HTML-Onlinefassungen, Markdownquellen und ZIP-Paket
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Portal:** Rang 16 - Sicherheit, Resilienz und globale Kooperation
**Version:** 1.0
**Status:** Struktur- und Prüfdatei v1.0
**Stand:** 24. Mai 2026

---

## Downloadstruktur

Dieses Dokument beschreibt die Download- und Onlinefassungslogik für Rang 16. Alle Haupttexte liegen als Markdown, HTML und PDF vor. Die HTML-Fassungen sind als vollständige Online-Volltexte angelegt. Die PDF-Fassungen dienen als Downloadfassung.

## Pflichtdownloads

- 00_portalstartseite.pdf - Rang 16 - Sicherheit, Resilienz und globale Kooperation
- 01_bestands_und_nachlieferliste.pdf - Bestands- und Nachlieferliste Rang 16
- 02_konzeptpapier.pdf - Konzeptpapier Rang 16
- 03_gesamtdossier.pdf - Gesamtdossier Rang 16
- 01_detail_sicherheit_als_wirkungsfrage.pdf - Detailkonzept Sicherheit als Wirkungsfrage
- 02_detail_resilienzstaat_kritische_funktionen.pdf - Detailkonzept Resilienzstaat und kritische Funktionen
- 03_detail_kritische_infrastruktur_demokratische_infrastruktur.pdf - Detailkonzept Kritische Infrastruktur als demokratische Infrastruktur
- 04_detail_cyberresilienz_digitale_verwundbarkeit.pdf - Detailkonzept Cyberresilienz und digitale Verwundbarkeit
- 05_detail_hybride_risiken_demokratieverteidigung.pdf - Detailkonzept Hybride Risiken und Demokratieverteidigung
- 06_detail_katastrophenschutz_bevoelkerungsvorsorge.pdf - Detailkonzept Katastrophenschutz und Bevölkerungsvorsorge
- 07_detail_energie_wasser_ernaehrung_gesundheit.pdf - Detailkonzept Energie-, Wasser-, Ernährungs- und Gesundheitsresilienz
- 08_detail_lieferketten_rohstoffe_finanzresilienz.pdf - Detailkonzept Lieferketten-, Rohstoff- und Finanzresilienz
- 09_detail_kommunale_resilienz_sozialraeume.pdf - Detailkonzept Kommunale Resilienz und Sozialräume
- 10_detail_dienstjahr_fuer_wirkung.pdf - Detailkonzept Dienstjahr für Wirkung
- 11_detail_aussenpolitik_globale_resilienz.pdf - Detailkonzept Außenpolitik, globale Resilienz und Kooperation
- 12_detail_wirkungsindikatoren_resilienz.pdf - Detailkonzept Wirkungsindikatoren für Sicherheit und Resilienz
- 16_sdg_sdgplus_block.pdf - SDG- und SDG+-Block Rang 16
- 17_politische_anschlussfaehigkeit.pdf - Politische Anschlussfähigkeit Rang 16
- 18_toolkarten.pdf - Toolkarten Rang 16
- 19_quellen_und_glossarlinks.pdf - Quellen und Glossarlinks Rang 16



## Metadaten je Dokument

- Titel und Untertitel
- Autorin: Natalie Weber
- Referenz: Wirkungsökonomie
- Portal: Rang 16 - Sicherheit, Resilienz und globale Kooperation
- Version: 1.0
- Status
- Stand: 24. Mai 2026
- Quellen- und Glossaranschluss
- Verweis auf Onlinefassung



## Website-Regeln

- Keine Downloadseite ohne Online-Volltext.
- Keine reinen Teaser statt Volltext.
- Keine internen Arbeitsanweisungen öffentlich.
- Keine en dashes oder Sonderstriche.
- Toolkarten mit Beschreibung, Nutzen, Status und Link.
- Druckfreundliche HTML-Struktur.
- Mobile Tabellen als responsive Cards oder horizontal scrollbar.
