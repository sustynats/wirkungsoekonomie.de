# Konzeptpapier Rang 16

**Untertitel:** Sicherheit, Resilienz und globale Kooperation in der Wirkungsökonomie
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Portal:** Rang 16 - Sicherheit, Resilienz und globale Kooperation
**Version:** 1.0
**Status:** Konzeptpapier v1.0
**Stand:** 24. Mai 2026

---

## Executive Summary

Sicherheit und Resilienz werden in der Wirkungsökonomie nicht militärisch verengt. Sie werden als Schutz kritischer Wirkungsbedingungen verstanden: Leben, Versorgung, Gesundheit, Wasser, Energie, Ernährung, Pflege, Kommunikation, Verwaltung, Recht, Daten, öffentliche Wahrheit, gesellschaftlicher Zusammenhalt und demokratische Korrekturfähigkeit. Rang 16 bündelt diese Perspektive als Portal für Sicherheit, Resilienz und globale Kooperation.


## Begriffliche Leitlinie

Für Rang 16 gilt der führende Begriffsleitfaden der Wirkungsökonomie. Wirkung ist neutral und relational. Sie beschreibt die tatsächliche Veränderung von Zuständen und kann positiv, negativ oder neutral sein. Bewertet wird Wirkung am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie.

Sicherheit wird deshalb nicht als bloße Abwehr, Kontrolle oder militärische Stärke verstanden. Sicherheit ist ein Wirkungszustand: Menschen bleiben geschützt, lebenswichtige Funktionen bleiben verfügbar, demokratische Korrekturfähigkeit bleibt erhalten, Infrastruktur bleibt belastbar, Information bleibt vertrauenswürdig und politische Entscheidungen bleiben rechtsstaatlich begrenzt.

Resilienz bedeutet nicht Abschottung. Resilienz bedeutet Lern-, Anpassungs- und Kooperationsfähigkeit unter Stress. Eine resiliente Gesellschaft kann Störungen aufnehmen, Grundfunktionen aufrechterhalten, Schaden begrenzen, aus Krisen lernen und ihre Freiheit bewahren.


## Warum Rang 16 notwendig ist

Die großen Krisen des 21. Jahrhunderts zeigen, dass klassische Ressortgrenzen nicht ausreichen. Ein Cyberangriff trifft nicht nur Technik. Er trifft Verwaltung, Gesundheit, Zahlungen, Vertrauen und politische Stabilität. Eine Dürre trifft nicht nur Landwirtschaft. Sie trifft Preise, Wasser, Ernährung, Migration, Konflikte, Versicherbarkeit und Haushalte. Eine Desinformationskampagne trifft nicht nur Meinungen. Sie trifft Wahrheit, Vertrauen, Institutionen, Wahlfähigkeit und die Bereitschaft zur Kooperation.

Rang 16 macht diese Kopplungen sichtbar. Er liest Sicherheit als Wirkung auf Mensch, Planet und Demokratie. Er fragt nicht nur nach Eintrittswahrscheinlichkeit, sondern nach Ausfallwirkung, Verwundbarkeit, Folgeschäden, Rückfallebenen, Lernfähigkeit und Freiheitsschutz.

## Grundprinzipien

- Prävention vor Reparatur: Frühes Handeln erhält Optionen.
- Kritische Funktionen statt isolierter Anlagen: Entscheidend ist die Wirkung eines Ausfalls.
- Freiheitsschutz: Sicherheit darf nicht zur Generalermächtigung werden.
- Dezentralität und Redundanz: Ausweichfähigkeit ist Teil der Stabilität.
- Transparenz und Vertrauen: Krisenkommunikation muss erklären, nicht beschönigen und nicht dramatisieren.
- Lernfähigkeit: Resilienz entsteht durch Rückkopplung, Evaluation und Korrektur.
- Kooperation statt Abschottung: Globale Resilienz braucht faire Partnerschaften.



## Portalarchitektur

Das Portal besteht aus einer Startseite, einem Konzeptpapier, einem Gesamtdossier, zwölf Detailkonzepten, einem Indikatorenblock, einem SDG-/SDG+-Block, Toolkarten, Quellen, Glossarlinks und Downloadfassungen.

## Abgrenzung

Rang 16 ersetzt keine Fachstrategien für Verteidigung, Polizei, Nachrichtendienste, Cybersecurity oder Katastrophenschutz. Es liefert den Wirkungsrahmen, in dem diese Strategien demokratisch, rechtlich, sozial, ökologisch und infrastrukturell eingeordnet werden können.


## SDG- und SDG+-Bezug

Rang 16 berührt mehrere SDGs direkt: SDG 3 Gesundheit und Wohlergehen, SDG 6 Wasser, SDG 7 Energie, SDG 9 Industrie, Innovation und Infrastruktur, SDG 11 nachhaltige Städte und Gemeinden, SDG 13 Klimaschutz, SDG 16 Frieden, Gerechtigkeit und starke Institutionen sowie SDG 17 Partnerschaften. Sicherheit und Resilienz sind keine Zusatzthemen, sondern Schutzbedingungen für die Erreichung dieser Ziele.

Der SDG+-Bezug ist zentral. Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlicher Zusammenhalt, digitale Selbstbestimmung und Datenintegrität entscheiden darüber, ob eine Gesellschaft Krisen bewältigen kann. Ohne diese Dimensionen können SDGs formal gemessen werden, während ihre politischen Voraussetzungen erodieren.

SDG+ ist keine offizielle UN-Kategorie. Es ist die transparente Erweiterung der Wirkungsökonomie für jene demokratischen und medialen Bedingungen, ohne die die SDGs nicht stabil erreichbar sind.



## Politische Anschlussfähigkeit und Umsetzungsoptionen

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Sie liefert einen Bewertungs- und Steuerungsrahmen. Parteien behalten Ausgestaltungsspielraum: Sie können Sicherheits-, Innen-, Außen-, Digital-, Sozial-, Infrastruktur- und Haushaltspolitik unterschiedlich gewichten. Entscheidend ist, ob die gewählte Politik ihre Wirkung transparent macht, Grundrechte achtet, kritische Funktionen schützt und Korrektur ermöglicht.

Aufgabe der Politik ist es, Risiken nicht zu verdrängen und zugleich keine Kontrolllogik zu erzeugen. Ein Sicherheitsstaat versucht, Risiken durch Überwachung und Zentralisierung zu minimieren. Ein Resilienzstaat schützt Handlungsfähigkeit, ohne die offene Gesellschaft zu schließen. Er setzt auf Vorsorge, klare Zuständigkeiten, robuste Infrastruktur, dezentrale Rückfallebenen, verlässliche Kommunikation, Rechtsstaatlichkeit und demokratische Kontrolle.

Politische Rahmenbedingungen sind: klare Risiko- und Zuständigkeitsarchitektur, transparente Daten, Schutz kritischer Einrichtungen, digitale und analoge Notfallfähigkeit, föderale Koordination, kommunale Umsetzung, soziale Abfederung, unabhängige Evaluation und Beteiligung der Bevölkerung. Zielkonflikte müssen offen benannt werden: Sicherheit und Freiheit, Tempo und Rechtsstaat, Zentralisierung und lokale Handlungsfähigkeit, Geheimschutz und Transparenz, Prävention und Kosten, internationale Kooperation und Souveränität.

Evaluation und Korrektur sind Pflicht. Sicherheits- und Resilienzpolitik muss prüfen, ob Maßnahmen tatsächlich Verwundbarkeit senken, Versorgung sichern, Vertrauen stärken, Freiheit schützen und Folgeschäden reduzieren. Nicht eingetretene Katastrophen sind keine Wirkungslosigkeit. Sie können Ergebnis gelungener Prävention sein.



## Quellen- und Anschlussrahmen

Interne WÖk-Anschlüsse:

- Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Kapitel 65 Resilienzstaat, Kapitel 66 Sicherheitsarchitektur, Kapitel 84 Cyberresilienz, Kapitel 95 Globale Resilienz, Sicherheit und Kooperation.
- Natalie Weber: Systemmodell der Wirkungsökonomie, 2025, Module Außenpolitik und Sicherheitspolitik, Bundeswehr und alternative Dienstpflicht, Katastrophenschutz und Systemresilienz, Demokratie-Schutzarchitektur, Digitalisierungsindikatoren.

Externe Anschlussquellen:

- United Nations Office for Disaster Risk Reduction: Sendai Framework for Disaster Risk Reduction 2015-2030.
- OECD: Good Governance for Critical Infrastructure Resilience.
- OECD: Recommendation on the Governance of Critical Risks.
- Europäische Union: Richtlinie (EU) 2022/2557 über die Resilienz kritischer Einrichtungen.
- Europäische Union: Richtlinie (EU) 2022/2555, NIS2-Richtlinie.
- Europäische Kommission: Preparedness Union Strategy, 2025.
- NATO: Resilience, civil preparedness and Article 3.
- NIST: Cybersecurity Framework 2.0, 2024.
- Bundesamt für Sicherheit in der Informationstechnik: Lage der IT-Sicherheit in Deutschland, 2025.
