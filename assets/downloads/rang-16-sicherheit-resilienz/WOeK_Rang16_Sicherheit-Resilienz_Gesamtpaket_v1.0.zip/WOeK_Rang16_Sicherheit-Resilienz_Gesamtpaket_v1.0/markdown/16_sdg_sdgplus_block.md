# SDG- und SDG+-Block Rang 16

**Untertitel:** Referenzrahmen für Sicherheit, Resilienz und globale Kooperation
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Portal:** Rang 16 - Sicherheit, Resilienz und globale Kooperation
**Version:** 1.0
**Status:** Online- und Downloadfassung v1.0
**Stand:** 24. Mai 2026

---


## SDG- und SDG+-Bezug

Rang 16 berührt mehrere SDGs direkt: SDG 3 Gesundheit und Wohlergehen, SDG 6 Wasser, SDG 7 Energie, SDG 9 Industrie, Innovation und Infrastruktur, SDG 11 nachhaltige Städte und Gemeinden, SDG 13 Klimaschutz, SDG 16 Frieden, Gerechtigkeit und starke Institutionen sowie SDG 17 Partnerschaften. Sicherheit und Resilienz sind keine Zusatzthemen, sondern Schutzbedingungen für die Erreichung dieser Ziele.

Der SDG+-Bezug ist zentral. Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlicher Zusammenhalt, digitale Selbstbestimmung und Datenintegrität entscheiden darüber, ob eine Gesellschaft Krisen bewältigen kann. Ohne diese Dimensionen können SDGs formal gemessen werden, während ihre politischen Voraussetzungen erodieren.

SDG+ ist keine offizielle UN-Kategorie. Es ist die transparente Erweiterung der Wirkungsökonomie für jene demokratischen und medialen Bedingungen, ohne die die SDGs nicht stabil erreichbar sind.


## Zuordnung nach Unterbereichen

| Unterbereich | SDGs | SDG+ |
|---|---|---|
| kritische Infrastruktur | 3, 6, 7, 9, 11, 16 | institutionelles Vertrauen, Rechtsstaat, Datenintegrität |
| Cyberresilienz | 9, 16, 17 | digitale Selbstbestimmung, algorithmische Fairness, Informationssicherheit |
| Katastrophenschutz | 3, 11, 13, 16 | gesellschaftlicher Zusammenhalt, Vertrauen, Teilgabe |
| hybride Risiken | 16, 17 | Medienqualität, Diskursfähigkeit, demokratische Stabilität |
| globale Kooperation | 2, 3, 6, 7, 13, 16, 17 | faire Datenzugänge, nicht-dominante Übersetzung, globale Korrekturfähigkeit |
| kommunale Resilienz | 3, 6, 7, 10, 11, 13, 16 | Beteiligung, lokale Demokratie, Sozialraumvertrauen |

## Bewertungsprinzip

Sicherheits- und Resilienzmaßnahmen gelten nicht automatisch als positiv. Sie erzeugen Wirkungen, Risiken und Nebenwirkungen. Positiv ist eine Maßnahme nur, wenn sie im Referenzrahmen SDGs, Agenda 2030 und SDG+ positive Netto-Wirkung erzeugt und rote Linien achtet: Menschenwürde, Rechtsstaatlichkeit, Datenschutz, Minderheitenschutz, demokratische Kontrolle und ökologische Lebensgrundlagen.
