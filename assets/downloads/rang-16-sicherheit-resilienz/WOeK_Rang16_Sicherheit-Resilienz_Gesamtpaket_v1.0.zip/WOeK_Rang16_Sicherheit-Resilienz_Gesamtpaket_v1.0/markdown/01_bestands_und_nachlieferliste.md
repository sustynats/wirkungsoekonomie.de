# Bestands- und Nachlieferliste Rang 16

**Untertitel:** Status, Lücken, Umbenennung und Produktionsplan
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Portal:** Rang 16 - Sicherheit, Resilienz und globale Kooperation
**Version:** 1.0
**Status:** Arbeits- und Websitegrundlage v1.0
**Stand:** 24. Mai 2026

---

## Bestands- und Nachlieferliste

### Ausgangslage

Die bisherige Portalrangfolge endete bei Rang 15 Migration und Vielfalt. Rang 16 wird aus der vorhandenen Buch- und Systemarchitektur abgeleitet: Sicherheitsarchitektur, Resilienzstaat, Cyberresilienz, Außenpolitik, globale Resilienz, Katastrophenschutz, kritische Infrastruktur, hybride Risiken und Dienstjahr für Wirkung. Diese Themen sind in den vorhandenen Grundlagen bereits angelegt, aber noch nicht als eigenständiges Portal mit Downloadstruktur, Onlinefassungen, Toolkarten und Langfassungen ausgearbeitet.

### Statusmatrix

| Baustein | Grundlage | Status | Nachlieferung |
|---|---|---|---|
| Portalstartseite | Kapitel 66, 95, Systemmodell | neu erstellt | Onlinefassung und Download |
| Konzeptpapier | Buchanker vorhanden | ausbauen | 18-25 Seiten Einführung |
| Gesamtdossier | mehrere Buchkapitel verteilt | neu als Langfassung | gebündeltes Dossier für Portal Rang 16 |
| Detailkonzepte | Themen angelegt | neu erstellt | 12 Langfassungsentwürfe |
| Online-Volltexte | nicht gebündelt | neu erstellt | HTML-Fassungen aller Dokumente |
| Downloads | nicht vorhanden | neu erstellt | PDF-Paket und Gesamt-ZIP |
| Toolkarten | Systemmodell enthält Ansatzpunkte | neu erstellt | 8 Toolkarten mit Status Demo in Vorbereitung |
| SDG-/SDG+-Block | vorhanden, aber nicht portalisiert | neu erstellt | eigener Block |
| Politische Anschlussfähigkeit | Pflichtblock nötig | neu erstellt | eigener Langtext |
| Quellen und Glossarlinks | verteilt | neu erstellt | Quellenrahmen und Glossaranschlüsse |

### Qualitätsentscheidung

Rang 16 darf nicht als Katastrophenangst, Sicherheitsstaat oder Verteidigungspolitik im engen Sinn erscheinen. Der Portalbereich muss den Unterschied zwischen Sicherheitsstaat und Resilienzstaat sauber herausarbeiten. Der Resilienzstaat schützt Handlungsfähigkeit, ohne offene Gesellschaft zu schließen.

### Nachlieferpriorität

1. Gesamtdossier Sicherheit, Resilienz und globale Kooperation
2. Detailkonzept Sicherheit als Wirkungsfrage
3. Detailkonzept Resilienzstaat und kritische Funktionen
4. Detailkonzept Kritische Infrastruktur als demokratische Infrastruktur
5. Detailkonzept Cyberresilienz und digitale Verwundbarkeit
6. Detailkonzept Hybride Risiken und Demokratieverteidigung
7. Detailkonzept Katastrophenschutz und Bevölkerungsvorsorge
8. Detailkonzept Außenpolitik, globale Resilienz und Kooperation



### Website-Korrekturen

- Alle PDF-Downloads erhalten vollständige Onlinefassungen.
- Keine Kurztexte werden als Detailkonzepte bezeichnet.
- Toolkarten enthalten Beschreibung, Nutzen, Status und Link.
- Tabellen werden mobil als Karten oder horizontal scrollbar dargestellt.
- Politische Anschlussfähigkeit erscheint auf jeder Wirkungsfeldseite.
- Keine internen Arbeitsanweisungen oder unfertigen Platzhalter werden öffentlich angezeigt.
