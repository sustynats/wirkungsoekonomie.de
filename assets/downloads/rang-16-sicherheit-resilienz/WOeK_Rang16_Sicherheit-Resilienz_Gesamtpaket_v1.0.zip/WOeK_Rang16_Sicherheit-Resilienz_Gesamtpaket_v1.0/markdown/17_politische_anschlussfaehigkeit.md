# Politische Anschlussfähigkeit Rang 16

**Untertitel:** Umsetzungsoptionen, Zielkonflikte und Schutz vor Technokratie
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Portal:** Rang 16 - Sicherheit, Resilienz und globale Kooperation
**Version:** 1.0
**Status:** Pflichtblock v1.0
**Stand:** 24. Mai 2026

---


## Politische Anschlussfähigkeit und Umsetzungsoptionen

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Sie liefert einen Bewertungs- und Steuerungsrahmen. Parteien behalten Ausgestaltungsspielraum: Sie können Sicherheits-, Innen-, Außen-, Digital-, Sozial-, Infrastruktur- und Haushaltspolitik unterschiedlich gewichten. Entscheidend ist, ob die gewählte Politik ihre Wirkung transparent macht, Grundrechte achtet, kritische Funktionen schützt und Korrektur ermöglicht.

Aufgabe der Politik ist es, Risiken nicht zu verdrängen und zugleich keine Kontrolllogik zu erzeugen. Ein Sicherheitsstaat versucht, Risiken durch Überwachung und Zentralisierung zu minimieren. Ein Resilienzstaat schützt Handlungsfähigkeit, ohne die offene Gesellschaft zu schließen. Er setzt auf Vorsorge, klare Zuständigkeiten, robuste Infrastruktur, dezentrale Rückfallebenen, verlässliche Kommunikation, Rechtsstaatlichkeit und demokratische Kontrolle.

Politische Rahmenbedingungen sind: klare Risiko- und Zuständigkeitsarchitektur, transparente Daten, Schutz kritischer Einrichtungen, digitale und analoge Notfallfähigkeit, föderale Koordination, kommunale Umsetzung, soziale Abfederung, unabhängige Evaluation und Beteiligung der Bevölkerung. Zielkonflikte müssen offen benannt werden: Sicherheit und Freiheit, Tempo und Rechtsstaat, Zentralisierung und lokale Handlungsfähigkeit, Geheimschutz und Transparenz, Prävention und Kosten, internationale Kooperation und Souveränität.

Evaluation und Korrektur sind Pflicht. Sicherheits- und Resilienzpolitik muss prüfen, ob Maßnahmen tatsächlich Verwundbarkeit senken, Versorgung sichern, Vertrauen stärken, Freiheit schützen und Folgeschäden reduzieren. Nicht eingetretene Katastrophen sind keine Wirkungslosigkeit. Sie können Ergebnis gelungener Prävention sein.


## Aufgabe der Politik im Detail

Politik muss für Rang 16 drei Aufgaben verbinden. Erstens: Schutz kritischer Funktionen. Zweitens: Freiheit, Grundrechte und offene Gesellschaft erhalten. Drittens: Menschen, Kommunen und Institutionen befähigen, Krisen selbstwirksam zu bewältigen. Diese Aufgaben stehen in Spannung. Die Wirkungsökonomie beseitigt diese Spannung nicht. Sie macht sie sichtbar.

## Parteipolitische Anschlussfähigkeit

Konservative Parteien können Rang 16 nutzen, um Ordnung, Schutz, Verteidigungsfähigkeit und kritische Infrastruktur wirkungsbasiert zu begründen. Sozialdemokratische Parteien können soziale Resilienz, faire Lastenverteilung und kommunale Handlungsfähigkeit betonen. Liberale Parteien können Freiheitsschutz, Rechtsstaat, Datenrechte und innovationsfähige Sicherheitsarchitektur stärken. Grüne Parteien können Klima-, Wasser-, Energie- und Biodiversitätsrisiken als Sicherheitsfragen operationalisieren. Linke Parteien können soziale Verwundbarkeit, öffentliche Daseinsvorsorge und Schutz vor Oligarchisierung fokussieren. Kommunal orientierte Parteien können lokale Resilienz, Bevölkerungsschutz und Beteiligung in den Mittelpunkt stellen.

## Schutz vor Technokratie

Wirkungsmessung darf keine Expertokratie erzeugen. Sie soll politische Folgen sichtbar machen, nicht demokratische Entscheidungen ersetzen. Alle Methoden müssen öffentlich, prüfbar, versioniert und anfechtbar sein. Wo Unsicherheit besteht, muss sie benannt werden. Wo Daten fehlen, darf nicht so getan werden, als sei Wirkung exakt bekannt. Wo Grundrechte betroffen sind, braucht es Rechtsprüfung und demokratische Kontrolle.

## Korrektur und Evaluation

Rang 16 braucht einen jährlichen Wirkungsresilienzbericht. Er sollte folgende Fragen beantworten: Welche kritischen Funktionen wurden stabiler? Welche Verwundbarkeiten bleiben? Welche Gruppen sind besonders betroffen? Welche Maßnahmen erzeugten Nebenwirkungen? Welche Daten fehlen? Welche Zuständigkeiten sind unklar? Welche Maßnahmen wurden korrigiert?
