# Toolkarten Rang 16

**Untertitel:** Beschreibung, Nutzen, Status und Linkstruktur
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Portal:** Rang 16 - Sicherheit, Resilienz und globale Kooperation
**Version:** 1.0
**Status:** Toolkarten v1.0
**Stand:** 24. Mai 2026

---
## Toolkarten

### Wirkungsresilienz-Dashboard

**Beschreibung:** Bündelt Risiko-, Infrastruktur-, Sozial-, Klima-, Cyber- und Vertrauensdaten für einen öffentlichen Überblick über Verwundbarkeit und Vorsorge.

**Nutzen:** Unterstützt Planung, Priorisierung, Kommunikation und Wirkungskontrolle.

**Status:** Demo in Vorbereitung

**Link:** /tools/wirkungsresilienz-dashboard/

### Kritische-Funktionen-Scorecard

**Beschreibung:** Bewertet nicht nur Anlagen, sondern die Ausfallwirkung auf Versorgung, Rechte, Vertrauen und demokratische Korrekturfähigkeit.

**Nutzen:** Unterstützt Planung, Priorisierung, Kommunikation und Wirkungskontrolle.

**Status:** Demo in Vorbereitung

**Link:** /tools/kritische-funktionen-scorecard/

### Kommunaler Resilienzindex

**Beschreibung:** Misst Hitze-, Wasser-, Strom-, Gesundheits-, Pflege-, Kommunikations-, Sozialraum- und Cyberresilienz auf kommunaler Ebene.

**Nutzen:** Unterstützt Planung, Priorisierung, Kommunikation und Wirkungskontrolle.

**Status:** Demo in Vorbereitung

**Link:** /tools/kommunaler-resilienzindex/

### Cyberresilienz-Check

**Beschreibung:** Prüft Wiederherstellungsfähigkeit, Datenintegrität, Backup, Incident Response, analoge Rückfallebenen und Auswirkungen auf Bürgerdienste.

**Nutzen:** Unterstützt Planung, Priorisierung, Kommunikation und Wirkungskontrolle.

**Status:** Demo in Vorbereitung

**Link:** /tools/cyberresilienz-check/

### Hybrid-Risiko-Radar

**Beschreibung:** Frühwarninstrument für koordinierte Wirkungsrisiken aus Desinformation, Cyberangriffen, wirtschaftlichem Druck und Polarisierung.

**Nutzen:** Unterstützt Planung, Priorisierung, Kommunikation und Wirkungskontrolle.

**Status:** Demo in Vorbereitung

**Link:** /tools/hybrid-risiko-radar/

### Bevölkerungsvorsorge-Planer

**Beschreibung:** Hilft Kommunen, Haushalten und Einrichtungen, 72-Stunden-Fähigkeit, Warnwege, Schutz vulnerabler Gruppen und lokale Anlaufstellen zu planen.

**Nutzen:** Unterstützt Planung, Priorisierung, Kommunikation und Wirkungskontrolle.

**Status:** Demo in Vorbereitung

**Link:** /tools/bevoelkerungsvorsorge-planer/

### Dienstjahr-für-Wirkung-Matcher

**Beschreibung:** Ordnet zivile, digitale und militärische Einsatzfelder nach Fähigkeiten, Schutzbedarf, Wirkung und Zertifikaten.

**Nutzen:** Unterstützt Planung, Priorisierung, Kommunikation und Wirkungskontrolle.

**Status:** Demo in Vorbereitung

**Link:** /tools/dienstjahr-fuer-wirkung-matcher/

### Globale-Resilienz-Matrix

**Beschreibung:** Bewertet internationale Wirkpartnerschaften nach Klima, Wasser, Ernährung, Gesundheit, Lieferketten, Datenzugang und demokratischer Korrekturfähigkeit.

**Nutzen:** Unterstützt Planung, Priorisierung, Kommunikation und Wirkungskontrolle.

**Status:** Demo in Vorbereitung

**Link:** /tools/globale-resilienz-matrix/
