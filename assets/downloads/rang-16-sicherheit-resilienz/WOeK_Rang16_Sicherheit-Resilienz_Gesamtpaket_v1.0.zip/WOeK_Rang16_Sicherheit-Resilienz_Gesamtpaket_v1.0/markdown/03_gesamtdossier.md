# Gesamtdossier Rang 16

**Untertitel:** Sicherheit, Resilienz und globale Kooperation
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Portal:** Rang 16 - Sicherheit, Resilienz und globale Kooperation
**Version:** 1.0
**Status:** Gesamtdossier - Langfassungsentwurf v1.0
**Stand:** 24. Mai 2026

---

## Executive Summary

Dieses Gesamtdossier bündelt Rang 16 der Wirkungsökonomie: Sicherheit, Resilienz und globale Kooperation. Es führt die bislang verstreuten Buchanker zu Sicherheitsarchitektur, Resilienzstaat, Cyberresilienz, Katastrophenschutz, Außenpolitik und globaler Resilienz in einen portal- und websitefähigen Fachbereich über.


## Begriffliche Leitlinie

Für Rang 16 gilt der führende Begriffsleitfaden der Wirkungsökonomie. Wirkung ist neutral und relational. Sie beschreibt die tatsächliche Veränderung von Zuständen und kann positiv, negativ oder neutral sein. Bewertet wird Wirkung am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie.

Sicherheit wird deshalb nicht als bloße Abwehr, Kontrolle oder militärische Stärke verstanden. Sicherheit ist ein Wirkungszustand: Menschen bleiben geschützt, lebenswichtige Funktionen bleiben verfügbar, demokratische Korrekturfähigkeit bleibt erhalten, Infrastruktur bleibt belastbar, Information bleibt vertrauenswürdig und politische Entscheidungen bleiben rechtsstaatlich begrenzt.

Resilienz bedeutet nicht Abschottung. Resilienz bedeutet Lern-, Anpassungs- und Kooperationsfähigkeit unter Stress. Eine resiliente Gesellschaft kann Störungen aufnehmen, Grundfunktionen aufrechterhalten, Schaden begrenzen, aus Krisen lernen und ihre Freiheit bewahren.


## Leitbild

Sicherheit ist die Fähigkeit einer Gesellschaft, ihre menschlichen, ökologischen und demokratischen Lebensbedingungen auch unter Stress zu schützen. Resilienz ist die Fähigkeit, Störungen aufzunehmen, Grundfunktionen zu erhalten, Verwundbarkeit zu senken, aus Krisen zu lernen und Freiheit zu bewahren.

## Systembild

Rang 16 umfasst nicht ein einzelnes Ressort. Er verknüpft Staat, Kommunen, kritische Infrastruktur, Wirtschaft, Finanzsystem, Medien, Wissenschaft, Gesundheit, digitale Infrastruktur, Energie, Wasser, Ernährung, internationale Kooperation und Gesellschaft. Das macht den Bereich sensibel: Wird er zu eng gefasst, bleiben zentrale Risiken unsichtbar. Wird er zu breit und kontrollorientiert gefasst, droht Sicherheitsstaatlichkeit. Die Wirkungsökonomie setzt deshalb auf einen Resilienzstaat mit rechtsstaatlicher Begrenzung.


## Kapitel 1: Sicherheit als Wirkungsfrage

### Kurzthese

Sicherheit wird als Wirkungszustand definiert: Menschen, Institutionen, Infrastruktur und demokratische Korrekturfähigkeit bleiben auch unter Stress tragfähig.

### Problem

Klassische Sicherheitslogik verengt Sicherheit häufig auf Gefahrenabwehr, Polizei, Militär oder Grenzschutz. Diese Bereiche bleiben wichtig, aber sie erfassen nur einen Teil moderner Verwundbarkeit. Eine Gesellschaft kann formal sicher wirken und dennoch unsicher werden, wenn Energieversorgung, Wasser, Gesundheit, Verwaltung, Medienvertrauen, digitale Netze, Lieferketten oder institutionelles Vertrauen brechen.

### Wirkungslogik

Die Wirkungsökonomie fragt nicht zuerst, welche Bedrohung formal vorliegt, sondern welche Zustände verändert werden. Ein Angriff auf ein Krankenhaus verändert andere Zustände als ein Angriff auf einen Unterhaltungsdienst. Eine Störung der Wahlkommunikation wirkt anders als der Ausfall privater Werbung. Maßgeblich ist die Wirkung auf Freiheit, Versorgung, Vertrauen, Würde und demokratische Korrekturfähigkeit.

### zentrale Bausteine

- Sicherheit als Schutz der Wirkungsbedingungen
- Gefahrenbewertung nach MPD-Wirkung
- Freiheit und Sicherheit als gegenseitige Bedingung
- Rechtsstaat und Verhältnismäßigkeit
- Vertrauen als Sicherheitsfaktor
- Prävention als Wirkleistung
- Grenze zum Sicherheitsstaat



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 2: Resilienzstaat und kritische Funktionen

### Kurzthese

Der Resilienzstaat schützt kritische Funktionen, bevor Störungen eskalieren. Er bewertet nicht nur Schadensereignisse, sondern Verwundbarkeit, Folgewirkung und Wiederherstellungsfähigkeit.

### Problem

Viele Staaten reagieren auf Krisen erst, wenn Schäden sichtbar sind. Dann sind Handlungsspielräume enger, Kosten höher und Eingriffe härter. Der Resilienzstaat kehrt diese Logik um: Er investiert in Vorsorge, Redundanz, Rückfallebenen, klare Zuständigkeiten und Lernfähigkeit.

### Wirkungslogik

Kritische Funktionen sind jene Leistungen, ohne die Mensch, Planet und Demokratie unter Stress nicht tragfähig bleiben: Wasser, Energie, Ernährung, Gesundheit, Pflege, Kommunikation, digitale Grunddienste, Verwaltung, Recht, öffentliche Information, Zahlungssysteme, Verkehr und Sicherheit.

### zentrale Bausteine

- Kritische Funktionen statt Einzelanlagen
- Risikoanalyse nach Ausfallwirkung
- Redundanz und analoge Rückfallebenen
- kommunale Vorsorge
- Resilienzhaushalt
- jährliche Wirkungsberichte
- Lernen aus Beinahe-Ereignissen



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 3: Kritische Infrastruktur als demokratische Infrastruktur

### Kurzthese

Kritische Infrastruktur ist nicht nur technisch oder wirtschaftlich relevant. Sie ist eine Bedingung demokratischer Stabilität.

### Problem

Infrastruktur wird oft nach Betriebskosten, Ausfallwahrscheinlichkeit oder Eigentumsfragen bewertet. Wirkungsökonomisch reicht das nicht. Ein Ausfall kann Grundrechte, Wahlfähigkeit, Vertrauen, öffentliche Sicherheit, Gesundheit und soziale Stabilität berühren.

### Wirkungslogik

Eine demokratische Gesellschaft braucht funktionierende Grunddienste. Wenn Verwaltung nicht erreichbar ist, Sozialleistungen ausfallen, Krankenhäuser nicht arbeiten, Wasser oder Energie fehlen oder vertrauenswürdige Kommunikation bricht, verliert Demokratie praktische Wirksamkeit.

### zentrale Bausteine

- MPD-Ausfallbewertung
- Betroffenengruppen und Vulnerabilität
- Ersatzwege und Wiederherstellung
- Datenabhängigkeiten
- Betreiberpflichten
- öffentliche Kontrolle
- Infrastruktur als Teil des Wirkungshaushalts



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 4: Cyberresilienz und digitale Verwundbarkeit

### Kurzthese

Cyberresilienz schützt nicht nur Systeme, sondern Verwaltung, Gesundheit, Märkte, Vertrauen, öffentliche Wahrheit und demokratische Handlungsfähigkeit.

### Problem

Digitale Verwundbarkeit entsteht nicht erst durch einen erfolgreichen Angriff. Sie entsteht durch Abhängigkeit ohne Ausweichfähigkeit, unklare Zuständigkeiten, veraltete Systeme, schwache Datenintegrität und fehlende analoge Rückfallebenen.

### Wirkungslogik

Ein Cyberangriff auf eine Kommune wirkt auf Bürgervertrauen, Verwaltungsgeschwindigkeit, Sozialleistungen, Gesundheitsversorgung, Medienkommunikation, politische Schuldzuweisung und Sicherheitsempfinden. Die Wirkungsökonomie bewertet Cyberrisiken deshalb nach Zustandsveränderung, nicht nur nach technischem Schweregrad.

### zentrale Bausteine

- Governance nach NIST CSF 2.0 und NIS2-Anschluss
- Datenintegrität
- Backup und Wiederherstellung
- kommunale Cyberresilienz
- Schutz von Krankenhäusern und Versorgung
- Wirkungsdatenräume
- digitale Rückfallebenen



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 5: Hybride Risiken und Demokratieverteidigung

### Kurzthese

Hybride Risiken greifen nicht nur Systeme an. Sie greifen Wirkungsbedingungen an: Wahrheit, Vertrauen, Infrastruktur, soziale Kohäsion und demokratische Korrekturfähigkeit.

### Problem

Hybride Bedrohungen verbinden Desinformation, Cyberangriffe, wirtschaftlichen Druck, verdeckte politische Einflussnahme, Sabotage, Spionage, Plattformmanipulation, Drohnenvorfälle, Migrationsinstrumentalisierung oder militärische Drohung. Klassische Ressortgrenzen erkennen diese Kopplung oft zu spät.

### Wirkungslogik

Die Wirkungsökonomie behandelt hybride Risiken als politische Wirkungsrisiken. Sie fragt: Welche Wirkungsräume werden destabilisiert? Welche Gruppen werden gegeneinander mobilisiert? Welche Informationswege verlieren Vertrauen? Welche Infrastruktur wird verletzlich? Welche demokratische Korrektur wird blockiert?

### zentrale Bausteine

- Civic Shield
- Diskursresilienz
- Transparenz politischer Einflussnahme
- Schutz von Wahlkommunikation
- Medien- und Plattformverantwortung
- Anti-Oligarchen-Framework
- Frühwarnung ohne Zensur



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 6: Katastrophenschutz und Bevölkerungsvorsorge

### Kurzthese

Katastrophenschutz wird wirkungsökonomisch als Fähigkeit verstanden, Menschen unter Belastung zu schützen, zu informieren, zu versorgen und einzubinden.

### Problem

Katastrophenschutz ist häufig ereignisorientiert. Es gibt Pläne für Hochwasser, Brand, Pandemie oder Ausfall. Wirkungsökonomisch muss zusätzlich gefragt werden, welche Grundfunktionen betroffen sind und welche Menschen zuerst Unterstützung brauchen.

### Wirkungslogik

Bevölkerungsvorsorge verbindet staatliche Vorbereitung, kommunale Infrastruktur, Haushaltsvorsorge, soziale Netze, barrierefreie Kommunikation, mehrsprachige Warnung, medizinische Versorgung, Pflege, Rettung, Feuerwehr, Zivilschutz und digitale Rückfallebenen.

### zentrale Bausteine

- Sendai-Anschluss
- 72-Stunden-Fähigkeit als Untergrenze
- mehrsprachige Warnwege
- Nachbarschaftsnetze
- Schutz vulnerabler Gruppen
- lokale Anlaufstellen
- Build Back Better nach Wirkung



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 7: Energie-, Wasser-, Ernährungs- und Gesundheitsresilienz

### Kurzthese

Klima, Wasser, Energie, Ernährung und Gesundheit sind keine getrennten Politikfelder. Sie bilden gekoppelte Wirkungsräume.

### Problem

Eine Dürre kann Ernten zerstören, Preise erhöhen, Konflikte verschärfen, Migration auslösen, Staatshaushalte belasten und politische Instabilität verstärken. Ein Energieausfall kann Gesundheit, Pflege, Wasser, Kommunikation und Verwaltung treffen.

### Wirkungslogik

Rang 16 macht Lebenssysteme zu Sicherheits- und Resilienzthemen, ohne sie militärisch zu verengen. Ziel ist die Fähigkeit, Grundversorgung unter Stress aufrechtzuerhalten und Verwundbarkeit systematisch zu senken.

### zentrale Bausteine

- Wasserstress und Versorgung
- dezentrale Energie und Speicher
- Ernährungsreserven und regionale Ketten
- Gesundheit und Pflege als kritische Funktion
- Hitzeschutz
- Pandemievorsorge
- Klimaanpassung als Sicherheitspolitik



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 8: Lieferketten-, Rohstoff- und Finanzresilienz

### Kurzthese

Rohstoffkonzentration, Energieabhängigkeit, Lieferketten, Versicherbarkeit, Datenmacht und Kapitalflüsse sind Stabilitätsgrößen.

### Problem

Makroökonomie bewertet Wachstum, Inflation, Beschäftigung, Schulden und Kapitalströme. Doch moderne Krisen zeigen: Wirkungsrisiken sind makroökonomisch. Wasserstress, Rohstoffmacht, Versicherbarkeit, Desinformation oder kritische Lieferketten können ganze Geschäftsmodelle und Staatshaushalte destabilisieren.

### Wirkungslogik

Wirkungsökonomische Resilienz lenkt Kapital in Prävention, transparente Lieferketten, strategische Autonomie, faire Rohstoffpartnerschaften, Versicherbarkeit und Transformationsfähigkeit.

### zentrale Bausteine

- Rohstofflandkarten
- Lieferketten-Diplomatie
- Versicherbarkeit als Wirklichkeitstest
- Kapitalzugang nach Resilienz
- Strategische Autonomie ohne Abschottung
- Datenmacht
- Wirkungsfonds für Resilienz



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 9: Kommunale Resilienz und Sozialräume

### Kurzthese

Kommunen sind der Ort, an dem Krisen Menschen konkret treffen und an dem Resilienz praktisch wird.

### Problem

Viele Krisen werden national diskutiert, aber lokal bewältigt: Hitze, Starkregen, Pflegeausfall, Stromausfall, Schulschließung, Cyberangriff, Unterbringung, Verkehrsunterbrechung, Desinformation oder soziale Spannung. Ohne kommunale Handlungsfähigkeit bleibt Resilienz abstrakt.

### Wirkungslogik

Kommunale Resilienz verbindet Sozialraumprofil, Infrastruktur, Nachbarschaft, Warnsysteme, Gesundheit, Pflege, Energie, Wasser, Mobilität, Bildung, Kultur, digitale Netze und Beteiligung.

### zentrale Bausteine

- kommunales Resilienzprofil
- Hitze- und Wasserresilienz
- dezentrale Energie
- Nachbarschaft und Begegnungsräume
- barrierefreie und mehrsprachige Kommunikation
- kommunale Wirkungsbudgets
- Beteiligung und Krisenlernen



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 10: Dienstjahr für Wirkung

### Kurzthese

Das Dienstjahr für Wirkung verbindet gesellschaftliche Teilgabe, Krisenfähigkeit und demokratische Identifikation.

### Problem

Klassische Wehrpflichtdebatten verengen gesellschaftliche Resilienz häufig auf militärische Personalfragen. Gleichzeitig fehlen Menschen in Pflege, Katastrophenschutz, Kommunen, Cybersecurity, Dateninfrastruktur und sozialer Stabilisierung.

### Wirkungslogik

Das Dienstjahr für Wirkung ist kein Zwang zur Uniform. Es ist ein strukturierter Beitrag zur Resilienz: zivil, digital oder militärisch. Es stärkt Demokratie, soziale Kohäsion, Krisenfähigkeit und technologische Verteidigung.

### zentrale Bausteine

- zivile Wirkung
- digitale Wirkung
- militärische Wirkung
- Ausbildung und Zertifikate
- Schutz vor Ausbeutung
- soziale Abfederung
- Wirkungsnachweis und Anerkennung



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 11: Außenpolitik, globale Resilienz und Kooperation

### Kurzthese

Außenpolitik der Wirkungsökonomie ist stabilitätsgetrieben: EU, demokratische Allianzen, globale Wirkpartnerschaften, Klimapolitik, Lieferketten-Diplomatie und Cyber-Schutz wirken zusammen.

### Problem

Außenpolitik wird häufig als Interessenpolitik verstanden. Wirkungsökonomisch greift das zu kurz, weil globale Sicherheit von Klima, Wasser, Ernährung, Gesundheit, Energie, Lieferketten, Daten, Frieden und demokratischer Korrekturfähigkeit abhängt.

### Wirkungslogik

Globale Resilienz entsteht nicht durch Abschottung, sondern durch gemeinsame Vorsorge, Frühwarnung, Kooperation, faire Datenzugänge, lokale Übersetzung und Schutz kritischer Funktionen über Grenzen hinweg.

### zentrale Bausteine

- EU als Wirkungsraum
- NATO und zivile Vorbereitung
- globale Wirkpartnerschaften
- Klimapolitik als Außenpolitik
- Lieferketten-Diplomatie
- Daten- und Frühwarnkooperation
- weltfähige Ordnung ohne Dominanzanspruch



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.

## Kapitel 12: Wirkungsindikatoren für Sicherheit und Resilienz

### Kurzthese

Rang 16 braucht Indikatoren, die Verwundbarkeit, Ausfallwirkung, Wiederherstellungsfähigkeit, Vertrauen, Freiheitsschutz und Lernfähigkeit messen.

### Problem

Viele Sicherheitskennzahlen messen Ereignisse: Angriffe, Ausfälle, Schäden oder Reaktionszeiten. Das reicht nicht. Die Wirkungsökonomie misst auch Verwundbarkeit, Präventionsleistung, Redundanz, Datenqualität, soziale Betroffenheit und demokratische Folgewirkung.

### Wirkungslogik

Indikatoren dürfen nicht zur Personenbewertung werden. Sie bewerten Strukturen, Systeme, Programme, Betreiber, Infrastrukturen, Behörden, Verfahren und Wirkungsräume.

### zentrale Bausteine

- Resilienz-WÖk-IDs
- Kritikalitäts- und Ausfallwirkungsindex
- Cyberresilienz-Score
- Kommunaler Resilienzindex
- Diskurs- und Vertrauensindikatoren
- Datenintegritätsindex
- Wirkungsresilienz-Dashboard



### MPD-Bewertung

Die Bewertung erfolgt nicht nach symbolischer Sicherheitsrhetorik, sondern nach Wirkung auf Mensch, Planet und Demokratie. Mensch meint Schutz, Versorgung, Gesundheit, Würde, Teilhabe und Sicherheit im Alltag. Planet meint ökologische Stabilität, Klima-, Wasser-, Energie- und Ressourcenbedingungen. Demokratie meint Rechtsstaat, Medienqualität, Vertrauen, transparente Institutionen, digitale Selbstbestimmung und Korrekturfähigkeit.

### Umsetzung

Für dieses Modul werden Onlinefassung, PDF-Download, Toolkarte, Datenquellen, Indikatoren, politische Anschlussfähigkeit und Querverlinkungen bereitgestellt. Die Umsetzung beginnt mit Pilotkommunen, kritischen Funktionen, ausgewählten Betreibergruppen und einem transparenten Wirkungsdashboard. Zusätzlich braucht jedes Modul eine Verantwortungsmatrix: Wer entscheidet, wer betreibt, wer prüft, wer finanziert, wer wird beteiligt und wer kann widersprechen? Erst dadurch wird Resilienz demokratisch und nicht nur technisch.

### Beispielhafte Anwendung

Die praktische Anwendung beginnt mit einem Szenario. Was passiert bei Ausfall, Manipulation, Engpass, Extremwetter, Cyberangriff, Desinformation oder Lieferkettenbruch? Danach wird geprüft, welche Gruppen betroffen sind, welche Ersatzwege existieren, welche öffentlichen Informationen vertrauenswürdig bleiben und welche Entscheidungen unter Zeitdruck getroffen werden müssen. Die Ergebnisse fließen in Scorecards, Übungen, Budgets und Korrekturmaßnahmen ein.



## SDG- und SDG+-Bezug

Rang 16 berührt mehrere SDGs direkt: SDG 3 Gesundheit und Wohlergehen, SDG 6 Wasser, SDG 7 Energie, SDG 9 Industrie, Innovation und Infrastruktur, SDG 11 nachhaltige Städte und Gemeinden, SDG 13 Klimaschutz, SDG 16 Frieden, Gerechtigkeit und starke Institutionen sowie SDG 17 Partnerschaften. Sicherheit und Resilienz sind keine Zusatzthemen, sondern Schutzbedingungen für die Erreichung dieser Ziele.

Der SDG+-Bezug ist zentral. Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlicher Zusammenhalt, digitale Selbstbestimmung und Datenintegrität entscheiden darüber, ob eine Gesellschaft Krisen bewältigen kann. Ohne diese Dimensionen können SDGs formal gemessen werden, während ihre politischen Voraussetzungen erodieren.

SDG+ ist keine offizielle UN-Kategorie. Es ist die transparente Erweiterung der Wirkungsökonomie für jene demokratischen und medialen Bedingungen, ohne die die SDGs nicht stabil erreichbar sind.



## Politische Anschlussfähigkeit und Umsetzungsoptionen

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Sie liefert einen Bewertungs- und Steuerungsrahmen. Parteien behalten Ausgestaltungsspielraum: Sie können Sicherheits-, Innen-, Außen-, Digital-, Sozial-, Infrastruktur- und Haushaltspolitik unterschiedlich gewichten. Entscheidend ist, ob die gewählte Politik ihre Wirkung transparent macht, Grundrechte achtet, kritische Funktionen schützt und Korrektur ermöglicht.

Aufgabe der Politik ist es, Risiken nicht zu verdrängen und zugleich keine Kontrolllogik zu erzeugen. Ein Sicherheitsstaat versucht, Risiken durch Überwachung und Zentralisierung zu minimieren. Ein Resilienzstaat schützt Handlungsfähigkeit, ohne die offene Gesellschaft zu schließen. Er setzt auf Vorsorge, klare Zuständigkeiten, robuste Infrastruktur, dezentrale Rückfallebenen, verlässliche Kommunikation, Rechtsstaatlichkeit und demokratische Kontrolle.

Politische Rahmenbedingungen sind: klare Risiko- und Zuständigkeitsarchitektur, transparente Daten, Schutz kritischer Einrichtungen, digitale und analoge Notfallfähigkeit, föderale Koordination, kommunale Umsetzung, soziale Abfederung, unabhängige Evaluation und Beteiligung der Bevölkerung. Zielkonflikte müssen offen benannt werden: Sicherheit und Freiheit, Tempo und Rechtsstaat, Zentralisierung und lokale Handlungsfähigkeit, Geheimschutz und Transparenz, Prävention und Kosten, internationale Kooperation und Souveränität.

Evaluation und Korrektur sind Pflicht. Sicherheits- und Resilienzpolitik muss prüfen, ob Maßnahmen tatsächlich Verwundbarkeit senken, Versorgung sichern, Vertrauen stärken, Freiheit schützen und Folgeschäden reduzieren. Nicht eingetretene Katastrophen sind keine Wirkungslosigkeit. Sie können Ergebnis gelungener Prävention sein.


## Umsetzungspfad

1. Portal veröffentlichen und Downloads bereitstellen.
2. Pilotkommunen und kritische Funktionen auswählen.
3. Resilienz-WÖk-IDs und Scorecards schrittweise testen.
4. Wirkungsresilienz-Dashboard als öffentliche Onlinefassung aufbauen.
5. Toolkarten als Demo in Vorbereitung kennzeichnen und später mit Daten anbinden.
6. Jährliche Evaluation durch Wirkungsrat, Kommunen, Wissenschaft und Öffentlichkeit.
7. Schutz vor Technokratie durch Datenschutz, Betroffenenbeteiligung, Rechtsmittel und öffentliche Methoden sichern.




## Quellen- und Anschlussrahmen

Interne WÖk-Anschlüsse:

- Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Kapitel 65 Resilienzstaat, Kapitel 66 Sicherheitsarchitektur, Kapitel 84 Cyberresilienz, Kapitel 95 Globale Resilienz, Sicherheit und Kooperation.
- Natalie Weber: Systemmodell der Wirkungsökonomie, 2025, Module Außenpolitik und Sicherheitspolitik, Bundeswehr und alternative Dienstpflicht, Katastrophenschutz und Systemresilienz, Demokratie-Schutzarchitektur, Digitalisierungsindikatoren.

Externe Anschlussquellen:

- United Nations Office for Disaster Risk Reduction: Sendai Framework for Disaster Risk Reduction 2015-2030.
- OECD: Good Governance for Critical Infrastructure Resilience.
- OECD: Recommendation on the Governance of Critical Risks.
- Europäische Union: Richtlinie (EU) 2022/2557 über die Resilienz kritischer Einrichtungen.
- Europäische Union: Richtlinie (EU) 2022/2555, NIS2-Richtlinie.
- Europäische Kommission: Preparedness Union Strategy, 2025.
- NATO: Resilience, civil preparedness and Article 3.
- NIST: Cybersecurity Framework 2.0, 2024.
- Bundesamt für Sicherheit in der Informationstechnik: Lage der IT-Sicherheit in Deutschland, 2025.
