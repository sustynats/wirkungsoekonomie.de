# Quellen und Glossarlinks Rang 16

**Untertitel:** Interne und externe Anschlussquellen für Website, Dossiers und Akademie
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Portal:** Rang 16 - Sicherheit, Resilienz und globale Kooperation
**Version:** 1.0
**Status:** Quellenfassung v1.0
**Stand:** 24. Mai 2026

---


## Quellen- und Anschlussrahmen

Interne WÖk-Anschlüsse:

- Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.
- Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Kapitel 65 Resilienzstaat, Kapitel 66 Sicherheitsarchitektur, Kapitel 84 Cyberresilienz, Kapitel 95 Globale Resilienz, Sicherheit und Kooperation.
- Natalie Weber: Systemmodell der Wirkungsökonomie, 2025, Module Außenpolitik und Sicherheitspolitik, Bundeswehr und alternative Dienstpflicht, Katastrophenschutz und Systemresilienz, Demokratie-Schutzarchitektur, Digitalisierungsindikatoren.

Externe Anschlussquellen:

- United Nations Office for Disaster Risk Reduction: Sendai Framework for Disaster Risk Reduction 2015-2030.
- OECD: Good Governance for Critical Infrastructure Resilience.
- OECD: Recommendation on the Governance of Critical Risks.
- Europäische Union: Richtlinie (EU) 2022/2557 über die Resilienz kritischer Einrichtungen.
- Europäische Union: Richtlinie (EU) 2022/2555, NIS2-Richtlinie.
- Europäische Kommission: Preparedness Union Strategy, 2025.
- NATO: Resilience, civil preparedness and Article 3.
- NIST: Cybersecurity Framework 2.0, 2024.
- Bundesamt für Sicherheit in der Informationstechnik: Lage der IT-Sicherheit in Deutschland, 2025.


## Glossarlinks für die Website

- Wirkung
- Wirkungspotenzial
- Wirkungsrisiko
- Netto-Wirkung
- positive Netto-Wirkung
- Wirkungsraum
- Resonanzraum
- Wirkungsbewertung
- Wirkungslenkung
- Wirkungsrückkopplung
- Wirkungsarchitektur
- Wirkungsrat
- SDG+
- Reverse Merit Order
- Nichtkompensationsprinzip
- Wirkungsgrenze
- Resilienzstaat
- Sicherheitsstaat
- kritische Funktion
- kritische Infrastruktur
- Cyberresilienz
- Datenintegrität
- hybrides Risiko
- Wirkungsresilienz-Dashboard



## Hinweise zur Zitierweise

Öffentliche Website-Texte sollten Quellen knapp, aber nachvollziehbar nennen. Fachdownloads dürfen detaillierter zitieren. Keine Rohdaten oder personenbezogenen Daten dürfen ohne Schutzkonzept veröffentlicht werden. Indikatoren müssen versioniert werden, damit Änderungen am Bewertungsrahmen transparent bleiben.
