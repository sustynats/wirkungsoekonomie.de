# Rang 16 - Sicherheit, Resilienz und globale Kooperation

**Untertitel:** Portalstartseite, Onlinefassung und Navigationslogik
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Portal:** Rang 16 - Sicherheit, Resilienz und globale Kooperation
**Version:** 1.0
**Status:** Onlinefassung - Portalblock v1.0
**Stand:** 24. Mai 2026

---

## Portalstartseite

### Sicherheit als Wirkungszustand

Rang 16 behandelt Sicherheit, Resilienz und globale Kooperation als eigenes Wirkungsfeld der Wirkungsökonomie. Der Portalbereich schließt an die bisherigen Felder an, weil Klima, Energie, Ressourcen, Finanzen, Digitalisierung, Medien, Migration, Gesundheit, Wohnen und Demokratie unter Krisenbedingungen zusammenwirken. Sicherheit ist hier nicht nur Polizei, Militär oder Grenze. Sicherheit ist die Fähigkeit, Mensch, Planet und Demokratie unter Stress tragfähig zu halten.


## Begriffliche Leitlinie

Für Rang 16 gilt der führende Begriffsleitfaden der Wirkungsökonomie. Wirkung ist neutral und relational. Sie beschreibt die tatsächliche Veränderung von Zuständen und kann positiv, negativ oder neutral sein. Bewertet wird Wirkung am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie.

Sicherheit wird deshalb nicht als bloße Abwehr, Kontrolle oder militärische Stärke verstanden. Sicherheit ist ein Wirkungszustand: Menschen bleiben geschützt, lebenswichtige Funktionen bleiben verfügbar, demokratische Korrekturfähigkeit bleibt erhalten, Infrastruktur bleibt belastbar, Information bleibt vertrauenswürdig und politische Entscheidungen bleiben rechtsstaatlich begrenzt.

Resilienz bedeutet nicht Abschottung. Resilienz bedeutet Lern-, Anpassungs- und Kooperationsfähigkeit unter Stress. Eine resiliente Gesellschaft kann Störungen aufnehmen, Grundfunktionen aufrechterhalten, Schaden begrenzen, aus Krisen lernen und ihre Freiheit bewahren.


### Leitfrage des Portals

Welche Verwundbarkeiten erzeugt eine Gesellschaft - und wie können sie gesenkt werden, ohne Freiheit, Rechtsstaat und offene Öffentlichkeit zu verlieren?

### Portalmodule

- Sicherheit als Wirkungsfrage
- Resilienzstaat und kritische Funktionen
- Kritische Infrastruktur als demokratische Infrastruktur
- Cyberresilienz und digitale Verwundbarkeit
- Hybride Risiken und Demokratieverteidigung
- Katastrophenschutz und Bevölkerungsvorsorge
- Energie-, Wasser-, Ernährungs- und Gesundheitsresilienz
- Lieferketten-, Rohstoff- und Finanzresilienz
- Kommunale Resilienz und Sozialräume
- Dienstjahr für Wirkung
- Außenpolitik, globale Resilienz und Kooperation
- Wirkungsindikatoren für Sicherheit und Resilienz



### Öffentliche Kurzlogik

Eine Gesellschaft ist nicht resilient, weil sie alle Risiken ausschließt. Das wäre unmöglich und autoritär. Sie ist resilient, wenn sie Risiken versteht, kritische Funktionen schützt, Störungen auffängt, Grundrechte wahrt, aus Fehlern lernt und ihre demokratische Korrekturfähigkeit bewahrt.

### Was dieses Portal ausdrücklich nicht ist

Dieses Portal ist keine militärische Strategie, keine Polizeireform, keine Geheimdienstarchitektur und kein Angstportal. Es ist ein wirkungsökonomischer Ordnungsrahmen für Sicherheits- und Resilienzpolitik. Es macht sichtbar, welche Zustände geschützt werden müssen und welche Nebenwirkungen Sicherheitsmaßnahmen selbst erzeugen können.


## SDG- und SDG+-Bezug

Rang 16 berührt mehrere SDGs direkt: SDG 3 Gesundheit und Wohlergehen, SDG 6 Wasser, SDG 7 Energie, SDG 9 Industrie, Innovation und Infrastruktur, SDG 11 nachhaltige Städte und Gemeinden, SDG 13 Klimaschutz, SDG 16 Frieden, Gerechtigkeit und starke Institutionen sowie SDG 17 Partnerschaften. Sicherheit und Resilienz sind keine Zusatzthemen, sondern Schutzbedingungen für die Erreichung dieser Ziele.

Der SDG+-Bezug ist zentral. Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlicher Zusammenhalt, digitale Selbstbestimmung und Datenintegrität entscheiden darüber, ob eine Gesellschaft Krisen bewältigen kann. Ohne diese Dimensionen können SDGs formal gemessen werden, während ihre politischen Voraussetzungen erodieren.

SDG+ ist keine offizielle UN-Kategorie. Es ist die transparente Erweiterung der Wirkungsökonomie für jene demokratischen und medialen Bedingungen, ohne die die SDGs nicht stabil erreichbar sind.



## Politische Anschlussfähigkeit und Umsetzungsoptionen

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Sie liefert einen Bewertungs- und Steuerungsrahmen. Parteien behalten Ausgestaltungsspielraum: Sie können Sicherheits-, Innen-, Außen-, Digital-, Sozial-, Infrastruktur- und Haushaltspolitik unterschiedlich gewichten. Entscheidend ist, ob die gewählte Politik ihre Wirkung transparent macht, Grundrechte achtet, kritische Funktionen schützt und Korrektur ermöglicht.

Aufgabe der Politik ist es, Risiken nicht zu verdrängen und zugleich keine Kontrolllogik zu erzeugen. Ein Sicherheitsstaat versucht, Risiken durch Überwachung und Zentralisierung zu minimieren. Ein Resilienzstaat schützt Handlungsfähigkeit, ohne die offene Gesellschaft zu schließen. Er setzt auf Vorsorge, klare Zuständigkeiten, robuste Infrastruktur, dezentrale Rückfallebenen, verlässliche Kommunikation, Rechtsstaatlichkeit und demokratische Kontrolle.

Politische Rahmenbedingungen sind: klare Risiko- und Zuständigkeitsarchitektur, transparente Daten, Schutz kritischer Einrichtungen, digitale und analoge Notfallfähigkeit, föderale Koordination, kommunale Umsetzung, soziale Abfederung, unabhängige Evaluation und Beteiligung der Bevölkerung. Zielkonflikte müssen offen benannt werden: Sicherheit und Freiheit, Tempo und Rechtsstaat, Zentralisierung und lokale Handlungsfähigkeit, Geheimschutz und Transparenz, Prävention und Kosten, internationale Kooperation und Souveränität.

Evaluation und Korrektur sind Pflicht. Sicherheits- und Resilienzpolitik muss prüfen, ob Maßnahmen tatsächlich Verwundbarkeit senken, Versorgung sichern, Vertrauen stärken, Freiheit schützen und Folgeschäden reduzieren. Nicht eingetretene Katastrophen sind keine Wirkungslosigkeit. Sie können Ergebnis gelungener Prävention sein.
