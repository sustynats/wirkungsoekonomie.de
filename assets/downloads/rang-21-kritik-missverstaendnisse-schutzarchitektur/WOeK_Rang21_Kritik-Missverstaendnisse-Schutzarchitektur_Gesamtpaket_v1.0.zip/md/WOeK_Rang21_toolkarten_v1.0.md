# Toolkarten Rang 21

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: Toolkarten

## Toolkartenuebersicht

Rang 21 stellt Toolkarten bereit, die Kritik, Schutz, Missbrauchsrisiken und demokratische Begrenzung operationalisieren. Alle Tools sind im Status Demo in Vorbereitung.

## Kritik-Kompass

Beschreibung: Ordnet Einwaende nach berechtigter Kritik, Missverstaendnis, Zielkonflikt, Projektion und Angriffsnarrativ.

Nutzen: Hilft Redaktion, Politik und Akademie, Kritik systematisch zu verarbeiten.

Status: Demo in Vorbereitung

Link: /tools/kritik-kompass/

## Technokratie-Risiko-Check

Beschreibung: Prueft Zentralisierung, Intransparenz, Expertokratie und Datenlastigkeit.

Nutzen: Schuetzt demokratische Entscheidung und Verhaeltnismaessigkeit.

Status: Demo in Vorbereitung

Link: /tools/technokratie-risiko-check/

## Social-Credit-Red-Line-Pruefer

Beschreibung: Prueft rote Linien gegen Personenbewertung, Gehorsamsmessung und Zugangssperren.

Nutzen: Macht Missbrauchsschutz praktisch auditierbar.

Status: Demo in Vorbereitung

Link: /tools/social-credit-red-line-pruefer/

## Wirkungssimulation-Scanner

Beschreibung: Erkennt Greenwashing, SDG-Washing, Impact-Washing und KPI-Gaming.

Nutzen: Schuetzt die Glaubwuerdigkeit der Wirkungsarchitektur.

Status: Demo in Vorbereitung

Link: /tools/wirkungssimulation-scanner/

## Planwirtschafts-Abgrenzungs-Matrix

Beschreibung: Unterscheidet Wirkungsrueckkopplung von zentraler Produktions- und Mengenplanung.

Nutzen: Erklaert Marktanschluss und Freiheitsschutz.

Status: Demo in Vorbereitung

Link: /tools/planwirtschafts-abgrenzungs-matrix/

## Fehlbarkeits- und Evaluationsradar

Beschreibung: Markiert Unsicherheiten, Messgrenzen, Zielkonflikte, Revisionsbedarf und Evaluationszyklen.

Nutzen: Verhindert Scheingenauigkeit.

Status: Demo in Vorbereitung

Link: /tools/fehlbarkeits-evaluationsradar/

## SDG-Narrativ-Monitor

Beschreibung: Analysiert, wie SDGs und SDG+ in Debatten verzerrt oder verschwoerungsfoermig umgedeutet werden.

Nutzen: Schuetzt globale Kooperation vor falschen Herrschaftsnarrativen.

Status: Demo in Vorbereitung

Link: /tools/sdg-narrativ-monitor/

## Rechtsschutz- und Ombuds-Check

Beschreibung: Prueft Transparenz, Widerspruch, Anfechtung, Ombudsstelle und Korrekturwege.

Nutzen: Verankert Wirkungsmessung rechtsstaatlich.

Status: Demo in Vorbereitung

Link: /tools/rechtsschutz-ombuds-check/