# Wirkungsindikatoren Rang 21

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: Indikatorendokument

## Executive Summary

Die Wirkungsindikatoren fuer Rang 21 messen nicht Kritik als Meinung, sondern Qualitaet der Schutzarchitektur. Sie pruefen, ob Anwendungen transparent, anfechtbar, beteiligungsorientiert, datensparsam, lernfaehig und freiheitskompatibel sind.

## Indikatoren

WOK-GOV-2101: Technokratie-Risiko. Messlogik: Anteil automatisierter Entscheidungen mit menschlicher Pruefung, Anfechtung und Begruendungspflicht. Bezug: SDG+ Rechtsstaatlichkeit.

WOK-GOV-2102: Rechtsschutzfaehigkeit. Messlogik: Existenz von Beschwerde-, Ombuds- und Korrekturwegen je Wirkungsinstrument. Bezug: SDG 16.

WOK-DATA-2103: Datenmacht-Konzentration. Messlogik: Grad der Zentralisierung von Wirkungsdaten, Zugriffsrechten und Modellhoheit. Bezug: SDG+ digitale Selbstbestimmung.

WOK-DISC-2104: Narrativ-Verzerrung. Messlogik: Reichweite von Kontroll-, Weltregierung- und Social-Credit-Frames ohne Faktenbasis. Bezug: SDG+ Diskursfaehigkeit.

WOK-AUD-2105: Wirkungssimulation. Messlogik: Anteil positiver Wirkungsbehauptungen ohne Datenqualitaet, Benchmark, Audit oder Rueckkopplung. Bezug: SDG 12 / SDG+ Transparenz.

WOK-EVAL-2106: Fehlbarkeitskennzeichnung. Messlogik: Anteil der Bewertungen mit Unsicherheitsklasse, Datenqualitaetsklasse und Revisionsdatum. Bezug: SDG 16.

WOK-PART-2107: Beteiligungsqualitaet. Messlogik: Betroffenenbeteiligung und oeffentliche Konsultation vor Verbindlichkeit. Bezug: SDG 16 / SDG 17.

WOK-MARKT-2108: Markt- und Innovationsschutz. Messlogik: KMU-Tauglichkeit, dezentrale Suchprozesse und Schutz vor zentraler Ergebnisplanung. Bezug: SDG 8 / SDG 9.

## Anwendung

Die Indikatoren werden fuer Pilotprojekte, Website-Tools, Gesetzesentwuerfe, Verwaltungsvorhaben, Produktkennzeichnung, KI-Systeme und Kommunikationsprojekte genutzt. Sie dienen nicht der Bewertung von Personen.

## Quellen

Quellenrahmen: Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XVII, Kapitel 101 bis 106.; Natalie Weber: Grundlagenpapier Wirkungsökonomie WÖk, 2025, Abschnitte Umsetzung, Transformation, Narrative, Change-Management und Akzeptanz.; Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.; United Nations: Transforming our world: The 2030 Agenda for Sustainable Development, https://sdgs.un.org/2030agenda.; European Commission: AI Act and guidelines on prohibited AI practices, https://digital-strategy.ec.europa.eu/.; European Commission: Digital Services Act, https://digital-strategy.ec.europa.eu/.; European Commission: Better regulation guidelines and toolbox, https://commission.europa.eu/.; OECD: Recommendation of the Council on Regulatory Policy and Governance, 2012, https://legalinstruments.oecd.org/.; NIST: Artificial Intelligence Risk Management Framework, https://www.nist.gov/itl/ai-risk-management-framework.; Council of Europe: Framework Convention on Artificial Intelligence and human rights, democracy and the rule of law, https://www.coe.int/.