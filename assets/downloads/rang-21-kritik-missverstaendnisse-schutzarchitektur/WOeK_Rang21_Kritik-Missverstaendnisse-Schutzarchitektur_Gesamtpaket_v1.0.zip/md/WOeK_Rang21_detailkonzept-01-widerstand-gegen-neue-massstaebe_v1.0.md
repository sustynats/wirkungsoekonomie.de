# Detailkonzept 1: Widerstand gegen neue Massstaebe

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: Detailkonzept

**Kurzbeschreibung:** Warum neue Bewertungslogiken alte Selbstverstaendlichkeiten, Machtpositionen und Statusordnungen irritieren.

## Executive Summary

Warum neue Bewertungslogiken alte Selbstverstaendlichkeiten, Machtpositionen und Statusordnungen irritieren.

Rang 21 bildet die Kritik-, Missverstaendnis- und Schutzarchitektur der Wirkungsökonomie. Der Bereich behandelt nicht die naechste Anwendung, sondern die Bedingungen, unter denen die gesamte WÖk glaubwuerdig, demokratisch, rechtssicher und lernfaehig bleibt.

Wirkung ist neutral und relational. Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein. Bewertet wird am Referenzrahmen SDGs, Agenda 2030 und SDG+. Ziel ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Kritik ist kein Stoerfall, sondern ein Stresstest. Die Wirkungsökonomie wird nicht stark, weil sie Einwaende abwehrt. Sie wird stark, wenn sie berechtigte Kritik verarbeitet, Missverstaendnisse klaert, ideologische Projektionen erkennt und eigene Missbrauchsrisiken architektonisch begrenzt.

Rang 21 zieht klare rote Linien: keine Personenbewertung, keine Gesinnungsbewertung, keine allgemeine Lebensfuehrungskontrolle, keine Black-Box-KI, keine zentrale Ergebnisplanung, keine scheinobjektive Zahl ohne demokratische Entscheidung und kein Wahrheitsmonopol.

Dieses Detailkonzept beantwortet nicht nur einen Einwand. Es zeigt, wie aus dem Einwand eine Schutzregel, ein Indikator, ein politischer Entscheidungspunkt und ein Website-Baustein wird.

Die zentrale Frage lautet: Wie bleibt Wirkungsmessung freiheitsfaehig, demokratisch, rechtsstaatlich und lernend, ohne in Wirkungsblindheit zurueckzufallen?

## 1. Ausgangslage

Der Themenbereich "Widerstand gegen neue Massstaebe" entscheidet darueber, ob die Wirkungsökonomie als Rueckkopplungsarchitektur oder als Kontrollversprechen wahrgenommen wird.

Neue Massstaebe veraendern Sichtbarkeit. Was bisher als normale Kostenrechnung, normale Marktlogik oder normale politische Routine galt, wird ploetzlich begruendungspflichtig.

Diese Verschiebung erzeugt reale Irritation. Sie betrifft nicht nur Interessen, sondern auch Selbstbilder: Wer bisher als leistungsstark, erfolgreich oder relevant galt, muss erklaeren, welche Wirkung dahintersteht.

Rang 21 nimmt diese Reaktion ernst. Er macht sie nicht klein, sondern uebersetzt sie in demokratische Schutzarchitektur.

## 2. Begriffslogik

Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Kritik kann selbst Wirkung erzeugen, wenn sie Vertrauen staerkt, Risiken sichtbar macht, Polarisierung ausloest oder demokratische Korrektur blockiert.

Wirkungspotenzial ist noch keine Wirkung. Ein Verdacht, ein Frame oder eine Sorge veraendert zunaechst Moeglichkeitsraeume. Erst wenn Entscheidungen, Verhalten, Vertrauen oder institutionelle Prozesse sich veraendern, liegt eingetretene Wirkung vor.

Wirkungsrisiko beschreibt die Moeglichkeit negativer oder destabilisierender Wirkung. In Rang 21 werden Einwaende deshalb nach ihrem Risiko und nach ihrem Wahrheitsgehalt geordnet.

Positive Netto-Wirkung entsteht nur, wenn Schutzmechanismen nicht durch andere Vorteile ueberdeckt werden. Ein Effizienzgewinn kann einen Grundrechtsverlust nicht kompensieren.

## 3. Fachfokus

Der spezifische Fokus umfasst: Massstaebe als Machtordnungen, Widerstand jenseits von Interessen, Identitaetskonflikte, produktive Kritik, Kommunikation ohne Abwehrhaltung.

Jeder Fokuspunkt wird als Wirkpfad gelesen: Welche Sorge wird sichtbar? Welche tatsaechliche Wirkung kann daraus entstehen? Welche Gegenmassnahme ist angemessen? Welche Rolle traegt Verantwortung?

Der Fokus ist nicht nur kommunikativ. Er betrifft Daten, Recht, Institutionen, Tools, Wissenschaft, Medien, Unternehmen, Verwaltung und politische Entscheidung.

Die Website muss deshalb pro Fokuspunkt kurze Klartexte, vertiefende Langtexte, Toolkarten, FAQ und Querverlinkungen bereitstellen.

## 4. Berechtigte Kritik

Berechtigte Kritik betrifft Datenqualitaet, Datenschutz, Buerokratie, KMU-Tauglichkeit, Machtkonzentration, politische Instrumentalisierung, algorithmische Verzerrung, soziale Haerten, Rechtswege und Messunsicherheit.

Diese Kritik darf nicht rhetorisch beruhigt werden. Sie muss in Anforderungen uebersetzt werden: offene Methoden, Datenqualitaetsklassen, Datenschutz-Folgenabschaetzung, Widerspruch, Ombudsstelle, menschliche Pruefung und externe Evaluation.

Berechtigte Kritik ist eine positive Systemressource. Sie verhindert, dass die WÖk dogmatisch wird. Sie zwingt zu Versionierung, Pilotierung und Korrektur.

Kritik wird erst destruktiv, wenn sie trotz besserer Informationen in falschen Kontrollnarrativen verharrt oder demokratische Rueckkopplung pauschal delegitimiert.

## 5. Missverstaendnisse und Projektionen

Ein haeufiges Missverstaendnis ist die Verwechslung von Wirkungsbewertung mit Personenbewertung. Die WÖk bewertet nicht den inneren Wert eines Menschen, sondern Zustandsveraenderungen durch Strukturen, Produkte, Organisationen und Regeln.

Ein zweites Missverstaendnis ist die Verwechslung von Rueckkopplung mit Kontrolle. Rueckkopplung macht Folgen sichtbar. Kontrolle beginnt dort, wo private Lebensfuehrung ueberwacht, Verhalten erzwungen oder Rechte an Scores gekoppelt werden.

Ein drittes Missverstaendnis ist die Verwechslung von globalen Zielrahmen mit globaler Herrschaft. Die SDGs sind ein Referenzrahmen fuer Kooperation, keine Weltregierung.

Projektionen werden politisch wirksam, wenn sie reale Angst mit falscher Schlussfolgerung verbinden. Deshalb muss Rang 21 empathisch, aber klar antworten.

## 6. Beispiele

Beispiel Produktlabel: Ein Produktlabel kann Freiheit erhoehen, weil es Folgen sichtbar macht. Es wird gefaehrlich, wenn daraus persoenliche Konsumprofile, Versicherungsnachteile oder Zugangssperren entstehen.

Beispiel kommunale Scorecard: Eine Scorecard kann Haushaltsentscheidungen verbessern. Sie wird technokratisch, wenn politische Zielkonflikte hinter einer Zahl verschwinden oder Betroffene keine Mitsprache erhalten.

Beispiel KI-Auswertung: KI kann Lieferkettenrisiken sichtbar machen. Sie darf aber nicht als Wahrheitsinstanz auftreten oder Entscheidungen ohne Anfechtungsweg automatisieren.

Beispiel SDG-Debatte: Die Agenda 2030 kann als kooperativer Zielrahmen dienen. Sie wird in Verschwoerungsnarrativen verzerrt, wenn Kooperation als Unterwerfung dargestellt wird.

## 7. Schutzarchitektur

Die Schutzarchitektur beginnt mit Datensparsamkeit und Zweckbindung. Wirkungsdaten werden nur fuer definierte Zwecke genutzt. Je naeher Daten an Personen heranreichen, desto strenger muessen Schutz, Minimierung und Anfechtbarkeit sein.

Zweitens braucht es Methodentransparenz. Bewertungslogiken, Benchmarks, Datenqualitaetsklassen und Unsicherheiten muessen oeffentlich dokumentiert werden.

Drittens braucht es Rechtsschutz. Betroffene Organisationen, Kommunen, Unternehmen und indirekt betroffene Gruppen muessen Korrektur, Beschwerde, Ombudsverfahren und gerichtliche Pruefung nutzen koennen.

Viertens braucht es demokratische Kontrolle. Der Wirkungsrat darf keine Ersatzregierung werden. Er muss plural, transparent, begrenzt, rechenschaftspflichtig und wissenschaftlich anschlussfaehig arbeiten.

## 8. Daten, KI und Modellgrenzen

Digitale Systeme koennen Kritikfelder verstaerken. Eine fehlerhafte Bewertung, die manuell klein bleibt, kann durch Plattformen, KI oder automatisierte Verwaltung massenhaft wirken.

Modelle brauchen Dokumentation: Datenquelle, Bewertungslogik, Kontextgrenzen, Bias-Risiken, Aktualisierungsdatum, Verantwortliche und Anfechtungsweg.

KI darf nicht Richterin der Wirkung werden. Sie kann Muster erkennen, Risiken markieren und Pruefprozesse unterstuetzen. Die normative Bewertung bleibt menschlich, institutionell, demokratisch und rechtsstaatlich.

Diese Grenze ist wichtig, weil Kritik an der WÖk dort eskaliert, wo Menschen das Gefuehl haben, einer unsichtbaren Maschine ausgeliefert zu sein.

## 9. Indikatoren

Geeignete Indikatoren sind: Anteil offengelegter Methoden, Anteil anfechtbarer Bewertungen, Datenqualitaetsklasse, Revisionsdatum, Beteiligungsquote, Zahl korrigierter Bewertungen und Beschwerdebearbeitungsdauer.

Weitere Indikatoren sind: Anteil menschlich gepruefter KI-Empfehlungen, Zahl oeffentlicher Konsultationen, KMU-Nachweisaufwand, Evaluationsrhythmus, Dokumentation von Zielkonflikten und Anteil reversibler Pilotmassnahmen.

Indikatoren duerfen keine neue Scheingenauigkeit erzeugen. Sie muessen erklaeren, was sie messen, was sie nicht messen und welche Unsicherheit bleibt.

Die Indikatoren dienen nicht dazu, Menschen zu sortieren. Sie dienen dazu, Verfahren, Institutionen und Wirkungsinstrumente zu verbessern.

## 10. Politische Anschlussfaehigkeit

Die WÖk liefert keinen fertigen Parteiprogrammtext. Parteien behalten Ausgestaltungsspielraum. Sie koennen unterschiedliche Wege waehlen, wie viel Pilotierung, Regulierung, Marktinstrument, Datenschutz oder sozialer Schutz sie priorisieren.

Entscheidend ist die pruefbare Wirkung. Wer Freiheit betont, muss zeigen, wie Freiheit vor falschen Preisen, Monopolen und Datenmacht geschuetzt wird. Wer Regulierung betont, muss zeigen, wie sie vor Technokratie, Buerokratie und Machtmissbrauch geschuetzt wird.

Rang 21 macht politische Anschlussfaehigkeit breiter: liberal ueber Freiheitsschutz, sozial ueber Gerechtigkeit, gruen ueber Anti-Greenwashing, konservativ ueber Institutionen und Ordnung, kommunal ueber Beteiligung und Konfliktmoderation.

Die WÖk beseitigt politische Unterschiede nicht. Sie macht sie wirkungsbezogen pruefbar.

## 11. Website und Akademie

Die Website muss dieses Detailkonzept vollstaendig online lesbar machen. Ein PDF allein reicht nicht. Nutzer:innen sollen die Argumentation im Browser lesen, drucken, als PDF herunterladen und als DOCX weiterbearbeiten koennen.

Die Seite braucht mobiles Inhaltsverzeichnis, Downloadbuttons, Toolkarten, SDG-/SDG+-Block, Quellen, Glossarlinks und Querverweise zu Rang 17, Rang 18, Rang 20, Staat und Demokratie sowie Medien und Oeffentlichkeit.

In der Akademie kann dieses Konzept als Modul fuer Kritikkompetenz, Wirkungsargumentation, digitale Rechte und demokratische Schutzarchitektur genutzt werden.

Die CodeX-Anweisung darf nicht als oeffentlicher Inhalt erscheinen. Sie gehoert in den Projekt- oder Adminbereich.

## 12. Evaluation und Korrektur

Evaluation prueft nicht nur, ob ein Schutzmechanismus formal existiert. Sie prueft, ob er wirkt. Wurde eine Beschwerde bearbeitet? Wurde eine falsche Bewertung korrigiert? Haben Betroffene die Methode verstanden?

Evaluation muss Nebenwirkungen erfassen: Steigt Vertrauen oder sinkt es? Entsteht Buerokratie? Werden kleine Akteure ueberlastet? Wird eine Minderheit stigmatisiert? Werden Verfahren langsamer oder gerechter?

Ein Einwand verschwindet nicht, weil er beantwortet wurde. Er bleibt beobachtbar, solange das Risiko besteht. Deshalb braucht jedes Wirkungsinstrument ein Revisionsdatum.

Versionierung ist Pflicht: Jede Methode braucht Datum, Version, Aenderungslog und Begruendung.

## 13. Pruefkatalog fuer Website und Redaktion

Jede oeffentliche Seite zu diesem Thema muss folgende Fragen sichtbar beantworten: Was ist der Einwand? Welche reale Sorge steckt darin? Welche falsche Zuspitzung kann entstehen? Welche rote Linie zieht die WÖk? Welcher Schutzmechanismus ist verpflichtend? Wer kann widersprechen? Wer prueft? Wann wird korrigiert?

Die Redaktion darf Einwaende nicht als Randnotiz behandeln. Ein guter Kritiktext beginnt mit dem staerksten Gegenargument, nicht mit einer Verteidigung. Erst danach wird sauber unterschieden: berechtigte Kritik, Missverstaendnis, Zielkonflikt, Projektion, strategische Desinformation.

Fuer jede Unterseite braucht es eine Kurzantwort fuer den schnellen Einstieg, eine Langantwort fuer die fachliche Tiefe, ein Beispiel fuer den Alltag, einen Hinweis auf rote Linien und eine Toolkarte fuer praktische Pruefung.

Der Pruefkatalog ist kein kosmetisches Element. Er ist die Methode, mit der Rang 21 verhindert, dass Website-Texte zu PR-Texten werden.

## 14. Daten- und Rechtsschutzmodell

Das Datenmodell folgt dem Grundsatz: so viel Wirkungsinformation wie noetig, so wenig personenbezogene Information wie moeglich. Rang 21 bevorzugt aggregierte, rollenbasierte, zweckgebundene und auditierbare Datenstrukturen.

Rechtsschutz muss vor Verbindlichkeit eingebaut werden. Wenn Wirkungsdaten in Steuern, Foerderung, Beschaffung, Kapitalzugang, Versicherbarkeit oder oeffentliche Bewertung einfliessen, muessen Fehler korrigierbar sein.

Ein Rechtsschutzmodell umfasst mindestens: Einsicht in die Bewertungsgrundlage, Begruendungspflicht, Frist fuer Widerspruch, unabhaengige Pruefung, Ombudsstelle, dokumentierte Korrektur, Wiederaufnahme bei neuen Daten und gerichtliche Pruefbarkeit.

Ohne Rechtsschutz wird Wirkungsmessung zur Machttechnik. Mit Rechtsschutz wird sie zur Rueckkopplung, die Fehler sichtbar macht und demokratisch bearbeitbar haelt.

## 15. Rollen und Verantwortlichkeiten

Der Staat setzt den Rechtsrahmen und garantiert Grundrechte. Der Wirkungsrat pflegt Indikatoren, Benchmarks und Methoden. Wissenschaft prueft Datenqualitaet und Unsicherheit. Unternehmen liefern Nachweise. Kommunen melden Infrastruktur- und Sozialraumdaten. Zivilgesellschaft benennt blinde Flecken. Medien uebersetzen, pruefen und kritisieren.

Keine Rolle darf alle Funktionen allein uebernehmen. Wer Daten erhebt, sollte nicht allein bewerten. Wer bewertet, sollte nicht allein sanktionieren. Wer sanktioniert, muss rechtlich und demokratisch kontrolliert werden.

Rollenverteilung ist ein Schutz gegen Machtkonzentration. Sie verhindert, dass Wirkung zu einem privaten Zertifizierungsmarkt, einer staatlichen Kontrolltechnik oder einer politischen Kampagnenwaffe wird.

Jede Website-Unterseite sollte deshalb eine kurze Rollenklaerung enthalten: Wer handelt? Wer prueft? Wer widerspricht? Wer korrigiert? Wer traegt Verantwortung?

## 16. Umsetzungsschritte

Schritt 1: Einwand sammeln und klassifizieren. Schritt 2: fachlichen Wahrheitsgehalt pruefen. Schritt 3: reales Wirkungsrisiko bestimmen. Schritt 4: Schutzmechanismus definieren. Schritt 5: Pilotfeld waehlen. Schritt 6: Datenqualitaet pruefen. Schritt 7: Beteiligung einrichten. Schritt 8: Evaluation festlegen.

Schritt 9: oeffentliche Erklaerung veroeffentlichen. Schritt 10: Widerspruchsweg bereitstellen. Schritt 11: erste Anwendung begrenzen. Schritt 12: Ergebnisse auswerten. Schritt 13: Methode versionieren. Schritt 14: fehlerhafte Teile korrigieren oder zuruecknehmen.

Der Umsetzungspfad ist bewusst langsam genug, um Vertrauen zu schaffen, und schnell genug, um reale Probleme nicht nur zu verwalten. Rang 21 ist die Bremse gegen Schocklogik und der Motor fuer lernende Korrektur.

Umsetzung ohne Schutzarchitektur ist gefaehrlich. Schutzarchitektur ohne Umsetzung bleibt folgenlos. Rang 21 verbindet beides.

## 17. Wirkungsfehler und Gegenmassnahmen

Fehlerart 1: Scheingenauigkeit. Gegenmassnahme: Unsicherheitsklassen, Datenqualitaetsklassen und klare Sprache ueber Grenzen. Fehlerart 2: Ueberwachung. Gegenmassnahme: Aggregation, Datensparsamkeit, Zweckbindung und Verbot allgemeiner Personenprofile.

Fehlerart 3: Technokratie. Gegenmassnahme: politische Entscheidung, oeffentliche Konsultation und Rechtsschutz. Fehlerart 4: Buerokratie. Gegenmassnahme: KMU-Tauglichkeit, Standarddaten, digitale Schnittstellen und gestufte Einfuehrung.

Fehlerart 5: Wirkungssimulation. Gegenmassnahme: externe Pruefung, Reverse Merit Order, offene Korrekturlogs und Sanktionen bei falschen Wirkungsbehauptungen. Fehlerart 6: Polarisierung. Gegenmassnahme: gute Kommunikation, Beispiele, Kritikwerkstatt und Dialogformate.

Diese Gegenmassnahmen sind nicht optional. Sie bilden den Mindeststandard fuer jede wirkungsbasierte Anwendung, die in oeffentliche Entscheidungen oder wirtschaftliche Anreize eingreift.

## 18. Redaktionsbausteine fuer oeffentliche Kommunikation

Kurzformel 1: Die Wirkungsökonomie bewertet keine Menschen. Sie bewertet Wirkungen von Produkten, Organisationen, Regeln, Kapitalfluessen und oeffentlichen Entscheidungen.

Kurzformel 2: Wirkungsmessung ist kein Wahrheitsmonopol. Sie ist ein Verfahren, um Folgen sichtbarer, pruefbarer und korrigierbarer zu machen.

Kurzformel 3: Die WÖk ist keine Planwirtschaft. Maerkte bleiben Suchraeume. Aber Preise, Steuern und Kapital duerfen relevante Schaeden nicht laenger verschweigen.

Kurzformel 4: Fehlbarkeit ist eingebaut. Jede Wirkungsmessung braucht Datenqualitaetsklasse, Unsicherheitsangabe, Revisionsdatum, Widerspruch und Evaluation.

## 19. Verbindung zu anderen Portalen

Rang 21 muss mit Rang 17 Digitalisierung verlinkt werden, weil Datenraeume, KI, Produktpaesse und Plattformlogik die groessten Technokratie- und Ueberwachungsfragen ausloesen.

Rang 21 muss mit Rang 18 Wissen und Wissenschaft verlinkt werden, weil Fehlbarkeit, Replikation, Datenqualitaet und oeffentliche Wahrheit methodische Grundbedingungen sind.

Rang 21 muss mit Rang 20 Transformation verlinkt werden, weil Pilotierung, Akzeptanz, Uebergang, Widerstand und Korrektur dort praktisch werden.

Rang 21 muss ausserdem mit Staat und Demokratie, Medien und Oeffentlichkeit, Finanzsystem und Kapital, Produkte und Konsum, Unternehmen und Wirtschaft sowie SDG-/SDG+-Referenz verknuepft werden.

## 20. Mindeststandard fuer Detailkonzepte

Ein Detailkonzept in Rang 21 muss laenger sein als eine Uebersicht. Es braucht Problemdefinition, Begriffslogik, Beispiele, Risiken, Schutzmechanismen, Datenquellen, Indikatoren, politische Anschlussfaehigkeit, Umsetzungslogik, Evaluationsstruktur und Website-Hinweise.

Wenn ein Text nur eine kurze Antwort auf einen Einwand liefert, ist er ein FAQ-Baustein. Wenn er aber die fachliche, rechtliche, kommunikative und institutionelle Architektur ausarbeitet, darf er als Detailkonzept gelten.

Diese Regel ist wichtig, weil Rang 21 selbst die Qualitaet der gesamten Fachbibliothek schuetzt. Die WÖk darf nicht erneut kurze Grobtexte als Detailkonzepte ausweisen.

Der Standard lautet: Dossier-Niveau, nicht Stichwortsammlung.

## Quellen und Anschlussrahmen

Quellenrahmen: Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XVII, Kapitel 101 bis 106.; Natalie Weber: Grundlagenpapier Wirkungsökonomie WÖk, 2025, Abschnitte Umsetzung, Transformation, Narrative, Change-Management und Akzeptanz.; Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.; United Nations: Transforming our world: The 2030 Agenda for Sustainable Development, https://sdgs.un.org/2030agenda.; European Commission: AI Act and guidelines on prohibited AI practices, https://digital-strategy.ec.europa.eu/.; European Commission: Digital Services Act, https://digital-strategy.ec.europa.eu/.; European Commission: Better regulation guidelines and toolbox, https://commission.europa.eu/.; OECD: Recommendation of the Council on Regulatory Policy and Governance, 2012, https://legalinstruments.oecd.org/.; NIST: Artificial Intelligence Risk Management Framework, https://www.nist.gov/itl/ai-risk-management-framework.; Council of Europe: Framework Convention on Artificial Intelligence and human rights, democracy and the rule of law, https://www.coe.int/.