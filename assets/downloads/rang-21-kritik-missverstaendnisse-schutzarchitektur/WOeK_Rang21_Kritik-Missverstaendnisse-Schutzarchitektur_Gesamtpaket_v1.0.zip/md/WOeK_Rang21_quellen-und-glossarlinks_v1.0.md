# Quellen und Glossarlinks Rang 21

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: Quellen und Glossar

## Quellenrahmen

Quellenrahmen: Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XVII, Kapitel 101 bis 106.; Natalie Weber: Grundlagenpapier Wirkungsökonomie WÖk, 2025, Abschnitte Umsetzung, Transformation, Narrative, Change-Management und Akzeptanz.; Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.; United Nations: Transforming our world: The 2030 Agenda for Sustainable Development, https://sdgs.un.org/2030agenda.; European Commission: AI Act and guidelines on prohibited AI practices, https://digital-strategy.ec.europa.eu/.; European Commission: Digital Services Act, https://digital-strategy.ec.europa.eu/.; European Commission: Better regulation guidelines and toolbox, https://commission.europa.eu/.; OECD: Recommendation of the Council on Regulatory Policy and Governance, 2012, https://legalinstruments.oecd.org/.; NIST: Artificial Intelligence Risk Management Framework, https://www.nist.gov/itl/ai-risk-management-framework.; Council of Europe: Framework Convention on Artificial Intelligence and human rights, democracy and the rule of law, https://www.coe.int/.

## Glossarlinks

Wirkung: Tatsaechliche Veraenderung von Zustaenden. Wirkung ist neutral und relational.

Wirkungspotenzial: Moeglichkeit, dass Wirkung eintreten kann. Noch keine eingetretene Wirkung.

Wirkungsrisiko: Moeglichkeit negativer oder destabilisierender Wirkung.

Positive Netto-Wirkung: Zielgroesse der WÖk: tragfaehige Wirkung fuer Mensch, Planet und Demokratie nach Beruecksichtigung roter Linien.

SDG+: Transparente WÖk-Erweiterung fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

Wirkungssimulation: Darstellung guter Wirkung ohne belastbare Zustandsveraenderung, Datenqualitaet oder Rueckkopplung.

Social-Credit-Rote-Linie: Verbot, Wirkungslogik in allgemeine Personenbewertung, Gehorsamsmessung oder Zugangsbeschraenkung zu verwandeln.

## Website-Hinweise

Quellen muessen in normaler Lesesprache angegeben werden. Keine internen CodeX-Kommentare, keine Tool-Citations und keine Arbeitsnotizen duerfen oeffentlich erscheinen.