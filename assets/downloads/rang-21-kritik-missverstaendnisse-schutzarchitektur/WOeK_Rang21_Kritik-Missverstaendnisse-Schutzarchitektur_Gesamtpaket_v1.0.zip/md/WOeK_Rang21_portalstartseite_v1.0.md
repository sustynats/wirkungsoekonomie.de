# Portalstartseite Rang 21 - Kritik, Missverständnisse und Schutzarchitektur

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: Portalstartseite

**Kurzbeschreibung:** Oeffentliche Startseite fuer Rang 21.

## Executive Summary

Rang 21 bildet die Kritik-, Missverstaendnis- und Schutzarchitektur der Wirkungsökonomie. Der Bereich behandelt nicht die naechste Anwendung, sondern die Bedingungen, unter denen die gesamte WÖk glaubwuerdig, demokratisch, rechtssicher und lernfaehig bleibt.

Wirkung ist neutral und relational. Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein. Bewertet wird am Referenzrahmen SDGs, Agenda 2030 und SDG+. Ziel ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Kritik ist kein Stoerfall, sondern ein Stresstest. Die Wirkungsökonomie wird nicht stark, weil sie Einwaende abwehrt. Sie wird stark, wenn sie berechtigte Kritik verarbeitet, Missverstaendnisse klaert, ideologische Projektionen erkennt und eigene Missbrauchsrisiken architektonisch begrenzt.

Rang 21 zieht klare rote Linien: keine Personenbewertung, keine Gesinnungsbewertung, keine allgemeine Lebensfuehrungskontrolle, keine Black-Box-KI, keine zentrale Ergebnisplanung, keine scheinobjektive Zahl ohne demokratische Entscheidung und kein Wahrheitsmonopol.

Das Portal fuehrt in die Kritikarchitektur ein. Es zeigt, dass Kritik kein Stoerfall ist, sondern ein Prueffeld der Wirkungsökonomie. Es behandelt Freiheit, Markt, Datenschutz, Social Credit, Planwirtschaft, SDGs, Technokratie und Fehlbarkeit.

## Unterbereiche

Widerstand gegen neue Massstaebe; SDGs und Verschwoerungsnarrative; Technokratie und Social Credit; Wirkungssimulation und Manipulation; Freiheit, Markt und Planwirtschaft; Fehlbarkeit und Korrektur; Datenmacht und Datenschutz; Kommunikation und Akzeptanz; Missbrauchsschutz und Rechtsschutz; Kritikwerkstatt und Beteiligung.

## Portalnutzen

Rang 21 verhindert, dass die WÖk naiv oder autoritaer wirkt. Er macht sichtbar, wo Risiken liegen, welche Einwaende berechtigt sind und welche Schutzmechanismen verpflichtend werden muessen.

## Politische Anschlussfaehigkeit

Aufgabe der Politik: Politik muss Kritik als Rueckkopplung organisieren. Sie schafft Regeln, die Wirkungsbewertung transparent, anfechtbar, lernfaehig und demokratisch begrenzt halten.

Politische Rahmenbedingungen: Noetig sind Datenschutz, Rechtsschutz, offene Methoden, unabhaengige Evaluation, Beteiligung, klare rote Linien gegen Personenbewertung und eine Pflicht zur Korrektur.

Ausgestaltungsspielraum: Parteien koennen unterschiedlich gewichten, wie schnell, mit welchen Pilotfeldern, welchen Anreizstaerken und welchen Institutionen die WÖk eingefuehrt wird.

Zielkonflikte: Transparenz kann mit Datenschutz kollidieren, Steuerung mit Freiheit, Geschwindigkeit mit Beteiligung, Standardisierung mit lokaler Anpassung und Missbrauchsschutz mit Verwaltungsaufwand.

Rollenverteilung: Bund, Laender, Kommunen, Wissenschaft, Wirtschaft, Zivilgesellschaft, Medien und Wirkungsrat tragen unterschiedliche Aufgaben. Keine einzelne Instanz darf Bewertungsmonopolistin werden.

Schutz vor Technokratie: Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie informiert, begrenzt und korrigiert. Daten duerfen nicht ueber Menschenwuerde, Grundrechte oder politische Teilhabe gestellt werden.

## Quellen

Quellenrahmen: Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XVII, Kapitel 101 bis 106.; Natalie Weber: Grundlagenpapier Wirkungsökonomie WÖk, 2025, Abschnitte Umsetzung, Transformation, Narrative, Change-Management und Akzeptanz.; Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.; United Nations: Transforming our world: The 2030 Agenda for Sustainable Development, https://sdgs.un.org/2030agenda.; European Commission: AI Act and guidelines on prohibited AI practices, https://digital-strategy.ec.europa.eu/.; European Commission: Digital Services Act, https://digital-strategy.ec.europa.eu/.; European Commission: Better regulation guidelines and toolbox, https://commission.europa.eu/.; OECD: Recommendation of the Council on Regulatory Policy and Governance, 2012, https://legalinstruments.oecd.org/.; NIST: Artificial Intelligence Risk Management Framework, https://www.nist.gov/itl/ai-risk-management-framework.; Council of Europe: Framework Convention on Artificial Intelligence and human rights, democracy and the rule of law, https://www.coe.int/.

## Glossar

Wirkung: Tatsaechliche Veraenderung von Zustaenden. Wirkung ist neutral und relational.

Wirkungspotenzial: Moeglichkeit, dass Wirkung eintreten kann. Noch keine eingetretene Wirkung.

Wirkungsrisiko: Moeglichkeit negativer oder destabilisierender Wirkung.

Positive Netto-Wirkung: Zielgroesse der WÖk: tragfaehige Wirkung fuer Mensch, Planet und Demokratie nach Beruecksichtigung roter Linien.

SDG+: Transparente WÖk-Erweiterung fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

Wirkungssimulation: Darstellung guter Wirkung ohne belastbare Zustandsveraenderung, Datenqualitaet oder Rueckkopplung.

Social-Credit-Rote-Linie: Verbot, Wirkungslogik in allgemeine Personenbewertung, Gehorsamsmessung oder Zugangsbeschraenkung zu verwandeln.