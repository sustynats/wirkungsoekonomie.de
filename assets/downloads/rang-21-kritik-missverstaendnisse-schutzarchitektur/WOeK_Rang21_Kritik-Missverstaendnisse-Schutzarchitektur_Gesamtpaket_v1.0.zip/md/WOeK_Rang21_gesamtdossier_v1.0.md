# Gesamtdossier Rang 21 - Kritik, Missverständnisse und Schutzarchitektur

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: Gesamtdossier

**Kurzbeschreibung:** Umfassendes Fach- und Portalgesamtdossier.

## Executive Summary

Rang 21 bildet die Kritik-, Missverstaendnis- und Schutzarchitektur der Wirkungsökonomie. Der Bereich behandelt nicht die naechste Anwendung, sondern die Bedingungen, unter denen die gesamte WÖk glaubwuerdig, demokratisch, rechtssicher und lernfaehig bleibt.

Wirkung ist neutral und relational. Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein. Bewertet wird am Referenzrahmen SDGs, Agenda 2030 und SDG+. Ziel ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Kritik ist kein Stoerfall, sondern ein Stresstest. Die Wirkungsökonomie wird nicht stark, weil sie Einwaende abwehrt. Sie wird stark, wenn sie berechtigte Kritik verarbeitet, Missverstaendnisse klaert, ideologische Projektionen erkennt und eigene Missbrauchsrisiken architektonisch begrenzt.

Rang 21 zieht klare rote Linien: keine Personenbewertung, keine Gesinnungsbewertung, keine allgemeine Lebensfuehrungskontrolle, keine Black-Box-KI, keine zentrale Ergebnisplanung, keine scheinobjektive Zahl ohne demokratische Entscheidung und kein Wahrheitsmonopol.

Das Gesamtdossier ordnet Rang 21 als Schutz- und Legitimationsarchitektur der gesamten WÖk ein. Es verbindet Kritik, demokratische Begrenzung, Anti-Simulation, Fehlbarkeit, Datenschutz, Rechtsschutz, Toolkarten und politische Anschlussfaehigkeit.

## Massstaebe und Widerstand

Kapitel 1 behandelt Massstaebe und Widerstand. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## SDGs und globale Kooperation

Kapitel 2 behandelt SDGs und globale Kooperation. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Technokratie und Social Credit

Kapitel 3 behandelt Technokratie und Social Credit. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Wirkungssimulation und Manipulation

Kapitel 4 behandelt Wirkungssimulation und Manipulation. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Freiheit und Markt

Kapitel 5 behandelt Freiheit und Markt. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Fehlbarkeit und Unsicherheit

Kapitel 6 behandelt Fehlbarkeit und Unsicherheit. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Datenmacht und Datenschutz

Kapitel 7 behandelt Datenmacht und Datenschutz. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Kommunikation und Akzeptanz

Kapitel 8 behandelt Kommunikation und Akzeptanz. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Governance und Rechtsschutz

Kapitel 9 behandelt Governance und Rechtsschutz. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Kritikwerkstatt und Beteiligung

Kapitel 10 behandelt Kritikwerkstatt und Beteiligung. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Indikatoren und Tools

Kapitel 11 behandelt Indikatoren und Tools. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Umsetzung auf der Website

Kapitel 12 behandelt Umsetzung auf der Website. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Rechtsstaatliche Mindestanforderungen

Kapitel 13 behandelt Rechtsstaatliche Mindestanforderungen. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Datenethik und Datenschutz

Kapitel 14 behandelt Datenethik und Datenschutz. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Anti-Simulationslogik

Kapitel 15 behandelt Anti-Simulationslogik. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Fehlbarkeit als Staerke

Kapitel 16 behandelt Fehlbarkeit als Staerke. Der Schwerpunkt liegt auf pruefbarer Abgrenzung statt Verteidigung. Jede Kritik wird danach geordnet, ob sie ein berechtigtes Risiko, ein Missverstaendnis, einen Zielkonflikt, eine Projektion oder einen strategischen Angriff darstellt.

Die Methode lautet: beschreiben, einordnen, bewerten und Rueckkopplung definieren. Dadurch wird Kritik nicht moralisiert, sondern in eine lernende Architektur ueberfuehrt.

Wirkungsökonomisch relevant ist immer die Frage, welche Zustandsveraenderung aus einem Einwand entsteht. Ein Einwand kann Vertrauen staerken, wenn er echte Risiken sichtbar macht. Er kann Vertrauen zerstoeren, wenn er falsche Angstnarrative erzeugt.

Der Schutzmechanismus besteht aus Transparenz, Beteiligung, Datenqualitaetsklassen, Rechtsschutz, Evaluationspflicht, unabhaengiger Pruefung, demokratischer Entscheidung und klaren roten Linien gegen Personenbewertung.

## Politische Anschlussfaehigkeit

Aufgabe der Politik: Politik muss Kritik als Rueckkopplung organisieren. Sie schafft Regeln, die Wirkungsbewertung transparent, anfechtbar, lernfaehig und demokratisch begrenzt halten.

Politische Rahmenbedingungen: Noetig sind Datenschutz, Rechtsschutz, offene Methoden, unabhaengige Evaluation, Beteiligung, klare rote Linien gegen Personenbewertung und eine Pflicht zur Korrektur.

Ausgestaltungsspielraum: Parteien koennen unterschiedlich gewichten, wie schnell, mit welchen Pilotfeldern, welchen Anreizstaerken und welchen Institutionen die WÖk eingefuehrt wird.

Zielkonflikte: Transparenz kann mit Datenschutz kollidieren, Steuerung mit Freiheit, Geschwindigkeit mit Beteiligung, Standardisierung mit lokaler Anpassung und Missbrauchsschutz mit Verwaltungsaufwand.

Rollenverteilung: Bund, Laender, Kommunen, Wissenschaft, Wirtschaft, Zivilgesellschaft, Medien und Wirkungsrat tragen unterschiedliche Aufgaben. Keine einzelne Instanz darf Bewertungsmonopolistin werden.

Schutz vor Technokratie: Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie informiert, begrenzt und korrigiert. Daten duerfen nicht ueber Menschenwuerde, Grundrechte oder politische Teilhabe gestellt werden.

## Dossier-Erweiterung: Schutzlogik ueber alle Portale

Rang 21 wirkt in alle anderen Portale hinein. Produkte brauchen Schutz vor Wirkungssimulation. Unternehmen brauchen Schutz vor Konzernbuerokratie und KMU-Ueberlastung. Finanzsysteme brauchen Schutz vor privaten Bewertungsmonopolen. Medien brauchen Schutz vor Zensurvorwurf und Desinformation. Digitalisierung braucht Schutz vor Datenmacht und Social-Credit-Logik.

Deshalb sollte jedes Wirkungsfeld eine Kurzbox enthalten: Welche Kritik ist berechtigt? Welche Missverstaendnisse sind wahrscheinlich? Welche roten Linien gelten? Welche Korrekturwege gibt es? Welche Daten duerfen nicht erhoben werden?

Die Schutzlogik ist kein Zusatz. Sie ist eine Bedingung fuer Skalierung. Ohne sie bleibt Wirkungsmessung fragil, angreifbar und potenziell missbrauchbar.

Das Gesamtdossier empfiehlt deshalb, Rang 21 als Querschnittsanker auf der Website prominent zu verlinken.

## Quellen

Quellenrahmen: Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XVII, Kapitel 101 bis 106.; Natalie Weber: Grundlagenpapier Wirkungsökonomie WÖk, 2025, Abschnitte Umsetzung, Transformation, Narrative, Change-Management und Akzeptanz.; Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.; United Nations: Transforming our world: The 2030 Agenda for Sustainable Development, https://sdgs.un.org/2030agenda.; European Commission: AI Act and guidelines on prohibited AI practices, https://digital-strategy.ec.europa.eu/.; European Commission: Digital Services Act, https://digital-strategy.ec.europa.eu/.; European Commission: Better regulation guidelines and toolbox, https://commission.europa.eu/.; OECD: Recommendation of the Council on Regulatory Policy and Governance, 2012, https://legalinstruments.oecd.org/.; NIST: Artificial Intelligence Risk Management Framework, https://www.nist.gov/itl/ai-risk-management-framework.; Council of Europe: Framework Convention on Artificial Intelligence and human rights, democracy and the rule of law, https://www.coe.int/.

## Glossar

Wirkung: Tatsaechliche Veraenderung von Zustaenden. Wirkung ist neutral und relational.

Wirkungspotenzial: Moeglichkeit, dass Wirkung eintreten kann. Noch keine eingetretene Wirkung.

Wirkungsrisiko: Moeglichkeit negativer oder destabilisierender Wirkung.

Positive Netto-Wirkung: Zielgroesse der WÖk: tragfaehige Wirkung fuer Mensch, Planet und Demokratie nach Beruecksichtigung roter Linien.

SDG+: Transparente WÖk-Erweiterung fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

Wirkungssimulation: Darstellung guter Wirkung ohne belastbare Zustandsveraenderung, Datenqualitaet oder Rueckkopplung.

Social-Credit-Rote-Linie: Verbot, Wirkungslogik in allgemeine Personenbewertung, Gehorsamsmessung oder Zugangsbeschraenkung zu verwandeln.