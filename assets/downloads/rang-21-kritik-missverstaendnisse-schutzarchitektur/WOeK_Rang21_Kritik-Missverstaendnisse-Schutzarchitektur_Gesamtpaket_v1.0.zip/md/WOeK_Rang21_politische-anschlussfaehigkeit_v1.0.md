# Politische Anschlussfähigkeit Rang 21

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: Politische Anschlussfaehigkeit

## Politische Anschlussfaehigkeit und Umsetzungsoptionen

Aufgabe der Politik: Politik muss Kritik als Rueckkopplung organisieren. Sie schafft Regeln, die Wirkungsbewertung transparent, anfechtbar, lernfaehig und demokratisch begrenzt halten.

Politische Rahmenbedingungen: Noetig sind Datenschutz, Rechtsschutz, offene Methoden, unabhaengige Evaluation, Beteiligung, klare rote Linien gegen Personenbewertung und eine Pflicht zur Korrektur.

Ausgestaltungsspielraum: Parteien koennen unterschiedlich gewichten, wie schnell, mit welchen Pilotfeldern, welchen Anreizstaerken und welchen Institutionen die WÖk eingefuehrt wird.

Zielkonflikte: Transparenz kann mit Datenschutz kollidieren, Steuerung mit Freiheit, Geschwindigkeit mit Beteiligung, Standardisierung mit lokaler Anpassung und Missbrauchsschutz mit Verwaltungsaufwand.

Rollenverteilung: Bund, Laender, Kommunen, Wissenschaft, Wirtschaft, Zivilgesellschaft, Medien und Wirkungsrat tragen unterschiedliche Aufgaben. Keine einzelne Instanz darf Bewertungsmonopolistin werden.

Schutz vor Technokratie: Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie informiert, begrenzt und korrigiert. Daten duerfen nicht ueber Menschenwuerde, Grundrechte oder politische Teilhabe gestellt werden.

## Parteipolitische Anschlussfaehigkeit

Liberale Akteure koennen Rang 21 als Schutz vor Ueberwachung, Buerokratie und Planwirtschaft lesen. Soziale Akteure koennen ihn als Schutz vor Ungleichheit und Machtkonzentration lesen. Gruene Akteure koennen ihn als Anti-Greenwashing-Architektur lesen. Konservative Akteure koennen ihn als Schutz institutioneller Stabilitaet und Rechtsstaatlichkeit lesen.