# SDG-/SDG+-Block Rang 21

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: SDG-/SDG+-Block

## SDG-Bezug

Relevante SDGs: SDG 4 Bildung, SDG 8 Arbeit, SDG 9 Infrastruktur, SDG 10 Ungleichheiten, SDG 12 Konsum und Produktion, SDG 16 Frieden, Gerechtigkeit und starke Institutionen, SDG 17 Partnerschaften.

## SDG+-Bezug

SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der WÖk fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

## Warum SDG+ hier unverzichtbar ist

Die SDGs koennen nur erreicht werden, wenn oeffentliche Wahrheit, Rechtsstaat, Vertrauen, Streitfaehigkeit und digitale Selbstbestimmung stabil bleiben. Rang 21 schuetzt genau diese Voraussetzungen.

## Quellen

Quellenrahmen: Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XVII, Kapitel 101 bis 106.; Natalie Weber: Grundlagenpapier Wirkungsökonomie WÖk, 2025, Abschnitte Umsetzung, Transformation, Narrative, Change-Management und Akzeptanz.; Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.; United Nations: Transforming our world: The 2030 Agenda for Sustainable Development, https://sdgs.un.org/2030agenda.; European Commission: AI Act and guidelines on prohibited AI practices, https://digital-strategy.ec.europa.eu/.; European Commission: Digital Services Act, https://digital-strategy.ec.europa.eu/.; European Commission: Better regulation guidelines and toolbox, https://commission.europa.eu/.; OECD: Recommendation of the Council on Regulatory Policy and Governance, 2012, https://legalinstruments.oecd.org/.; NIST: Artificial Intelligence Risk Management Framework, https://www.nist.gov/itl/ai-risk-management-framework.; Council of Europe: Framework Convention on Artificial Intelligence and human rights, democracy and the rule of law, https://www.coe.int/.