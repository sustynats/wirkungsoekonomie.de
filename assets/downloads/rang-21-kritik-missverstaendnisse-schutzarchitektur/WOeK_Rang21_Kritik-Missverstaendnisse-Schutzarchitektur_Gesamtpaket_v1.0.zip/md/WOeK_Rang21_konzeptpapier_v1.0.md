# Konzeptpapier Rang 21 - Kritik, Missverständnisse und Schutzarchitektur

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: Konzeptpapier

**Kurzbeschreibung:** Langfassung zur Begruendung von Rang 21.

## Executive Summary

Rang 21 bildet die Kritik-, Missverstaendnis- und Schutzarchitektur der Wirkungsökonomie. Der Bereich behandelt nicht die naechste Anwendung, sondern die Bedingungen, unter denen die gesamte WÖk glaubwuerdig, demokratisch, rechtssicher und lernfaehig bleibt.

Wirkung ist neutral und relational. Wirkung ist die tatsaechliche Veraenderung von Zustaenden. Sie kann positiv, negativ oder neutral sein. Bewertet wird am Referenzrahmen SDGs, Agenda 2030 und SDG+. Ziel ist positive Netto-Wirkung fuer Mensch, Planet und Demokratie.

Kritik ist kein Stoerfall, sondern ein Stresstest. Die Wirkungsökonomie wird nicht stark, weil sie Einwaende abwehrt. Sie wird stark, wenn sie berechtigte Kritik verarbeitet, Missverstaendnisse klaert, ideologische Projektionen erkennt und eigene Missbrauchsrisiken architektonisch begrenzt.

Rang 21 zieht klare rote Linien: keine Personenbewertung, keine Gesinnungsbewertung, keine allgemeine Lebensfuehrungskontrolle, keine Black-Box-KI, keine zentrale Ergebnisplanung, keine scheinobjektive Zahl ohne demokratische Entscheidung und kein Wahrheitsmonopol.

Neue Massstaebe erzeugen Widerstand, weil sie Machtordnungen beruehren. Wer lange nach Kapital, Gewinn, Wachstum, Reichweite oder Einkommen bewertet wurde, erlebt eine Umstellung auf Wirkung nicht als neutrale Methodenfrage.

Ohne Rang 21 entstuende ein Legitimationsloch. Gegner:innen koennten die WÖk als Social Credit, Planwirtschaft, Ueberwachung, Weltregierung, Moralstaat oder Buerokratiemonster framen. Rang 21 liefert die inhaltliche, rechtliche und kommunikative Antwort.

## Leitprinzipien

Erstens: Kritik ist Rueckkopplung. Zweitens: Schutz vor Missbrauch ist Teil der Architektur. Drittens: keine Personenbewertung. Viertens: kein Wahrheitsmonopol. Fuenftens: keine zentrale Ergebnisplanung. Sechstens: Unsicherheit wird markiert. Siebtens: demokratische Kontrolle bleibt Vorrang vor technischer Effizienz.

Diese Prinzipien muessen in Website, Akademie, Dossiers, Tools, Gesetzesentwuerfen und Kommunikation konsistent erscheinen.

## Abgrenzungen

Die WÖk ist nicht Social Credit, weil sie keine Menschen nach Gehorsam, Konsumverhalten, politischer Haltung oder moralischer Konformitaet klassifiziert.

Die WÖk ist nicht Planwirtschaft, weil sie keine zentrale Produktions- und Mengenplanung ersetzt, sondern Marktsignale um Wirkungsinformationen ergaenzt.

Die WÖk ist nicht Technokratie, wenn sie demokratische Entscheidung, Rechtsschutz, Beteiligung und oeffentliche Methodenkritik verankert.

## Umsetzungslogik

Rang 21 wird als Portal umgesetzt. Es enthaelt Gesamtdossier, zehn Detailkonzepte, Toolkarten, Schutzmatrix, FAQ, Indikatoren und CodeX-Anweisung. Alle Inhalte liegen als PDF, DOCX, Markdown und HTML vor.

Fuer die politische Kommunikation sollte Rang 21 frueh sichtbar werden. Wer nur Wirkungssteuer oder Scorecards sieht, kann Kontrollframes entwickeln. Wer zuerst die Schutzarchitektur sieht, erkennt die demokratische Begrenzung.

## Politische Anschlussfaehigkeit

Aufgabe der Politik: Politik muss Kritik als Rueckkopplung organisieren. Sie schafft Regeln, die Wirkungsbewertung transparent, anfechtbar, lernfaehig und demokratisch begrenzt halten.

Politische Rahmenbedingungen: Noetig sind Datenschutz, Rechtsschutz, offene Methoden, unabhaengige Evaluation, Beteiligung, klare rote Linien gegen Personenbewertung und eine Pflicht zur Korrektur.

Ausgestaltungsspielraum: Parteien koennen unterschiedlich gewichten, wie schnell, mit welchen Pilotfeldern, welchen Anreizstaerken und welchen Institutionen die WÖk eingefuehrt wird.

Zielkonflikte: Transparenz kann mit Datenschutz kollidieren, Steuerung mit Freiheit, Geschwindigkeit mit Beteiligung, Standardisierung mit lokaler Anpassung und Missbrauchsschutz mit Verwaltungsaufwand.

Rollenverteilung: Bund, Laender, Kommunen, Wissenschaft, Wirtschaft, Zivilgesellschaft, Medien und Wirkungsrat tragen unterschiedliche Aufgaben. Keine einzelne Instanz darf Bewertungsmonopolistin werden.

Schutz vor Technokratie: Wirkungsmessung ersetzt keine demokratische Entscheidung. Sie informiert, begrenzt und korrigiert. Daten duerfen nicht ueber Menschenwuerde, Grundrechte oder politische Teilhabe gestellt werden.

## Konzeptuelle Einordnung

Rang 21 ist der Ort, an dem die Wirkungsökonomie ihre eigene Macht begrenzt. Das ist mehr als Kommunikation. Es ist eine systemische Selbstbindung. Jede Architektur, die Wirkung in Preise, Steuern, Kapital, Beschaffung oder oeffentliche Bewertung zurueckfuehrt, braucht eine ebenso starke Architektur fuer Kritik, Rechtsschutz und Korrektur.

Die historische Erfahrung zeigt, dass gute Ziele schlechte Systeme nicht automatisch verhindern. Deshalb reicht es nicht, positive Netto-Wirkung zu wollen. Die Verfahren, mit denen Wirkung gemessen und gelenkt wird, muessen selbst nach Wirkung bewertet werden.

Die Kernfrage lautet deshalb: Welche Wirkung erzeugt die Wirkungsökonomie selbst? Erhoeht sie Transparenz, Fairness und Zukunftsfaehigkeit? Oder erzeugt sie Buerokratie, Kontrolle, Datenmacht und politische Abwehr? Rang 21 macht diese Rueckfrage verbindlich.

Das Konzeptpapier ordnet diese Rueckfrage in eine Schutzlogik ein, die fuer alle weiteren Portale gilt.

## Anwendungsfelder der Kritikarchitektur

Erstes Anwendungsfeld sind Produkte und Konsum. Dort entstehen Fragen nach Labelvertrauen, Wirkungssimulation, Verbraucherinformation und Schutz vor moralischer Ueberforderung.

Zweites Anwendungsfeld sind Unternehmen. Dort entstehen Fragen nach Berichtspflichten, KMU-Tauglichkeit, Lieferkettennachweisen, Ratingmacht und Kapitalzugang.

Drittes Anwendungsfeld ist der Staat. Dort entstehen Fragen nach Wirkungspruefung, Haushalt, Foerderung, Rechtsschutz, politischer Verantwortung und demokratischer Begrenzung.

Viertes Anwendungsfeld sind Medien und Plattformen. Dort entstehen Fragen nach Wahrheit, Zensurvorwurf, Reichweite, Diskursrisiko und algorithmischer Verstaerkung.

Fuenftes Anwendungsfeld sind Datenraeume und KI. Dort entstehen Fragen nach Black-Box-Modellen, Bias, Datenzugang, Anfechtbarkeit und Modellhoheit.

## Mindeststandards fuer alle Wirkungsinstrumente

Jedes Wirkungsinstrument braucht einen Methodensteckbrief. Er muss erklaeren, welche Wirkung gemessen wird, welche Daten genutzt werden, welche Unsicherheiten bestehen, welche roten Linien gelten und wer die Methode prueft.

Jedes Wirkungsinstrument braucht einen Widerspruchsweg. Wer von einer Bewertung betroffen ist, muss verstehen koennen, wie sie zustande kam und wie sie korrigiert werden kann.

Jedes Wirkungsinstrument braucht eine Evaluationspflicht. Wirkungsmessung ist nicht mit der Einfuehrung abgeschlossen. Sie beginnt dort erst als lernendes System.

Jedes Wirkungsinstrument braucht eine Kommunikationsfassung. Menschen muessen verstehen koennen, dass es nicht um Gehorsam, sondern um bessere Rueckkopplung geht.

## Warum dieser Rang vor der Skalierung sichtbar sein muss

Rang 21 sollte nicht erst spaet ergaenzt werden. Er muss sichtbar sein, bevor starke Instrumente wie Wirkungssteuer, Wirkungseinkommen, Kapitalwirkung oder kommunale Wirkungshaushalte skaliert werden.

Der Grund ist einfach: Akzeptanz entsteht nicht durch nachtraegliche Versicherung, dass alles gut gemeint sei. Akzeptanz entsteht, wenn Schutzgrenzen, Widerspruchsrechte und Korrekturwege von Anfang an sichtbar sind.

Gerade bei digitalen Tools ist die Reihenfolge entscheidend. Ein Wirkungsscanner ohne Social-Credit-Abgrenzung wird anders gelesen als ein Wirkungsscanner, der seine roten Linien offen zeigt.

Rang 21 ist damit nicht defensiv, sondern vorauslaufende Legitimation.

## Vertiefender Pruefrahmen

Das Konzeptpapier definiert einen Pruefrahmen mit fuenf Ebenen. Ebene 1 ist die begriffliche Ebene: Wirkung, Wirkungspotenzial, Wirkungsrisiko und Wirkungssimulation duerfen nicht vermischt werden. Ebene 2 ist die methodische Ebene: Datenqualitaet, Unsicherheit, Benchmark, Gegenpruefung und Nichtkompensation muessen offenliegen.

Ebene 3 ist die rechtliche Ebene: Datenschutz, Rechtsschutz, Verhaeltnismaessigkeit, Widerspruch und gerichtliche Pruefbarkeit. Ebene 4 ist die demokratische Ebene: Beteiligung, politische Entscheidung, Wirkungsrat, oeffentliche Konsultation und parlamentarische Verantwortung. Ebene 5 ist die kommunikative Ebene: Missverstaendnisse, Frames, FAQ und Akzeptanz.

Jede konkrete Anwendung der WÖk muss diese fuenf Ebenen durchlaufen, bevor sie oeffentlich als Tool, Steuerungsmodell, Scorecard, Foerderlogik oder Website-Fachseite eingesetzt wird.

Damit wird Rang 21 zur Querschnittsqualitaetssicherung der Wirkungsökonomie.

## Quellen

Quellenrahmen: Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XVII, Kapitel 101 bis 106.; Natalie Weber: Grundlagenpapier Wirkungsökonomie WÖk, 2025, Abschnitte Umsetzung, Transformation, Narrative, Change-Management und Akzeptanz.; Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.; United Nations: Transforming our world: The 2030 Agenda for Sustainable Development, https://sdgs.un.org/2030agenda.; European Commission: AI Act and guidelines on prohibited AI practices, https://digital-strategy.ec.europa.eu/.; European Commission: Digital Services Act, https://digital-strategy.ec.europa.eu/.; European Commission: Better regulation guidelines and toolbox, https://commission.europa.eu/.; OECD: Recommendation of the Council on Regulatory Policy and Governance, 2012, https://legalinstruments.oecd.org/.; NIST: Artificial Intelligence Risk Management Framework, https://www.nist.gov/itl/ai-risk-management-framework.; Council of Europe: Framework Convention on Artificial Intelligence and human rights, democracy and the rule of law, https://www.coe.int/.

## Glossar

Wirkung: Tatsaechliche Veraenderung von Zustaenden. Wirkung ist neutral und relational.

Wirkungspotenzial: Moeglichkeit, dass Wirkung eintreten kann. Noch keine eingetretene Wirkung.

Wirkungsrisiko: Moeglichkeit negativer oder destabilisierender Wirkung.

Positive Netto-Wirkung: Zielgroesse der WÖk: tragfaehige Wirkung fuer Mensch, Planet und Demokratie nach Beruecksichtigung roter Linien.

SDG+: Transparente WÖk-Erweiterung fuer Demokratie, Medienqualitaet, Rechtsstaatlichkeit, Diskursfaehigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

Wirkungssimulation: Darstellung guter Wirkung ohne belastbare Zustandsveraenderung, Datenqualitaet oder Rueckkopplung.

Social-Credit-Rote-Linie: Verbot, Wirkungslogik in allgemeine Personenbewertung, Gehorsamsmessung oder Zugangsbeschraenkung zu verwandeln.