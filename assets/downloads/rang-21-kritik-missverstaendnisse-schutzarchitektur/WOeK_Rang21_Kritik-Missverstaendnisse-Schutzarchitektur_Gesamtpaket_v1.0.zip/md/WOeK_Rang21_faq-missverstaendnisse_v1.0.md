# FAQ Rang 21 - Missverständnisse und Gegenframes

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: FAQ

## Ist die WÖk Social Credit?

Nein. Sie darf keine Menschen als Personen bewerten. Sie bewertet Wirkung von Produkten, Organisationen, Strukturen, Kapitalfluessen, Regeln und oeffentlichen Entscheidungen.

## Ist die WÖk Planwirtschaft?

Nein. Sie ersetzt keine dezentralen Marktentscheidungen durch zentrale Produktionsplanung. Sie verbessert den Informationsgehalt von Preisen, Steuern, Kapitalzugang und Beschaffung.

## Sind die SDGs eine Weltregierung?

Nein. Die SDGs sind ein global verhandelter Zielrahmen. Die WÖk nutzt sie als Referenzrahmen, nicht als Herrschaftsinstrument.

## Wer entscheidet, was wirkt?

Nicht eine einzelne Instanz. Wirkungsmessung braucht offene Methoden, Datenqualitaetsklassen, wissenschaftliche Pruefung, demokratische Entscheidung, Rechtsschutz und Revision.

## Was passiert bei Unsicherheit?

Unsicherheit wird markiert. Bewertungen brauchen Revisionsdatum, Datenqualitaetsklasse und Korrekturschleife.