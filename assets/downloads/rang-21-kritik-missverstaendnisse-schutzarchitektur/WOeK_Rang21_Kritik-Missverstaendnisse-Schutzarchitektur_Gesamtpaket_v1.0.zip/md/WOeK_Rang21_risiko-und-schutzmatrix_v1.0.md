# Risiko- und Schutzmatrix Rang 21

Autorin: Natalie Weber
Referenz: Wirkungsoekonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf fuer Website, Akademie, Downloads und politische Anschlussfaehigkeit
Dokumenttyp: Schutzmatrix

## Technokratie

Gegenmassnahmen: demokratische Entscheidung, oeffentliche Methoden, Betroffenenbeteiligung, Rechtsschutz, unabhaengige Pruefung und Verhaeltnismaessigkeit.

## Social Credit

Gegenmassnahmen: Verbot allgemeiner Personenbewertung, Zweckbindung, Datensparsamkeit, keine Zugangssperren und keine politischen Loyalitaetsscores.

## Wirkungssimulation

Gegenmassnahmen: Datenqualitaetsklassen, Audit, Reverse Merit Order, Sanktion bei falschen Behauptungen und oeffentliche Korrekturlogs.

## Planwirtschaftsframe

Gegenmassnahmen: klare Abgrenzung zu zentraler Ergebnisplanung, Betonung dezentraler Suchprozesse, KMU-Schutz und Innovationsfenster.

## Fehlbarkeit

Gegenmassnahmen: Unsicherheitsklassen, Pilotierung, Evaluation, Revisionsdatum, offene Zielkonflikte und wissenschaftliche Gegenpruefung.