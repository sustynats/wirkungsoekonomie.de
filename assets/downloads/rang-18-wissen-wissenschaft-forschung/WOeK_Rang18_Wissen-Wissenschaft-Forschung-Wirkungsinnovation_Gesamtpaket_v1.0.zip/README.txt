WOeK Rang 18 - Wissen, Wissenschaft, Forschung und Wirkungsinnovation
Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

Enthalten:
- PDF-Dateien
- DOCX-Dateien
- Markdown-Quelltexte
- HTML-Onlinefassungen
- JSON-Indexdateien
- Toolkarten
- CodeX-Website-Anweisung
- Gesamtpaket-PDF und Gesamtpaket-DOCX
