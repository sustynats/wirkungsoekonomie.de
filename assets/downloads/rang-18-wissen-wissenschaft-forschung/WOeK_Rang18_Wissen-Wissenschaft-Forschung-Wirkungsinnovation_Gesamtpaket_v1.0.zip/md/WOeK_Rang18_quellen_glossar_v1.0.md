# Quellen und Glossarlinks Rang 18

## Interne und externe Anschlussstellen

Autorin: Natalie Weber  
Referenz: Wirkungsökonomie  
Version: 1.0  
Stand: Mai 2026  
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Inhaltsverzeichnis

1. Einordnung

2. Führende Begriffslogik

3. Warum dieser Bereich wichtig ist

4. Quellenrahmen

5. Interne WÖk-Referenz

6. Interne WÖk-Referenz

7. UNESCO

8. CoARA

9. DORA

10. OECD

11. Europäische Kommission

12. Europäische Kommission

13. Glossar: Wirkung

14. Glossar: Positive Netto-Wirkung

15. Glossar: Wirkungswissen

16. Glossar: Wissensintegrität

17. Glossar: Wissenschafts-Wirkungsindikatoren

18. Glossar: Wissensrat

19. Glossar: Wirkungsinnovation

20. Glossar: Science for Policy

## 1. Einordnung

Quellen und Glossarlinks Rang 18 gehört zu Rang 18 der Wirkungsökonomie. Der Bereich verbindet Wissenschaft, Forschung, öffentliche Wahrheit, Innovationspolitik, Datenqualität und Rechtsschutz. Er schließt an Rang 17 an: Digitale Infrastrukturen machen Wirkung sichtbar, aber erst Wissenschaft, Statistik, offene Daten, Integrität und Rechtsprechung sichern, dass diese Sichtbarkeit nicht beliebig, manipulierbar oder technokratisch wird.

## 2. Führende Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird sie am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Logik gilt auch für Wissenschaft und Innovation: Nicht jede Forschung wirkt sofort positiv, nicht jede Innovation ist Fortschritt, nicht jede Datenlage ist Wahrheit. Entscheidend ist die nachprüfbare Zustandsveränderung und ihre Rückkopplung in Entscheidung, Lernen und Korrektur.

## 3. Warum dieser Bereich wichtig ist

Ohne verlässliches Wissen kann Wirkung nicht bewertet werden. Ohne Datenqualität kann keine WÖk-ID stabil sein. Ohne Replikation wird Forschung anfällig für Scheingenauigkeit. Ohne unabhängige Statistik verliert Politik ihre Wirklichkeitsbindung. Ohne Wissenschaftsfreiheit wird Forschung gefällig. Ohne Rechtsschutz kann Wirkungssteuerung technokratisch werden. Rang 18 ist deshalb die epistemische Sicherungsschicht der Wirkungsökonomie.

## 4. Quellenrahmen

Die Quellen dienen der Anschlussfähigkeit. Sie ersetzen keine vollständige wissenschaftliche Literaturarbeit, markieren aber die Leitlinien für Website, Akademie und Downloadbibliothek.

## 5. Interne WÖk-Referenz

Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

## 6. Interne WÖk-Referenz

Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

## 7. UNESCO

UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

## 8. CoARA

Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

## 9. DORA

San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

## 10. OECD

Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

## 11. Europäische Kommission

EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

## 12. Europäische Kommission

Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.

## 13. Glossar: Wirkung

Tatsächliche Veränderung von Zuständen. Wirkung ist neutral und relational und kann positiv, negativ oder neutral sein.

## 14. Glossar: Positive Netto-Wirkung

Zielgröße der Wirkungsökonomie: systemisch tragfähige Wirkung für Mensch, Planet und Demokratie nach Einbezug negativer Wirkungen und Wirkungsgrenzen.

## 15. Glossar: Wirkungswissen

Wissen, das nicht nur erklärt, sondern Zustandsveränderungen, Nebenwirkungen, Unsicherheiten und Korrekturpfade sichtbar macht.

## 16. Glossar: Wissensintegrität

Verlässlichkeit von Methoden, Daten, Reproduzierbarkeit, Interessenoffenlegung und Korrekturbereitschaft.

## 17. Glossar: Wissenschafts-Wirkungsindikatoren

Indikatoren, die Forschungsqualität, Offenheit, Replikation, gesellschaftliche Anschlussfähigkeit und Transformationsbeitrag sichtbar machen.

## 18. Glossar: Wissensrat

Vorgeschlagene unabhängige Institution zur Sicherung wissenschaftlicher Integrität, Reproduzierbarkeit, Open-Science-Standards und Schutz vor Einflussnahme.

## 19. Glossar: Wirkungsinnovation

Innovation, die nicht primär Kapitalrendite, sondern positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugt.

## 20. Glossar: Science for Policy

Strukturierte Übersetzung von Forschung, Statistik und Unsicherheit in demokratische Entscheidungsprozesse.

## Quellen und Referenzrahmen

- Interne WÖk-Referenz: Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

- Interne WÖk-Referenz: Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

- UNESCO: UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

- CoARA: Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

- DORA: San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

- OECD: Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

- Europäische Kommission: EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

- Europäische Kommission: Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.