# Wirkungsindikatoren Rang 18

## WÖk-IDs, Scorecards und Bewertungslogik für Wissen, Wissenschaft und Wirkungsinnovation

Autorin: Natalie Weber  
Referenz: Wirkungsökonomie  
Version: 1.0  
Stand: Mai 2026  
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Inhaltsverzeichnis

1. Einordnung

2. Führende Begriffslogik

3. Warum dieser Bereich wichtig ist

4. Indikatorenlogik

5. WOK-KNOW-101 - Open-Science-Anteil

6. WOK-KNOW-102 - Replikationsfähigkeit

7. WOK-KNOW-103 - Interessenkonflikt-Transparenz

8. WOK-KNOW-104 - Forschungsdatenqualität

9. WOK-KNOW-105 - Science-for-Policy-Qualität

10. WOK-KNOW-106 - Wirkungsinnovationsbeitrag

11. WOK-KNOW-107 - Wissenschaftsvertrauen

12. WOK-KNOW-108 - Rechtsschutzfähigkeit

## 1. Einordnung

Wirkungsindikatoren Rang 18 gehört zu Rang 18 der Wirkungsökonomie. Der Bereich verbindet Wissenschaft, Forschung, öffentliche Wahrheit, Innovationspolitik, Datenqualität und Rechtsschutz. Er schließt an Rang 17 an: Digitale Infrastrukturen machen Wirkung sichtbar, aber erst Wissenschaft, Statistik, offene Daten, Integrität und Rechtsprechung sichern, dass diese Sichtbarkeit nicht beliebig, manipulierbar oder technokratisch wird.

## 2. Führende Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird sie am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Logik gilt auch für Wissenschaft und Innovation: Nicht jede Forschung wirkt sofort positiv, nicht jede Innovation ist Fortschritt, nicht jede Datenlage ist Wahrheit. Entscheidend ist die nachprüfbare Zustandsveränderung und ihre Rückkopplung in Entscheidung, Lernen und Korrektur.

## 3. Warum dieser Bereich wichtig ist

Ohne verlässliches Wissen kann Wirkung nicht bewertet werden. Ohne Datenqualität kann keine WÖk-ID stabil sein. Ohne Replikation wird Forschung anfällig für Scheingenauigkeit. Ohne unabhängige Statistik verliert Politik ihre Wirklichkeitsbindung. Ohne Wissenschaftsfreiheit wird Forschung gefällig. Ohne Rechtsschutz kann Wirkungssteuerung technokratisch werden. Rang 18 ist deshalb die epistemische Sicherungsschicht der Wirkungsökonomie.

## 4. Indikatorenlogik

Die Indikatoren für Rang 18 bewerten nicht Personen und nicht Gesinnung, sondern Strukturen, Methoden, Datenqualität, Offenheit, Korrekturfähigkeit und Wirkungspfade. Sie dienen als Lerninstrument für Forschung, Förderung, Wissenschaftskommunikation und öffentliche Entscheidung.

## 5. WOK-KNOW-101 - Open-Science-Anteil

Anteil öffentlich finanzierter Forschung mit Open Access, offenen Methoden oder offenen Daten, soweit Schutzgründe nicht entgegenstehen. Bewertung: -3 bis +3 je nach Datenqualität, Wirkung, Schutzgrenzen und Korrekturfähigkeit.

## 6. WOK-KNOW-102 - Replikationsfähigkeit

Anteil zentraler Ergebnisse mit dokumentierten Daten, Methoden, Code oder Replikationsprüfung. Bewertung: -3 bis +3 je nach Datenqualität, Wirkung, Schutzgrenzen und Korrekturfähigkeit.

## 7. WOK-KNOW-103 - Interessenkonflikt-Transparenz

Offenlegung von Drittmitteln, Lobbybeziehungen, finanziellen Interessen und institutionellen Abhängigkeiten. Bewertung: -3 bis +3 je nach Datenqualität, Wirkung, Schutzgrenzen und Korrekturfähigkeit.

## 8. WOK-KNOW-104 - Forschungsdatenqualität

Datenherkunft, Aktualität, Vollständigkeit, Unsicherheitsklasse, Audit-Trail und Versionierung. Bewertung: -3 bis +3 je nach Datenqualität, Wirkung, Schutzgrenzen und Korrekturfähigkeit.

## 9. WOK-KNOW-105 - Science-for-Policy-Qualität

Trennung von Evidenz, Unsicherheit, normativer Bewertung und politischer Empfehlung. Bewertung: -3 bis +3 je nach Datenqualität, Wirkung, Schutzgrenzen und Korrekturfähigkeit.

## 10. WOK-KNOW-106 - Wirkungsinnovationsbeitrag

Beitrag eines Projekts zu messbaren Zustandsveränderungen in Mensch, Planet und Demokratie. Bewertung: -3 bis +3 je nach Datenqualität, Wirkung, Schutzgrenzen und Korrekturfähigkeit.

## 11. WOK-KNOW-107 - Wissenschaftsvertrauen

Öffentliche Verständlichkeit, Quellenklarheit, Korrekturbereitschaft und Transparenz. Bewertung: -3 bis +3 je nach Datenqualität, Wirkung, Schutzgrenzen und Korrekturfähigkeit.

## 12. WOK-KNOW-108 - Rechtsschutzfähigkeit

Begründbarkeit und Überprüfbarkeit von Bewertungen, Förderentscheidungen und Wirkungsklassifikationen. Bewertung: -3 bis +3 je nach Datenqualität, Wirkung, Schutzgrenzen und Korrekturfähigkeit.

## Quellen und Referenzrahmen

- Interne WÖk-Referenz: Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

- Interne WÖk-Referenz: Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

- UNESCO: UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

- CoARA: Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

- DORA: San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

- OECD: Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

- Europäische Kommission: EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

- Europäische Kommission: Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.