# Politische Anschlussfähigkeit Rang 18

## Umsetzungsoptionen für Wissenschaft, Forschung und Wirkungsinnovation

Autorin: Natalie Weber  
Referenz: Wirkungsökonomie  
Version: 1.0  
Stand: Mai 2026  
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Inhaltsverzeichnis

1. Einordnung

2. Führende Begriffslogik

3. Warum dieser Bereich wichtig ist

4. Aufgabe der Politik

5. Politische Rahmenbedingungen

6. Ausgestaltungsspielraum

7. Zielkonflikte

8. Rollenverteilung

9. Übergang und Schutz

10. Evaluation und Korrektur

11. Schutz vor Technokratie

12. Pflichtsatz

## 1. Einordnung

Politische Anschlussfähigkeit Rang 18 gehört zu Rang 18 der Wirkungsökonomie. Der Bereich verbindet Wissenschaft, Forschung, öffentliche Wahrheit, Innovationspolitik, Datenqualität und Rechtsschutz. Er schließt an Rang 17 an: Digitale Infrastrukturen machen Wirkung sichtbar, aber erst Wissenschaft, Statistik, offene Daten, Integrität und Rechtsprechung sichern, dass diese Sichtbarkeit nicht beliebig, manipulierbar oder technokratisch wird.

## 2. Führende Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird sie am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Logik gilt auch für Wissenschaft und Innovation: Nicht jede Forschung wirkt sofort positiv, nicht jede Innovation ist Fortschritt, nicht jede Datenlage ist Wahrheit. Entscheidend ist die nachprüfbare Zustandsveränderung und ihre Rückkopplung in Entscheidung, Lernen und Korrektur.

## 3. Warum dieser Bereich wichtig ist

Ohne verlässliches Wissen kann Wirkung nicht bewertet werden. Ohne Datenqualität kann keine WÖk-ID stabil sein. Ohne Replikation wird Forschung anfällig für Scheingenauigkeit. Ohne unabhängige Statistik verliert Politik ihre Wirklichkeitsbindung. Ohne Wissenschaftsfreiheit wird Forschung gefällig. Ohne Rechtsschutz kann Wirkungssteuerung technokratisch werden. Rang 18 ist deshalb die epistemische Sicherungsschicht der Wirkungsökonomie.

## 4. Aufgabe der Politik

Politik muss Wissenschaftsfreiheit schützen, Forschungsdaten zugänglich machen, Integrität sichern, öffentliche Statistik stärken und Forschung so fördern, dass Wissen in positive Netto-Wirkung übersetzt werden kann.

## 5. Politische Rahmenbedingungen

Erforderlich sind Open-Science-Regeln, Forschungsintegritätsstellen, Reformen der Forschungsbewertung, Replikationsfonds, faire Förderlogiken, Schutz vor Lobbyeinfluss, unabhängige Statistik und transparente Science-for-Policy-Prozesse.

## 6. Ausgestaltungsspielraum

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Parteien können unterschiedliche Schwerpunkte setzen: Grundlagenforschung, missionsorientierte Forschung, Transfer, Open Science, Hochschulfinanzierung, Forschungsinfrastrukturen oder Innovationsfonds.

## 7. Zielkonflikte

Wissenschaftsfreiheit vs. Missionsorientierung, Open Data vs. Datenschutz, schnelle Innovation vs. Sicherheit, Transfer vs. Unabhängigkeit, Exzellenz vs. Breitenzugang, globale Offenheit vs. Forschungssicherheit.

## 8. Rollenverteilung

Bund und Länder sichern Finanzierung, Recht und Infrastrukturen. Wissenschaft prüft Wirklichkeit. Gerichte schützen Rechtsschutz. Verwaltung nutzt Evidenz. Unternehmen und Zivilgesellschaft bringen Praxiswissen ein, ohne Wissenschaft zu vereinnahmen.

## 9. Übergang und Schutz

Einführung über Pilotprogramme, freiwillige Scorecards, unabhängige Evaluierung, Datenschutz, Ethik, Einspruchsrechte und Schutz wissenschaftlicher Minderheitenpositionen.

## 10. Evaluation und Korrektur

Alle Instrumente müssen regelmäßig auf Wirkung, Fehlanreize, Bürokratie, Exklusion, Machtkonzentration und Methodenqualität geprüft werden.

## 11. Schutz vor Technokratie

Wissenschaft ersetzt keine Demokratie. Sie macht Wirklichkeit, Unsicherheit und Folgen prüfbar. Politische Entscheidungen bleiben demokratische Entscheidungen.

## 12. Pflichtsatz

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext, sondern einen Bewertungs- und Steuerungsrahmen. Parteien behalten Ausgestaltungsspielraum. Entscheidend ist die überprüfbare Wirkung auf Mensch, Planet und Demokratie.

## Quellen und Referenzrahmen

- Interne WÖk-Referenz: Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

- Interne WÖk-Referenz: Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

- UNESCO: UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

- CoARA: Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

- DORA: San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

- OECD: Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

- Europäische Kommission: EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

- Europäische Kommission: Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.