# Gesamtdossier Rang 18 - Wissen, Wissenschaft, Forschung und Wirkungsinnovation

## Die Wissensordnung der Wirkungsökonomie

Autorin: Natalie Weber  
Referenz: Wirkungsökonomie  
Version: 1.0  
Stand: Mai 2026  
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Inhaltsverzeichnis

1. Einordnung

2. Führende Begriffslogik

3. Warum dieser Bereich wichtig ist

4. Executive Summary

5. Die Maßstabskrise des Wissens

6. Wissenschaft als demokratische Infrastruktur

7. Forschung als Wirkungswissen

8. Innovation als evolutionäres Systemlernen

9. Wissensrat

10. Rechtsprechung

11. Umsetzungspfad

12. Detailkonzept 01: Wissenschaft als Wirklichkeitsprüfung

13. Detailkonzept 02: Wissensrat und wissenschaftliche Integrität

14. Detailkonzept 03: Open Science und öffentliche Wissensinfrastruktur

15. Detailkonzept 04: Forschungsbewertung und Wissenschafts-Wirkungsindikatoren

16. Detailkonzept 05: Mission-oriented Research und Wirkungsinnovation

17. Detailkonzept 06: Transdisziplinarität und Citizen Science

18. Detailkonzept 07: Science for Policy und öffentliche Statistik

19. Detailkonzept 08: Forschungsdaten, Replikation und Qualitätssicherung

20. Detailkonzept 09: Rechtsprechung, Sachverständige und Wirkungsrecht

21. Detailkonzept 10: Wirkungskompetenz-Akademie und Wissensbildung

22. Toolkarte: Wissenschafts-Wirkungsindikator-Set

23. Toolkarte: Forschungs-Scorecard

24. Toolkarte: Wissensintegritäts-Check

25. Toolkarte: Mission-Impact-Radar

26. Toolkarte: Science-for-Policy-Kompass

27. Toolkarte: Replikations- und Datenqualitätsmonitor

28. Toolkarte: Wirkungsinnovations-Portfolio

29. Politische Anschlussfähigkeit - Aufgabe der Politik

30. Politische Anschlussfähigkeit - Politische Rahmenbedingungen

31. Politische Anschlussfähigkeit - Ausgestaltungsspielraum

32. Politische Anschlussfähigkeit - Zielkonflikte

33. Politische Anschlussfähigkeit - Rollenverteilung

34. Politische Anschlussfähigkeit - Übergang und Schutz

35. Politische Anschlussfähigkeit - Evaluation und Korrektur

36. Politische Anschlussfähigkeit - Schutz vor Technokratie

37. SDG 4 - Hochwertige Bildung

38. SDG 5 - Geschlechtergleichstellung

39. SDG 8 - Menschenwürdige Arbeit

40. SDG 9 - Industrie, Innovation und Infrastruktur

41. SDG 10 - Weniger Ungleichheiten

42. SDG 13 - Klimaschutz

43. SDG 16 - Frieden, Gerechtigkeit und starke Institutionen

44. SDG 17 - Partnerschaften

## 1. Einordnung

Gesamtdossier Wissen, Wissenschaft, Forschung und Wirkungsinnovation gehört zu Rang 18 der Wirkungsökonomie. Der Bereich verbindet Wissenschaft, Forschung, öffentliche Wahrheit, Innovationspolitik, Datenqualität und Rechtsschutz. Er schließt an Rang 17 an: Digitale Infrastrukturen machen Wirkung sichtbar, aber erst Wissenschaft, Statistik, offene Daten, Integrität und Rechtsprechung sichern, dass diese Sichtbarkeit nicht beliebig, manipulierbar oder technokratisch wird.

## 2. Führende Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird sie am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Logik gilt auch für Wissenschaft und Innovation: Nicht jede Forschung wirkt sofort positiv, nicht jede Innovation ist Fortschritt, nicht jede Datenlage ist Wahrheit. Entscheidend ist die nachprüfbare Zustandsveränderung und ihre Rückkopplung in Entscheidung, Lernen und Korrektur.

## 3. Warum dieser Bereich wichtig ist

Ohne verlässliches Wissen kann Wirkung nicht bewertet werden. Ohne Datenqualität kann keine WÖk-ID stabil sein. Ohne Replikation wird Forschung anfällig für Scheingenauigkeit. Ohne unabhängige Statistik verliert Politik ihre Wirklichkeitsbindung. Ohne Wissenschaftsfreiheit wird Forschung gefällig. Ohne Rechtsschutz kann Wirkungssteuerung technokratisch werden. Rang 18 ist deshalb die epistemische Sicherungsschicht der Wirkungsökonomie.

## 4. Executive Summary

Das Gesamtdossier zeigt Rang 18 als epistemische, institutionelle und rechtliche Sicherungsschicht der Wirkungsökonomie. Es verbindet Wissenschaftsfreiheit, Forschungsintegrität, Open Science, Forschungsbewertung, Wirkungsinnovation, öffentliche Statistik, Rechtsprechung und Wirkungskompetenz zu einer lernenden Architektur.

## 5. Die Maßstabskrise des Wissens

Auch Wissenschaft und Innovation können am falschen Maßstab hängen. Wenn Zitationen, Rankings, Drittmittel, Patente oder Start-up-Bewertungen dominieren, wird Aktivität sichtbar, aber nicht zwingend Wirkung. Die Wirkungsökonomie fragt daher: Welche Erkenntnisse verbessern Zustände? Welche Daten sind belastbar? Welche Unsicherheiten bleiben? Welche Korrekturmechanismen bestehen? Welche Innovationen stärken Mensch, Planet und Demokratie?

## 6. Wissenschaft als demokratische Infrastruktur

Wissenschaft ist eine Schicht öffentlicher Wahrheit. Sie entscheidet nicht anstelle von Demokratie, aber sie schützt Demokratie vor Wirklichkeitsverlust. Gerichte, Parlamente, Verwaltungen, Medien, Unternehmen und Bürger:innen brauchen belastbare Forschung, Statistik und Expertise, um Entscheidungen nicht auf bloße Behauptungen zu stützen.

## 7. Forschung als Wirkungswissen

Wirkungswissen unterscheidet Beschreibung, Modell, Kausalannahme, Unsicherheit, normative Bewertung und politische Schlussfolgerung. Diese Trennung ist zentral. Wenn wissenschaftliche Unsicherheit als Beliebigkeit missbraucht wird, schwächt das Demokratie. Wenn politische Bewertung als wissenschaftliche Gewissheit verkauft wird, schwächt das ebenfalls Demokratie.

## 8. Innovation als evolutionäres Systemlernen

Innovation ist nicht automatisch gut. Eine Technologie kann nützlich, schädlich oder ambivalent wirken. Wirkungsinnovation braucht daher Scorecards, Reallabore, Sicherheitsgrenzen, T-SROI, Verteilungsanalyse, Datenqualität, Ethik, Rechtsschutz und Evaluation. Der Maßstab ist nicht Neuheit, sondern positive Netto-Wirkung.

## 9. Wissensrat

Der Wissensrat ist die vorgeschlagene Institution zur Sicherung wissenschaftlicher Integrität. Er überwacht nicht Meinungen, sondern Methoden, Reproduzierbarkeit, Interessenkonflikte, Open-Science-Standards, Modelltransparenz, Forschungsethik und Schutz vor politischer oder wirtschaftlicher Vereinnahmung.

## 10. Rechtsprechung

Die Justiz ist Freiheitsgarantie der Wirkungsökonomie. Sobald Wirkungsbewertungen reale Folgen für Steuern, Förderungen, Beschaffung, Kapitalzugang oder Marktzugang haben, braucht es Einspruch, Begründung, Prüfung, Sachverständige, Verhältnismäßigkeit und gerichtliche Kontrolle.

## 11. Umsetzungspfad

Rang 18 wird über Pilotprogramme eingeführt: Forschungs-Scorecards, offene Datenräume, Replikationsfonds, Wissenschafts-Wirkungsberichte, Science-for-Policy-Standards, unabhängige Statistik-Sicherung, Wirkungskompetenz-Akademie und öffentliche Toolkarten.

## 12. Detailkonzept 01: Wissenschaft als Wirklichkeitsprüfung

Warum Wissenschaft in der Wirkungsökonomie keine Autoritätsherrschaft ist, sondern ein Korrektursystem für Wirklichkeit, Unsicherheit und demokratische Entscheidungen. Kernbausteine: Wissenschaftsfreiheit, Wirklichkeitsprüfung, Unsicherheit, Öffentliche Wahrheit, Demokratische Korrektur.

## 13. Detailkonzept 02: Wissensrat und wissenschaftliche Integrität

Institutionelle Sicherung gegen Manipulation, Lobbyeinfluss, politisierte Forschung, methodische Schwäche und Wirkungssimulation. Kernbausteine: Wissensrat, Integrität, Interessenregister, Reproduzierbarkeit, Open Science.

## 14. Detailkonzept 03: Open Science und öffentliche Wissensinfrastruktur

Open Access, Open Data, Citizen Science und faire Wissenszugänge als öffentliche Infrastruktur der Wirkungsökonomie. Kernbausteine: Open Access, Open Data, Citizen Science, Wissensgerechtigkeit, Datenräume.

## 15. Detailkonzept 04: Forschungsbewertung und Wissenschafts-Wirkungsindikatoren

Wie Forschung jenseits von Publikationszahlen, Impact Factor und Zitationen wirkungsorientiert, aber nicht technokratisch bewertet werden kann. Kernbausteine: CoARA, DORA, Wissenschafts-Wirkungsindikatoren, Forschungs-Scorecard, Qualität.

## 16. Detailkonzept 05: Mission-oriented Research und Wirkungsinnovation

Missionen als Richtung, nicht als Mikromanagement: Forschung, Technologie, Regulierung und Praxis auf messbare gesellschaftliche Zustandsveränderungen ausrichten. Kernbausteine: Missionen, Wirkungsinnovation, Portfolios, T-SROI, Zukunftsfonds.

## 17. Detailkonzept 06: Transdisziplinarität und Citizen Science

Gesellschaftliche Akteure als Co-Forschende, ohne methodische Standards zu verwässern. Kernbausteine: Transdisziplinarität, Praxiswissen, Co-Forschung, Beteiligung, Konfliktwissen.

## 18. Detailkonzept 07: Science for Policy und öffentliche Statistik

Wie Parlamente, Verwaltung und Öffentlichkeit Evidenz nutzen können, ohne Wissenschaft zur Politikverkündung zu machen. Kernbausteine: Policy Advice, Statistik, Unsicherheitsklassen, Evidenzampel, Demokratie.

## 19. Detailkonzept 08: Forschungsdaten, Replikation und Qualitätssicherung

Datenqualität, Replikation, Audit-Trails, negative Ergebnisse und Unsicherheitsklassen als Rückgrat verlässlicher Wirkungssteuerung. Kernbausteine: Replikation, Datenqualität, Audit-Trail, Methodentransparenz, Qualitätssicherung.

## 20. Detailkonzept 09: Rechtsprechung, Sachverständige und Wirkungsrecht

Justiz als Freiheitsgarantie, Korrekturinstanz und Schutz vor technokratischer Wirkungssteuerung. Kernbausteine: Rechtsschutz, Sachverständige, Verhältnismäßigkeit, Wirkungsrecht, Grundrechte.

## 21. Detailkonzept 10: Wirkungskompetenz-Akademie und Wissensbildung

Wirkungskompetenz als Querschnittskompetenz für Wissenschaft, Verwaltung, Unternehmen, Medien, Schulen und Bürger:innen. Kernbausteine: Wirkungskompetenz, Akademie, Weiterbildung, Wissenschaftskommunikation, Lernende Gesellschaft.

## 22. Toolkarte: Wissenschafts-Wirkungsindikator-Set

Bewertet Forschungsprojekte nach Qualität, Offenheit, Replikationsfähigkeit, gesellschaftlicher Anschlussfähigkeit, Transformationspfad und Risiken. Zielgruppe: Forschungseinrichtungen, Fördergeber, Ministerien. Status: Demo in Vorbereitung. Link: /tools/wissenschafts-wirkungsindikatoren/

## 23. Toolkarte: Forschungs-Scorecard

Macht Wirkungspfad, Datenqualität, Zielkonflikte, Nebenwirkungen und Umsetzungsreife eines Forschungsprojekts sichtbar. Zielgruppe: Hochschulen, Förderprogramme, Innovationsagenturen. Status: Demo in Vorbereitung. Link: /tools/forschungs-scorecard/

## 24. Toolkarte: Wissensintegritäts-Check

Prüft Interessenkonflikte, Datenherkunft, Reproduzierbarkeit, Open-Science-Anteil, methodische Transparenz und Korrekturmechanismen. Zielgruppe: Wissensrat, Forschungseinrichtungen, Redaktionen, Verwaltung. Status: Demo in Vorbereitung. Link: /tools/wissensintegritaets-check/

## 25. Toolkarte: Mission-Impact-Radar

Übersetzt Missionen in messbare Wirkungspfade, Zwischenziele, Portfolio-Risiken und Lernschleifen. Zielgruppe: Politik, Kommunen, Forschungscluster, Innovationsfonds. Status: Demo in Vorbereitung. Link: /tools/mission-impact-radar/

## 26. Toolkarte: Science-for-Policy-Kompass

Hilft Ministerien und Parlamenten, Evidenz, Unsicherheit, Zielkonflikte und normative Bewertung sauber zu trennen. Zielgruppe: Politik, Verwaltung, Wissenschaftskommunikation. Status: Demo in Vorbereitung. Link: /tools/science-for-policy-kompass/

## 27. Toolkarte: Replikations- und Datenqualitätsmonitor

Erfasst Replikationsstatus, Datenqualität, Unsicherheitsklassen, Audit-Trails und offene Materialien. Zielgruppe: Forschung, Prüfstellen, Fördergeber. Status: Demo in Vorbereitung. Link: /tools/replikations-datenqualitaetsmonitor/

## 28. Toolkarte: Wirkungsinnovations-Portfolio

Bewertet Innovationsportfolios nach Wirkung, Risiko, Reifegrad, Diffusionspotenzial, Gerechtigkeit und Resilienz. Zielgruppe: Wirkungsfonds, Unternehmen, Kommunen. Status: Demo in Vorbereitung. Link: /tools/wirkungsinnovations-portfolio/

## 29. Politische Anschlussfähigkeit - Aufgabe der Politik

Politik muss Wissenschaftsfreiheit schützen, Forschungsdaten zugänglich machen, Integrität sichern, öffentliche Statistik stärken und Forschung so fördern, dass Wissen in positive Netto-Wirkung übersetzt werden kann.

## 30. Politische Anschlussfähigkeit - Politische Rahmenbedingungen

Erforderlich sind Open-Science-Regeln, Forschungsintegritätsstellen, Reformen der Forschungsbewertung, Replikationsfonds, faire Förderlogiken, Schutz vor Lobbyeinfluss, unabhängige Statistik und transparente Science-for-Policy-Prozesse.

## 31. Politische Anschlussfähigkeit - Ausgestaltungsspielraum

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Parteien können unterschiedliche Schwerpunkte setzen: Grundlagenforschung, missionsorientierte Forschung, Transfer, Open Science, Hochschulfinanzierung, Forschungsinfrastrukturen oder Innovationsfonds.

## 32. Politische Anschlussfähigkeit - Zielkonflikte

Wissenschaftsfreiheit vs. Missionsorientierung, Open Data vs. Datenschutz, schnelle Innovation vs. Sicherheit, Transfer vs. Unabhängigkeit, Exzellenz vs. Breitenzugang, globale Offenheit vs. Forschungssicherheit.

## 33. Politische Anschlussfähigkeit - Rollenverteilung

Bund und Länder sichern Finanzierung, Recht und Infrastrukturen. Wissenschaft prüft Wirklichkeit. Gerichte schützen Rechtsschutz. Verwaltung nutzt Evidenz. Unternehmen und Zivilgesellschaft bringen Praxiswissen ein, ohne Wissenschaft zu vereinnahmen.

## 34. Politische Anschlussfähigkeit - Übergang und Schutz

Einführung über Pilotprogramme, freiwillige Scorecards, unabhängige Evaluierung, Datenschutz, Ethik, Einspruchsrechte und Schutz wissenschaftlicher Minderheitenpositionen.

## 35. Politische Anschlussfähigkeit - Evaluation und Korrektur

Alle Instrumente müssen regelmäßig auf Wirkung, Fehlanreize, Bürokratie, Exklusion, Machtkonzentration und Methodenqualität geprüft werden.

## 36. Politische Anschlussfähigkeit - Schutz vor Technokratie

Wissenschaft ersetzt keine Demokratie. Sie macht Wirklichkeit, Unsicherheit und Folgen prüfbar. Politische Entscheidungen bleiben demokratische Entscheidungen.

## 37. SDG 4 - Hochwertige Bildung

Wissenschaft und Forschung stärken Bildung, Wirkungskompetenz, kritisches Denken und lebenslanges Lernen.

## 38. SDG 5 - Geschlechtergleichstellung

Forschungszugang, Karrieren, Daten und Innovationen müssen geschlechtergerecht und diskriminierungsarm gestaltet werden.

## 39. SDG 8 - Menschenwürdige Arbeit

Wissenschaft erzeugt Zukunftsarbeit, Qualifikation und faire Transformationspfade, darf aber keine Prekarität in Forschungsstrukturen verstärken.

## 40. SDG 9 - Industrie, Innovation und Infrastruktur

Rang 18 übersetzt Forschung in wirkungsorientierte Innovation, Infrastruktur und offene Wissenssysteme.

## 41. SDG 10 - Weniger Ungleichheiten

Open Science, gerechte Datenzugänge und inklusive Forschung reduzieren Wissens- und Innovationsungleichheit.

## 42. SDG 13 - Klimaschutz

Klimaforschung, Transformationsforschung und missionsorientierte Innovation sind zentrale Hebel gegen Klimarisiken.

## 43. SDG 16 - Frieden, Gerechtigkeit und starke Institutionen

Wissenschaftliche Integrität, öffentliche Statistik, Rechtsprechung und Quellenklarheit schützen demokratische Entscheidungsfähigkeit.

## 44. SDG 17 - Partnerschaften

Forschung wirkt durch internationale Kooperation, Datenräume, transdisziplinäre Netzwerke und globale Wissenspartnerschaften.

## Quellen und Referenzrahmen

- Interne WÖk-Referenz: Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

- Interne WÖk-Referenz: Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

- UNESCO: UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

- CoARA: Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

- DORA: San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

- OECD: Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

- Europäische Kommission: EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

- Europäische Kommission: Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.