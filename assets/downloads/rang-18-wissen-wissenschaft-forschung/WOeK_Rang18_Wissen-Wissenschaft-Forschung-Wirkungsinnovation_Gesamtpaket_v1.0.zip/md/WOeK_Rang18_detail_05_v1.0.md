# Detailkonzept Mission-oriented Research und Wirkungsinnovation

## Missionen als Richtung, nicht als Mikromanagement: Forschung, Technologie, Regulierung und Praxis auf messbare gesellschaftliche Zustandsveränderungen ausrichten.

Autorin: Natalie Weber  
Referenz: Wirkungsökonomie  
Version: 1.0  
Stand: Mai 2026  
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Inhaltsverzeichnis

1. Einordnung

2. Führende Begriffslogik

3. Warum dieser Bereich wichtig ist

4. Executive Summary

5. Problemdefinition

6. Wirkungsfrage

7. Systemische Funktion

8. Daten- und Bewertungslogik

9. Beispielhafte Indikatoren

10. Beispiel 1 - kommunale Anwendung

11. Beispiel 2 - Innovationsförderung

12. Governance

13. Zielkonflikte

14. Umsetzungslogik

15. Politische Anschlussfähigkeit

16. Schutz vor Technokratie

17. Website- und Downloadlogik

18. Fokus: Missionen

19. Fokus: Wirkungsinnovation

20. Fokus: Portfolios

21. Fokus: T-SROI

22. Fokus: Zukunftsfonds

23. Fachliche Tiefenlogik

24. Wirkungsarchitektur

25. Datenquellen im Detail

26. Scorecard-Logik

27. Institutionelle Umsetzung

28. Finanzierungslogik

29. Risikomanagement

30. Beispielhafte Berechnungslogik

31. Reallabor und Pilotierung

32. Rechtliche Anschlussstellen

33. Kommunikation und Öffentlichkeit

34. Umsetzung auf der Website

35. Quellenrahmen

## 1. Einordnung

Mission-oriented Research und Wirkungsinnovation gehört zu Rang 18 der Wirkungsökonomie. Der Bereich verbindet Wissenschaft, Forschung, öffentliche Wahrheit, Innovationspolitik, Datenqualität und Rechtsschutz. Er schließt an Rang 17 an: Digitale Infrastrukturen machen Wirkung sichtbar, aber erst Wissenschaft, Statistik, offene Daten, Integrität und Rechtsprechung sichern, dass diese Sichtbarkeit nicht beliebig, manipulierbar oder technokratisch wird.

## 2. Führende Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird sie am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Logik gilt auch für Wissenschaft und Innovation: Nicht jede Forschung wirkt sofort positiv, nicht jede Innovation ist Fortschritt, nicht jede Datenlage ist Wahrheit. Entscheidend ist die nachprüfbare Zustandsveränderung und ihre Rückkopplung in Entscheidung, Lernen und Korrektur.

## 3. Warum dieser Bereich wichtig ist

Ohne verlässliches Wissen kann Wirkung nicht bewertet werden. Ohne Datenqualität kann keine WÖk-ID stabil sein. Ohne Replikation wird Forschung anfällig für Scheingenauigkeit. Ohne unabhängige Statistik verliert Politik ihre Wirklichkeitsbindung. Ohne Wissenschaftsfreiheit wird Forschung gefällig. Ohne Rechtsschutz kann Wirkungssteuerung technokratisch werden. Rang 18 ist deshalb die epistemische Sicherungsschicht der Wirkungsökonomie.

## 4. Executive Summary

Dieses Detailkonzept zeigt, wie Mission-oriented Research und Wirkungsinnovation in der Wirkungsökonomie ausgestaltet wird. Es behandelt fachliche Grundlagen, Datenlogik, Risiken, Governance, politische Anschlussfähigkeit und Umsetzung. Der Schwerpunkt liegt nicht auf symbolischer Wissenschaftsfreundlichkeit, sondern auf belastbarer Wissensinfrastruktur. Forschung soll frei bleiben, aber ihre Wirkungspfade, Datenqualität, Grenzen und Nebenwirkungen müssen besser sichtbar werden.

## 5. Problemdefinition

Die heutige Wissens- und Innovationsordnung ist leistungsfähig, aber fragmentiert. Viele Systeme bewerten Output statt Wirkung: Publikationen statt Erkenntnisqualität, Patente statt gesellschaftlicher Lösung, Drittmittel statt Unabhängigkeit, Reichweite statt Quellenklarheit. Im Themenfeld Mission-oriented Research und Wirkungsinnovation entsteht dadurch eine Lücke zwischen wissenschaftlicher Aktivität und gesellschaftlicher Wirkung. Diese Lücke ist keine persönliche Schuld einzelner Forschender, sondern ein Strukturproblem der Bewertungs- und Förderlogik.

## 6. Wirkungsfrage

Die zentrale Frage lautet: Welche Zustände werden durch Mission-oriented Research und Wirkungsinnovation verändert, welche Risiken entstehen, welche Daten sind belastbar und wie wird Korrektur möglich? Wirkung wird nicht behauptet, sondern über Wirkpfade beschrieben. Ein Wirkpfad umfasst Auslöser, Wirkungspotenzial, Wirkungsrisiko, tatsächliche Zustandsveränderung, Nebenwirkungen, Datenqualität, Bewertungsrahmen und Rückkopplung.

## 7. Systemische Funktion

Mission-oriented Research und Wirkungsinnovation ist nicht nur ein Fachthema. Es verbindet Wissenschaft, Verwaltung, Recht, Öffentlichkeit, Wirtschaft und Bildung. In einer Wirkungsökonomie müssen Erkenntnisse nicht nur produziert, sondern anschlussfähig, überprüfbar und korrigierbar gemacht werden. Das bedeutet: offene Methoden, nachvollziehbare Daten, klare Unsicherheitskommunikation, Schutz vor Lobbyeinfluss, Verfahren für Replikation und eine Sprache, die politische Bewertung nicht als wissenschaftliche Tatsache tarnt.

## 8. Daten- und Bewertungslogik

Die Bewertung erfolgt nicht durch eine einzelne Zahl. Benötigt werden mehrere Ebenen: Datenherkunft, Datenqualität, Replikationsstatus, Methodenoffenheit, Interessenkonflikte, Open-Science-Anteil, gesellschaftliche Anschlussfähigkeit, Wirkungsrisiken, Transformationspotenzial und Schutz vulnerabler Gruppen. Daraus entsteht eine Scorecard, die nicht als Ranking missverstanden werden darf. Sie ist ein Lerninstrument, kein Prestigeinstrument.

## 9. Beispielhafte Indikatoren

Für Mission-oriented Research und Wirkungsinnovation eignen sich Indikatoren wie: Anteil offener Daten, Anteil reproduzierbarer Ergebnisse, dokumentierte Unsicherheitsklassen, Interessenkonflikt-Transparenz, Beteiligung relevanter Praxisakteure, Replikationsbudget, Anschlussfähigkeit an SDGs und SDG+, Risiken für Missbrauch, Transfer in gemeinwohlorientierte Lösungen, Barrierefreiheit von Wissen und Beitrag zu institutionellem Vertrauen.

## 10. Beispiel 1 - kommunale Anwendung

Eine Kommune will Hitzerisiken in Quartieren reduzieren. Forschung liefert Klimadaten, Gesundheitsdaten, Sozialraumprofile und Wirkungsindikatoren. Die Wirkungsökonomie fragt nicht nur, ob Studien existieren, sondern ob sie in konkrete Entscheidungen übersetzt werden: Entsiegelung, Kühlräume, Nachbarschaftshilfe, Pflegevorsorge, Bauleitplanung, Frühwarnsysteme und öffentliche Kommunikation. Der Erfolg wird nicht an Berichtsseiten gemessen, sondern an reduzierten Hitzebelastungen, verbesserter Erreichbarkeit, geringeren Gesundheitsrisiken und höherem Vertrauen.

## 11. Beispiel 2 - Innovationsförderung

Ein Forschungsprogramm fördert KI in der Pflege. Klassisch würden Publikationen, Prototypen und Patente gezählt. Wirkungsökonomisch muss zusätzlich geprüft werden: Entlastet die Technologie Pflegekräfte real? Verbessert sie Würde, Sicherheit und Autonomie? Entstehen Datenschutzrisiken? Verstärkt sie Ungleichheit? Ist sie auditierbar? Gibt es Reallabore, Einspruchsrechte, Haftung und Evaluation? Nur dann kann Innovationsförderung positive Netto-Wirkung erzeugen.

## 12. Governance

Governance für Mission-oriented Research und Wirkungsinnovation braucht mehrere Schutzschichten: Wissenschaftsfreiheit, transparente Förderentscheidungen, unabhängige Integritätsstellen, offene Methoden, Datenschutz, Ethikprüfung, Beteiligung, Rechtsschutz und regelmäßige Evaluation. Ein Wissensrat kann Standards setzen, aber nicht politische Entscheidungen ersetzen. Er sichert Methoden, Integrität und Korrekturfähigkeit.

## 13. Zielkonflikte

Typische Zielkonflikte sind: Offenheit vs. Datenschutz, Geschwindigkeit vs. Qualität, Missionen vs. Grundlagenfreiheit, Transfer vs. Unabhängigkeit, Exzellenz vs. Breitenwirkung, globale Kooperation vs. Forschungssicherheit, standardisierte Indikatoren vs. disziplinäre Unterschiede. Diese Konflikte dürfen nicht verschwiegen werden, sondern müssen Teil der Wirkungsbewertung sein.

## 14. Umsetzungslogik

Die Umsetzung erfolgt schrittweise: Erstens ein freiwilliges Indikatorenset für Pilotprogramme. Zweitens Forschungs-Scorecards für öffentlich geförderte Projekte. Drittens Replikations- und Datenqualitätsfonds. Viertens offene Datenräume mit Schutzklassen. Fünftens jährliche Wirkungsberichte. Sechstens unabhängige Evaluation durch Wissensrat und Wirkungsrat. Siebtens Rechtsschutz bei Bewertungen, Förderentscheidungen und Datenklassifikationen.

## 15. Politische Anschlussfähigkeit

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext, sondern einen Bewertungs- und Steuerungsrahmen. Parteien behalten Ausgestaltungsspielraum. Entscheidend ist nicht, ob Wissenschaftspolitik eher missionsorientiert, grundlagenorientiert, regional, europäisch oder industriepolitisch formuliert wird. Entscheidend ist, ob die gewählten Instrumente wissenschaftliche Freiheit schützen, Wirkung sichtbar machen, Integrität sichern und positive Netto-Wirkung für Mensch, Planet und Demokratie ermöglichen.

## 16. Schutz vor Technokratie

Wirkungsmessung darf Forschung nicht in eine Verwaltungsmaschine verwandeln. Sie darf Wissenschaft nicht nach politischer Nützlichkeit sortieren und keine unliebsamen Ergebnisse sanktionieren. Schutz vor Technokratie bedeutet: Methodenoffenheit, Minderheitenpositionen, Replikation, Widerspruch, Transparenz und Rechtsschutz. Wissenschaft schützt Demokratie nicht, indem sie Demokratie ersetzt, sondern indem sie Wirklichkeit überprüfbar hält.

## 17. Website- und Downloadlogik

Die Onlinefassung dieses Detailkonzepts muss vollständig lesbar sein. Das PDF und die DOCX-Fassung müssen verlinkt werden. Die Seite braucht Inhaltsverzeichnis, Quellen, Glossar, SDG-/SDG+-Block, politische Anschlussfähigkeit, Druckfunktion und Querverlinkungen zu Digitalisierung, Bildung, Medien, Staat und Finanzsystem. Tabellen müssen mobil responsiv sein.

## 18. Fokus: Missionen

Missionen ist in diesem Detailkonzept kein Schlagwort, sondern ein Wirkungsbaustein. Es muss beschrieben werden, welcher Zustand verändert wird, welche Daten die Veränderung belegen, welche Risiken bestehen, welche Akteure beteiligt sind und wie Korrektur möglich bleibt. So wird Missionen von einem Programmpunkt zu einem prüfbaren Element der Wirkungsarchitektur.

## 19. Fokus: Wirkungsinnovation

Wirkungsinnovation ist in diesem Detailkonzept kein Schlagwort, sondern ein Wirkungsbaustein. Es muss beschrieben werden, welcher Zustand verändert wird, welche Daten die Veränderung belegen, welche Risiken bestehen, welche Akteure beteiligt sind und wie Korrektur möglich bleibt. So wird Wirkungsinnovation von einem Programmpunkt zu einem prüfbaren Element der Wirkungsarchitektur.

## 20. Fokus: Portfolios

Portfolios ist in diesem Detailkonzept kein Schlagwort, sondern ein Wirkungsbaustein. Es muss beschrieben werden, welcher Zustand verändert wird, welche Daten die Veränderung belegen, welche Risiken bestehen, welche Akteure beteiligt sind und wie Korrektur möglich bleibt. So wird Portfolios von einem Programmpunkt zu einem prüfbaren Element der Wirkungsarchitektur.

## 21. Fokus: T-SROI

T-SROI ist in diesem Detailkonzept kein Schlagwort, sondern ein Wirkungsbaustein. Es muss beschrieben werden, welcher Zustand verändert wird, welche Daten die Veränderung belegen, welche Risiken bestehen, welche Akteure beteiligt sind und wie Korrektur möglich bleibt. So wird T-SROI von einem Programmpunkt zu einem prüfbaren Element der Wirkungsarchitektur.

## 22. Fokus: Zukunftsfonds

Zukunftsfonds ist in diesem Detailkonzept kein Schlagwort, sondern ein Wirkungsbaustein. Es muss beschrieben werden, welcher Zustand verändert wird, welche Daten die Veränderung belegen, welche Risiken bestehen, welche Akteure beteiligt sind und wie Korrektur möglich bleibt. So wird Zukunftsfonds von einem Programmpunkt zu einem prüfbaren Element der Wirkungsarchitektur.

## 23. Fachliche Tiefenlogik

Dieses Kapitel vertieft die fachliche Logik des jeweiligen Unterbereichs. Der Kern besteht darin, wissenschaftliche, rechtliche, gesellschaftliche und technische Ebenen nicht zu trennen. Wirkung entsteht nicht aus einer einzelnen Maßnahme, sondern aus einem Zusammenspiel von Daten, Methoden, Institutionen, Anreizen, Vertrauen, Qualifikation und Rechtsschutz. Für die Website bedeutet das: Der Text muss als Volltext lesbar sein und darf nicht nur als Teaser auf einen Download verweisen.

## 24. Wirkungsarchitektur

Die Wirkungsarchitektur besteht aus Auslösern, Datenquellen, Bewertungsregeln, Governance, Rückkopplung und Korrektur. Im Forschungsbereich sind Auslöser zum Beispiel Förderprogramme, Publikationen, Datensätze, Modelle, Patente, Reallabore, Gutachten, Sachverständigenaussagen oder politische Empfehlungen. Erst wenn klar ist, welche Zustände dadurch verändert werden, kann Wirkung bewertet werden.

## 25. Datenquellen im Detail

Relevante Datenquellen sind Forschungsdaten, Projektberichte, Open-Access-Repositorys, Registerdaten, statistische Fachreihen, Peer-Review-Dokumente, Replikationsstudien, Ethikvoten, Interessenerklärungen, Transferberichte, Nutzungsdaten öffentlicher Infrastrukturen, Daten aus Reallaboren und qualitative Rückmeldungen aus Praxisfeldern. Alle Daten benötigen Herkunft, Version, Gültigkeitszeitraum und Unsicherheitsklasse.

## 26. Scorecard-Logik

Eine Forschungs-Scorecard darf nicht zu einem eindimensionalen Ranking werden. Sie muss mehrere Felder getrennt sichtbar machen: wissenschaftliche Qualität, Datenqualität, Offenheit, Replikation, gesellschaftliche Anschlussfähigkeit, Wirkungsrisiko, Transformationspotenzial, ethische Grenzen, Schutz vulnerabler Gruppen, Rechtsschutzfähigkeit und Kosten der Umsetzung. Die Reverse-Merit-Logik gilt bei roten Linien: schwere Verstöße gegen Integrität, Grundrechte oder Datenmanipulation können nicht durch gute Transferwerte kompensiert werden.

## 27. Institutionelle Umsetzung

Die Umsetzung benötigt Rollen. Forschende erzeugen und prüfen Wissen. Hochschulen und Institute sichern Methoden und Infrastruktur. Fördergeber setzen Anreize. Der Wissensrat definiert Standards und Missbrauchsschutz. Der Wirkungsrat stellt Anschluss an WÖk-IDs und Benchmarks her. Gerichte sichern Rechtsschutz. Medien übersetzen Wissen in Öffentlichkeit. Bürger:innen und Praxisakteure bringen Erfahrung ein, ohne wissenschaftliche Methode zu ersetzen.

## 28. Finanzierungslogik

Finanzierung darf nicht nur Exzellenz im engen Sinn belohnen. Benötigt werden Grundfinanzierung für freie Forschung, Replikationsfonds, Transformationsfonds, Open-Science-Infrastruktur, Datenkurationsmittel, Wissenschaftskommunikation, Citizen-Science-Formate, Ethik- und Rechtsprüfung sowie langfristige Monitoringbudgets. Kurzfristige Projektförderung allein erzeugt keine stabile Wissensinfrastruktur.

## 29. Risikomanagement

Rang 18 behandelt auch Risiken der Wissensordnung: Publikationsdruck, Drittmittelabhängigkeit, Reproduktionskrisen, Datenmanipulation, Interessenkonflikte, politische Vereinnahmung, Forschungssicherheitsrisiken, Dual Use, KI-generierte Scheindaten, Zitationskartelle, methodische Monokulturen und Vertrauensverlust. Diese Risiken müssen sichtbar, prüfbar und sanktionierbar sein, ohne Wissenschaftsfreiheit zu beschädigen.

## 30. Beispielhafte Berechnungslogik

Ein Forschungsprojekt kann mit einem Netto-Wirkungs-Index bewertet werden, der positive Beiträge wie offene Daten, robuste Methode, relevante Zielgruppe, Transformationspfad und Replikationsfähigkeit sichtbar macht. Negative Beiträge wie hohe Bias-Risiken, fehlende Datenzugänglichkeit, unklare Finanzierung, nicht dokumentierte Unsicherheit oder Ausschluss betroffener Gruppen werden gegengehalten. Der Wert dient nicht als absolute Wahrheit, sondern als Entscheidungs- und Lernsignal.

## 31. Reallabor und Pilotierung

Für die praktische Umsetzung eignen sich Reallabore. Eine Kommune, Hochschule oder Region wählt ein konkretes Problem, zum Beispiel Hitze, Pflege, Mobilität, Desinformation oder Energiearmut. Forschung, Verwaltung, Zivilgesellschaft und Wirtschaft entwickeln gemeinsam Interventionen. Die Wirkungsökonomie verlangt klare Baselines, Indikatoren, Datenschutz, Beteiligung, Zwischenberichte, Replikationsmöglichkeiten und eine Exit-Logik, falls negative Wirkungen auftreten.

## 32. Rechtliche Anschlussstellen

Rechtlich relevant sind Wissenschaftsfreiheit, Datenschutz, Informationsfreiheit, Förderrecht, Vergaberecht, Urheberrecht, Forschungsdatenrecht, Haftung, Antidiskriminierung, Hochschulrecht, Statistikrecht, Verwaltungsrecht und gerichtlicher Rechtsschutz. Eine Wirkungsordnung darf nur dann reale Folgen auslösen, wenn Verfahren, Zuständigkeiten, Begründungen und Einspruchsmöglichkeiten klar sind.

## 33. Kommunikation und Öffentlichkeit

Wissenschaftliche Kommunikation muss verständlich sein, ohne Unsicherheit zu verschweigen. Sie muss unterscheiden zwischen Beobachtung, Modell, Prognose, Kausalannahme, normativer Bewertung und politischer Empfehlung. Gerade bei Klima, Gesundheit, Migration, Sicherheit oder KI ist diese Trennung entscheidend, weil falsche Sicherheit und falsche Beliebigkeit beide demokratische Schäden erzeugen können.

## 34. Umsetzung auf der Website

Die Website-Seite dieses Detailkonzepts braucht eine vollständige Onlinefassung mit mobilem Inhaltsverzeichnis, Downloadlinks zu PDF und DOCX, Toolkarten, Glossar, Quellen, SDG-/SDG+-Block, politischer Anschlussfähigkeit und Querverlinkungen. Tabellen sollen mobil als Karten oder horizontal scrollbar dargestellt werden. Der Text darf keine internen CodeX-Hinweise enthalten.

## 35. Quellenrahmen

Interne Quellen: Systemmodell der Wirkungsökonomie, Die neue Ordnung des Wohlstands, Grundlagenpapier der Wirkungsökonomie, Begriffsleitfaden. Externe Anschlussstellen: UNESCO Open Science Recommendation, CoARA Agreement on Reforming Research Assessment, DORA, OECD Mission-Oriented Innovation Policies, EU Missions, EU Guiding Principles for Knowledge Valorisation.

## Quellen und Referenzrahmen

- Interne WÖk-Referenz: Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

- Interne WÖk-Referenz: Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

- UNESCO: UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

- CoARA: Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

- DORA: San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

- OECD: Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

- Europäische Kommission: EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

- Europäische Kommission: Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.