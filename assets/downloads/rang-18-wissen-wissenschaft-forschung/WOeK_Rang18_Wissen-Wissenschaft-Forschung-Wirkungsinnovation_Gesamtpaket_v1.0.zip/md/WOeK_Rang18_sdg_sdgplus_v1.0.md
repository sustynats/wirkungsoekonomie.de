# SDG- und SDG+-Bezug Rang 18

## Wissen, Wissenschaft und Forschung im Referenzrahmen der Wirkungsökonomie

Autorin: Natalie Weber  
Referenz: Wirkungsökonomie  
Version: 1.0  
Stand: Mai 2026  
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Inhaltsverzeichnis

1. Einordnung

2. Führende Begriffslogik

3. Warum dieser Bereich wichtig ist

4. SDG+ Hinweis

5. SDG 4 - Hochwertige Bildung

6. SDG 5 - Geschlechtergleichstellung

7. SDG 8 - Menschenwürdige Arbeit

8. SDG 9 - Industrie, Innovation und Infrastruktur

9. SDG 10 - Weniger Ungleichheiten

10. SDG 13 - Klimaschutz

11. SDG 16 - Frieden, Gerechtigkeit und starke Institutionen

12. SDG 17 - Partnerschaften

13. SDG+-Dimensionen

## 1. Einordnung

SDG-/SDG+-Block Rang 18 gehört zu Rang 18 der Wirkungsökonomie. Der Bereich verbindet Wissenschaft, Forschung, öffentliche Wahrheit, Innovationspolitik, Datenqualität und Rechtsschutz. Er schließt an Rang 17 an: Digitale Infrastrukturen machen Wirkung sichtbar, aber erst Wissenschaft, Statistik, offene Daten, Integrität und Rechtsprechung sichern, dass diese Sichtbarkeit nicht beliebig, manipulierbar oder technokratisch wird.

## 2. Führende Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird sie am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Logik gilt auch für Wissenschaft und Innovation: Nicht jede Forschung wirkt sofort positiv, nicht jede Innovation ist Fortschritt, nicht jede Datenlage ist Wahrheit. Entscheidend ist die nachprüfbare Zustandsveränderung und ihre Rückkopplung in Entscheidung, Lernen und Korrektur.

## 3. Warum dieser Bereich wichtig ist

Ohne verlässliches Wissen kann Wirkung nicht bewertet werden. Ohne Datenqualität kann keine WÖk-ID stabil sein. Ohne Replikation wird Forschung anfällig für Scheingenauigkeit. Ohne unabhängige Statistik verliert Politik ihre Wirklichkeitsbindung. Ohne Wissenschaftsfreiheit wird Forschung gefällig. Ohne Rechtsschutz kann Wirkungssteuerung technokratisch werden. Rang 18 ist deshalb die epistemische Sicherungsschicht der Wirkungsökonomie.

## 4. SDG+ Hinweis

SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratie, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt, digitale Selbstbestimmung und öffentliche Wahrheit.

## 5. SDG 4 - Hochwertige Bildung

Wissenschaft und Forschung stärken Bildung, Wirkungskompetenz, kritisches Denken und lebenslanges Lernen.

## 6. SDG 5 - Geschlechtergleichstellung

Forschungszugang, Karrieren, Daten und Innovationen müssen geschlechtergerecht und diskriminierungsarm gestaltet werden.

## 7. SDG 8 - Menschenwürdige Arbeit

Wissenschaft erzeugt Zukunftsarbeit, Qualifikation und faire Transformationspfade, darf aber keine Prekarität in Forschungsstrukturen verstärken.

## 8. SDG 9 - Industrie, Innovation und Infrastruktur

Rang 18 übersetzt Forschung in wirkungsorientierte Innovation, Infrastruktur und offene Wissenssysteme.

## 9. SDG 10 - Weniger Ungleichheiten

Open Science, gerechte Datenzugänge und inklusive Forschung reduzieren Wissens- und Innovationsungleichheit.

## 10. SDG 13 - Klimaschutz

Klimaforschung, Transformationsforschung und missionsorientierte Innovation sind zentrale Hebel gegen Klimarisiken.

## 11. SDG 16 - Frieden, Gerechtigkeit und starke Institutionen

Wissenschaftliche Integrität, öffentliche Statistik, Rechtsprechung und Quellenklarheit schützen demokratische Entscheidungsfähigkeit.

## 12. SDG 17 - Partnerschaften

Forschung wirkt durch internationale Kooperation, Datenräume, transdisziplinäre Netzwerke und globale Wissenspartnerschaften.

## 13. SDG+-Dimensionen

Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, Wissenschaftsvertrauen, digitale Selbstbestimmung, Schutz vor Desinformation, öffentliche Wahrheit, Wissensgerechtigkeit

## Quellen und Referenzrahmen

- Interne WÖk-Referenz: Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

- Interne WÖk-Referenz: Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

- UNESCO: UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

- CoARA: Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

- DORA: San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

- OECD: Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

- Europäische Kommission: EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

- Europäische Kommission: Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.