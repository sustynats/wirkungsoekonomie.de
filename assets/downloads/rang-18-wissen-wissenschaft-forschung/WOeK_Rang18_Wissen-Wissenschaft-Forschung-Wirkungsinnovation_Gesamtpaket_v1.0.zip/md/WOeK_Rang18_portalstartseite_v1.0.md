# Rang 18 - Wissen, Wissenschaft, Forschung und Wirkungsinnovation

## Wissenschaft als Korrektursystem, Forschung als Wirkungswissen, Innovation als Systemlernen

Autorin: Natalie Weber  
Referenz: Wirkungsökonomie  
Version: 1.0  
Stand: Mai 2026  
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Inhaltsverzeichnis

1. Einordnung

2. Führende Begriffslogik

3. Warum dieser Bereich wichtig ist

4. Portalstartseite - Zweck

5. Leitidee

6. Unterbereiche

7. Downloads und Onlinefassungen

## 1. Einordnung

Wissen, Wissenschaft, Forschung und Wirkungsinnovation gehört zu Rang 18 der Wirkungsökonomie. Der Bereich verbindet Wissenschaft, Forschung, öffentliche Wahrheit, Innovationspolitik, Datenqualität und Rechtsschutz. Er schließt an Rang 17 an: Digitale Infrastrukturen machen Wirkung sichtbar, aber erst Wissenschaft, Statistik, offene Daten, Integrität und Rechtsprechung sichern, dass diese Sichtbarkeit nicht beliebig, manipulierbar oder technokratisch wird.

## 2. Führende Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird sie am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Logik gilt auch für Wissenschaft und Innovation: Nicht jede Forschung wirkt sofort positiv, nicht jede Innovation ist Fortschritt, nicht jede Datenlage ist Wahrheit. Entscheidend ist die nachprüfbare Zustandsveränderung und ihre Rückkopplung in Entscheidung, Lernen und Korrektur.

## 3. Warum dieser Bereich wichtig ist

Ohne verlässliches Wissen kann Wirkung nicht bewertet werden. Ohne Datenqualität kann keine WÖk-ID stabil sein. Ohne Replikation wird Forschung anfällig für Scheingenauigkeit. Ohne unabhängige Statistik verliert Politik ihre Wirklichkeitsbindung. Ohne Wissenschaftsfreiheit wird Forschung gefällig. Ohne Rechtsschutz kann Wirkungssteuerung technokratisch werden. Rang 18 ist deshalb die epistemische Sicherungsschicht der Wirkungsökonomie.

## 4. Portalstartseite - Zweck

Das Portal Rang 18 bündelt alle Inhalte zu Wissenschaft, Forschung, öffentlicher Wahrheit, Wirkungsinnovation, Wissenschaftsgovernance, Forschungsbewertung, Open Science, Science for Policy, Rechtsprechung und Wirkungskompetenz. Es macht sichtbar, dass die Wirkungsökonomie nicht nur Daten sammelt, sondern Wissen, Methode, Korrektur, Recht und demokratische Kontrolle braucht.

## 5. Leitidee

Wissenschaft ist kein Wahrheitsmonopol. Wissenschaft ist ein Korrektursystem. Forschung ist keine bloße Publikationsmaschine. Forschung ist eine Quelle gesellschaftlicher Problemlösung, aber nur, wenn Freiheit, Integrität, Replikation, Datenqualität und offene Kritik geschützt werden. Innovation ist keine Kapitalbeschleunigung, sondern evolutionäres Systemlernen in Richtung Mensch, Planet und Demokratie.

## 6. Unterbereiche

Die Portalarchitektur umfasst: Wissenschaft als Wirklichkeitsprüfung, Wissensrat, Open Science, Forschungsbewertung, Wissenschafts-Wirkungsindikatoren, Wirkungsinnovation, Transdisziplinarität, Science for Policy, öffentliche Statistik, Replikation, Rechtsprechung und Wirkungskompetenz-Akademie.

## 7. Downloads und Onlinefassungen

Alle Inhalte müssen online vollständig lesbar sein und zusätzlich als PDF und DOCX vorliegen. Die Downloadseite enthält ZIP-Gesamtpaket, Gesamtpaket-PDF, Gesamtpaket-DOCX, Konzeptpapier, Gesamtdossier, Detailkonzepte, Toolkarten, SDG-/SDG+-Block, politische Anschlussfähigkeit, Quellen und Glossarlinks.

## Quellen und Referenzrahmen

- Interne WÖk-Referenz: Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

- Interne WÖk-Referenz: Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

- UNESCO: UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

- CoARA: Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

- DORA: San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

- OECD: Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

- Europäische Kommission: EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

- Europäische Kommission: Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.