# Toolkarten Rang 18

## Werkzeuge für Wissensintegrität, Forschungswirkung und Wirkungsinnovation

Autorin: Natalie Weber  
Referenz: Wirkungsökonomie  
Version: 1.0  
Stand: Mai 2026  
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Inhaltsverzeichnis

1. Einordnung

2. Führende Begriffslogik

3. Warum dieser Bereich wichtig ist

4. Zweck

5. Wissenschafts-Wirkungsindikator-Set

6. Forschungs-Scorecard

7. Wissensintegritäts-Check

8. Mission-Impact-Radar

9. Science-for-Policy-Kompass

10. Replikations- und Datenqualitätsmonitor

11. Wirkungsinnovations-Portfolio

## 1. Einordnung

Toolkarten Rang 18 gehört zu Rang 18 der Wirkungsökonomie. Der Bereich verbindet Wissenschaft, Forschung, öffentliche Wahrheit, Innovationspolitik, Datenqualität und Rechtsschutz. Er schließt an Rang 17 an: Digitale Infrastrukturen machen Wirkung sichtbar, aber erst Wissenschaft, Statistik, offene Daten, Integrität und Rechtsprechung sichern, dass diese Sichtbarkeit nicht beliebig, manipulierbar oder technokratisch wird.

## 2. Führende Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird sie am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Logik gilt auch für Wissenschaft und Innovation: Nicht jede Forschung wirkt sofort positiv, nicht jede Innovation ist Fortschritt, nicht jede Datenlage ist Wahrheit. Entscheidend ist die nachprüfbare Zustandsveränderung und ihre Rückkopplung in Entscheidung, Lernen und Korrektur.

## 3. Warum dieser Bereich wichtig ist

Ohne verlässliches Wissen kann Wirkung nicht bewertet werden. Ohne Datenqualität kann keine WÖk-ID stabil sein. Ohne Replikation wird Forschung anfällig für Scheingenauigkeit. Ohne unabhängige Statistik verliert Politik ihre Wirklichkeitsbindung. Ohne Wissenschaftsfreiheit wird Forschung gefällig. Ohne Rechtsschutz kann Wirkungssteuerung technokratisch werden. Rang 18 ist deshalb die epistemische Sicherungsschicht der Wirkungsökonomie.

## 4. Zweck

Die Toolkarten machen Rang 18 praktisch anschlussfähig. Sie sind keine fertigen Softwareprodukte, sondern beschreiben die Werkzeuge, die Website, Akademie, Portale, Verwaltung, Forschung und Förderprogramme später als Demo oder Vollversion anbieten können.

## 5. Wissenschafts-Wirkungsindikator-Set

Beschreibung: Bewertet Forschungsprojekte nach Qualität, Offenheit, Replikationsfähigkeit, gesellschaftlicher Anschlussfähigkeit, Transformationspfad und Risiken.
Nutzen: Macht Wissenswirkung sichtbar und verhindert, dass Forschung nur an Output gemessen wird.
Zielgruppe: Forschungseinrichtungen, Fördergeber, Ministerien
Status: Demo in Vorbereitung
Link: /tools/wissenschafts-wirkungsindikatoren/

## 6. Forschungs-Scorecard

Beschreibung: Macht Wirkungspfad, Datenqualität, Zielkonflikte, Nebenwirkungen und Umsetzungsreife eines Forschungsprojekts sichtbar.
Nutzen: Macht Wissenswirkung sichtbar und verhindert, dass Forschung nur an Output gemessen wird.
Zielgruppe: Hochschulen, Förderprogramme, Innovationsagenturen
Status: Demo in Vorbereitung
Link: /tools/forschungs-scorecard/

## 7. Wissensintegritäts-Check

Beschreibung: Prüft Interessenkonflikte, Datenherkunft, Reproduzierbarkeit, Open-Science-Anteil, methodische Transparenz und Korrekturmechanismen.
Nutzen: Macht Wissenswirkung sichtbar und verhindert, dass Forschung nur an Output gemessen wird.
Zielgruppe: Wissensrat, Forschungseinrichtungen, Redaktionen, Verwaltung
Status: Demo in Vorbereitung
Link: /tools/wissensintegritaets-check/

## 8. Mission-Impact-Radar

Beschreibung: Übersetzt Missionen in messbare Wirkungspfade, Zwischenziele, Portfolio-Risiken und Lernschleifen.
Nutzen: Macht Wissenswirkung sichtbar und verhindert, dass Forschung nur an Output gemessen wird.
Zielgruppe: Politik, Kommunen, Forschungscluster, Innovationsfonds
Status: Demo in Vorbereitung
Link: /tools/mission-impact-radar/

## 9. Science-for-Policy-Kompass

Beschreibung: Hilft Ministerien und Parlamenten, Evidenz, Unsicherheit, Zielkonflikte und normative Bewertung sauber zu trennen.
Nutzen: Macht Wissenswirkung sichtbar und verhindert, dass Forschung nur an Output gemessen wird.
Zielgruppe: Politik, Verwaltung, Wissenschaftskommunikation
Status: Demo in Vorbereitung
Link: /tools/science-for-policy-kompass/

## 10. Replikations- und Datenqualitätsmonitor

Beschreibung: Erfasst Replikationsstatus, Datenqualität, Unsicherheitsklassen, Audit-Trails und offene Materialien.
Nutzen: Macht Wissenswirkung sichtbar und verhindert, dass Forschung nur an Output gemessen wird.
Zielgruppe: Forschung, Prüfstellen, Fördergeber
Status: Demo in Vorbereitung
Link: /tools/replikations-datenqualitaetsmonitor/

## 11. Wirkungsinnovations-Portfolio

Beschreibung: Bewertet Innovationsportfolios nach Wirkung, Risiko, Reifegrad, Diffusionspotenzial, Gerechtigkeit und Resilienz.
Nutzen: Macht Wissenswirkung sichtbar und verhindert, dass Forschung nur an Output gemessen wird.
Zielgruppe: Wirkungsfonds, Unternehmen, Kommunen
Status: Demo in Vorbereitung
Link: /tools/wirkungsinnovations-portfolio/

## Quellen und Referenzrahmen

- Interne WÖk-Referenz: Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

- Interne WÖk-Referenz: Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

- UNESCO: UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

- CoARA: Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

- DORA: San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

- OECD: Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

- Europäische Kommission: EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

- Europäische Kommission: Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.