# Bestands- und Nachlieferliste Rang 18

## Status, Lücken und Nachlieferungen für Website, Downloads und Detailkonzepte

Autorin: Natalie Weber  
Referenz: Wirkungsökonomie  
Version: 1.0  
Stand: Mai 2026  
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Inhaltsverzeichnis

1. Einordnung

2. Führende Begriffslogik

3. Warum dieser Bereich wichtig ist

4. Bestand

5. Lücken

6. Nachlieferung

7. Portalstartseite

8. Konzeptpapier

9. Gesamtdossier

10. Detailkonzepte

11. Online-Volltexte

12. PDF-Downloads

13. DOCX-Downloads

14. Toolkarten

15. SDG-/SDG+-Block

16. Politische Anschlussfähigkeit

17. Querverlinkungen

18. Mobile UX

## 1. Einordnung

Bestands- und Nachlieferliste gehört zu Rang 18 der Wirkungsökonomie. Der Bereich verbindet Wissenschaft, Forschung, öffentliche Wahrheit, Innovationspolitik, Datenqualität und Rechtsschutz. Er schließt an Rang 17 an: Digitale Infrastrukturen machen Wirkung sichtbar, aber erst Wissenschaft, Statistik, offene Daten, Integrität und Rechtsprechung sichern, dass diese Sichtbarkeit nicht beliebig, manipulierbar oder technokratisch wird.

## 2. Führende Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird sie am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Logik gilt auch für Wissenschaft und Innovation: Nicht jede Forschung wirkt sofort positiv, nicht jede Innovation ist Fortschritt, nicht jede Datenlage ist Wahrheit. Entscheidend ist die nachprüfbare Zustandsveränderung und ihre Rückkopplung in Entscheidung, Lernen und Korrektur.

## 3. Warum dieser Bereich wichtig ist

Ohne verlässliches Wissen kann Wirkung nicht bewertet werden. Ohne Datenqualität kann keine WÖk-ID stabil sein. Ohne Replikation wird Forschung anfällig für Scheingenauigkeit. Ohne unabhängige Statistik verliert Politik ihre Wirklichkeitsbindung. Ohne Wissenschaftsfreiheit wird Forschung gefällig. Ohne Rechtsschutz kann Wirkungssteuerung technokratisch werden. Rang 18 ist deshalb die epistemische Sicherungsschicht der Wirkungsökonomie.

## 4. Bestand

Vorhanden sind starke Buchanker in Teil XIV der neuen Ordnung des Wohlstands sowie im Systemmodell. Dort werden Wissenschaft, Bildung, Innovation und Digitalisierung als intellektuelles Betriebssystem beschrieben. Zusätzlich liegen Grundlagen zur WÖk-ID, Datenqualität, Reverse Merit Order, T-SROI, DPP und Wirkungsdatenräumen vor.

## 5. Lücken

Noch nicht ausreichend vorhanden sind eigenständige Website-Onlinefassungen, PDF- und DOCX-Downloads je Unterbereich, Toolkarten mit Status und Link, mobile Tabellen, umfassende politische Anschlussfähigkeit und eine konsistente Downloadbibliothek.

## 6. Nachlieferung

Für Rang 18 werden Konzeptpapier, Gesamtdossier, zehn Detailkonzepte, Wirkungsindikatoren, Toolkarten, SDG-/SDG+-Block, politische Anschlussfähigkeit, Quellen- und Glossarblock sowie CodeX-Anweisung ausgeliefert.

## 7. Portalstartseite

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 8. Konzeptpapier

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 9. Gesamtdossier

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 10. Detailkonzepte

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 11. Online-Volltexte

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 12. PDF-Downloads

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 13. DOCX-Downloads

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 14. Toolkarten

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 15. SDG-/SDG+-Block

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 16. Politische Anschlussfähigkeit

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 17. Querverlinkungen

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## 18. Mobile UX

Status: neu als Langfassung und Website-Baustein einbauen. Nachlieferung: vollständige Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Druckfunktion und Downloadprüfung.

## Quellen und Referenzrahmen

- Interne WÖk-Referenz: Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

- Interne WÖk-Referenz: Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

- UNESCO: UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

- CoARA: Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

- DORA: San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

- OECD: Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

- Europäische Kommission: EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

- Europäische Kommission: Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.