# Konzeptpapier Rang 18 - Wissen, Wissenschaft, Forschung und Wirkungsinnovation

## Wissenschaft als Korrektursystem der Wirkungsökonomie

Autorin: Natalie Weber  
Referenz: Wirkungsökonomie  
Version: 1.0  
Stand: Mai 2026  
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Inhaltsverzeichnis

1. Einordnung

2. Führende Begriffslogik

3. Warum dieser Bereich wichtig ist

4. Executive Summary

5. Diagnose

6. Zielbild

7. Zentrale Instrumente

8. Kapitel 1 - Wissenschaft als Korrektursystem

9. Kapitel 2 - Forschung als öffentliches Gut

10. Kapitel 3 - Innovationslogik

11. Kapitel 4 - Daten und Replikation

12. Kapitel 5 - Open Science

13. Kapitel 6 - Forschungsbewertung

14. Kapitel 7 - Science for Policy

15. Kapitel 8 - Rechtsschutz

16. Kapitel 9 - Wissensrat

17. Kapitel 10 - Wirkungskompetenz

18. Kapitel 11 - Forschungsinfrastruktur

19. Kapitel 12 - Internationale Anschlussfähigkeit

20. Kapitel 13 - Umsetzungspfad

21. Kapitel 14 - Abgrenzung

22. Politische Anschlussfähigkeit - Aufgabe der Politik

23. Politische Anschlussfähigkeit - Politische Rahmenbedingungen

24. Politische Anschlussfähigkeit - Ausgestaltungsspielraum

25. Politische Anschlussfähigkeit - Zielkonflikte

26. Politische Anschlussfähigkeit - Rollenverteilung

27. Politische Anschlussfähigkeit - Übergang und Schutz

28. Politische Anschlussfähigkeit - Evaluation und Korrektur

29. Politische Anschlussfähigkeit - Schutz vor Technokratie

30. SDG 4 - Hochwertige Bildung

31. SDG 5 - Geschlechtergleichstellung

32. SDG 8 - Menschenwürdige Arbeit

33. SDG 9 - Industrie, Innovation und Infrastruktur

34. SDG 10 - Weniger Ungleichheiten

35. SDG 13 - Klimaschutz

36. SDG 16 - Frieden, Gerechtigkeit und starke Institutionen

37. SDG 17 - Partnerschaften

## 1. Einordnung

Konzeptpapier Wissen, Wissenschaft, Forschung und Wirkungsinnovation gehört zu Rang 18 der Wirkungsökonomie. Der Bereich verbindet Wissenschaft, Forschung, öffentliche Wahrheit, Innovationspolitik, Datenqualität und Rechtsschutz. Er schließt an Rang 17 an: Digitale Infrastrukturen machen Wirkung sichtbar, aber erst Wissenschaft, Statistik, offene Daten, Integrität und Rechtsprechung sichern, dass diese Sichtbarkeit nicht beliebig, manipulierbar oder technokratisch wird.

## 2. Führende Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein. Bewertet wird sie am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Logik gilt auch für Wissenschaft und Innovation: Nicht jede Forschung wirkt sofort positiv, nicht jede Innovation ist Fortschritt, nicht jede Datenlage ist Wahrheit. Entscheidend ist die nachprüfbare Zustandsveränderung und ihre Rückkopplung in Entscheidung, Lernen und Korrektur.

## 3. Warum dieser Bereich wichtig ist

Ohne verlässliches Wissen kann Wirkung nicht bewertet werden. Ohne Datenqualität kann keine WÖk-ID stabil sein. Ohne Replikation wird Forschung anfällig für Scheingenauigkeit. Ohne unabhängige Statistik verliert Politik ihre Wirklichkeitsbindung. Ohne Wissenschaftsfreiheit wird Forschung gefällig. Ohne Rechtsschutz kann Wirkungssteuerung technokratisch werden. Rang 18 ist deshalb die epistemische Sicherungsschicht der Wirkungsökonomie.

## 4. Executive Summary

Rang 18 definiert die Wissensordnung der Wirkungsökonomie. Digitale Daten und Scorecards reichen nicht aus, wenn Wissen nicht unabhängig, prüfbar, reproduzierbar, offen, rechtlich kontrollierbar und demokratisch anschlussfähig ist. Die Wirkungsökonomie braucht Wissenschaft als Wirklichkeitsprüfung, Forschung als Wirkungswissen, Innovation als Systemlernen und Rechtsprechung als Freiheitsgarantie.

## 5. Diagnose

Die heutige Wissensordnung leidet nicht an einem Mangel an Daten, sondern an einer Fehlkopplung von Wissen und Steuerung. Forschung wird häufig an Publikationen, Drittmitteln, Zitationen oder Patenten gemessen. Politik nutzt Studien selektiv. Unternehmen verwerten Forschung nach Geschäftsmodellen. Medien verkürzen Unsicherheit. Bürger:innen treffen auf widersprüchliche Aussagen. Daraus entsteht ein Vertrauensproblem: Nicht weil Wissenschaft schwach wäre, sondern weil ihre Rolle im System nicht sauber geschützt und übersetzt wird.

## 6. Zielbild

Rang 18 schafft eine Architektur, in der Wissen öffentlich, überprüfbar, frei, offen und wirksam wird. Wissenschaft bleibt frei. Forschung wird nicht politisch kommandiert. Innovation bleibt dezentral. Aber die Wirkungsökonomie ergänzt diese Freiheit um Verantwortung, Transparenz, Datenqualität, Replikation, Integrität und Wirkungsrückkopplung.

## 7. Zentrale Instrumente

Zentrale Instrumente sind: Wissensrat, Wissenschafts-Wirkungsindikatoren, Forschungs-Scorecards, Replikationsfonds, Open-Science-Infrastruktur, Science-for-Policy-Kompass, Interessenkonfliktregister, öffentliche Statistik-Sicherung, Wirkungsinnovations-Portfolios, Wirkungskompetenz-Akademie und Rechtsschutz gegen technokratische Fehlsteuerung.

## 8. Kapitel 1 - Wissenschaft als Korrektursystem

Wissenschaft ist in der Wirkungsökonomie kein Ersatz für Politik. Sie ist die institutionalisierte Praxis, Annahmen zu prüfen, Daten zu ordnen, Fehler zu finden, Unsicherheit zu benennen und Wirklichkeit gegen Behauptung zu verteidigen. Diese Korrekturfunktion ist wichtiger als Autorität. Wissenschaft kann irren, aber sie enthält Verfahren, um Irrtum sichtbar zu machen.

## 9. Kapitel 2 - Forschung als öffentliches Gut

Forschung ist nicht nur Eigentum einzelner Institutionen oder Unternehmen. Öffentlich finanzierte Forschung erzeugt Gemeingüter: Wissen, Daten, Methoden, Ausbildung, Infrastrukturen, Kritikfähigkeit und Innovationsmöglichkeiten. Dieses öffentliche Gut muss zugänglich sein, ohne Datenschutz, Sicherheit, Persönlichkeitsrechte oder legitime Schutzinteressen zu verletzen.

## 10. Kapitel 3 - Innovationslogik

Innovation ist nicht automatisch Fortschritt. Eine neue Technologie kann Produktivität steigern und zugleich Demokratie, Arbeit, Umwelt oder Gesundheit schädigen. Wirkungsinnovation fragt daher nach Netto-Wirkung, Verteilung, Nebenwirkung, Rebound, Missbrauch und Langzeitfolgen. Sie verbindet Freiheit zur Erfindung mit Verantwortung für Systemfolgen.

## 11. Kapitel 4 - Daten und Replikation

Wirkungsmessung braucht Daten, aber Daten sind kein Selbstzweck. Daten brauchen Herkunft, Versionierung, Unsicherheitsklassen, Audit-Trails, Datenschutz und Replikationsmöglichkeit. Replikation darf nicht als akademischer Luxus gelten. Sie ist Sicherheitsinfrastruktur gegen Scheingenauigkeit, Fehlanreize und Wirkungssimulation.

## 12. Kapitel 5 - Open Science

Open Science macht Wissenschaft zugänglicher, überprüfbarer und kooperativer. Gleichzeitig braucht Offenheit Schutzgrenzen: personenbezogene Daten, Sicherheitsrisiken, vulnerable Gruppen, Missbrauch von biologischen oder digitalen Informationen und geistige Leistungen müssen differenziert behandelt werden. Offenheit bedeutet nicht Schutzlosigkeit.

## 13. Kapitel 6 - Forschungsbewertung

Die Wirkungsökonomie unterstützt Reformen der Forschungsbewertung, die Qualität, Integrität, Offenheit, Kooperation und Wirkung stärker berücksichtigen. Sie lehnt flache Rankings ab. Eine gute Bewertungslogik erkennt verschiedene Forschungsarten an: Grundlagenforschung, Methodenarbeit, Datenkuratierung, Replikation, Transfer, Lehre, Wissenschaftskommunikation und transdisziplinäre Problemlösung.

## 14. Kapitel 7 - Science for Policy

Politik braucht Wissenschaft, darf sie aber nicht vereinnahmen. Science for Policy muss Evidenz, Unsicherheit, Zielkonflikt und normative Entscheidung trennen. Sachverständigenräte, statistische Ämter, Ministerien und Parlamente brauchen Standards, die selektive Evidenznutzung, Lobbyverzerrung und Scheingewissheit verhindern.

## 15. Kapitel 8 - Rechtsschutz

Sobald Wirkungsbewertungen reale Folgen auslösen, braucht es Rechtsschutz. Scorecards, Register, Förderentscheidungen, Wirkungsberichte und Innovationsfreigaben müssen begründbar, dokumentiert und überprüfbar sein. Die Justiz ist nicht Gegnerin der Wirkungsökonomie, sondern ihre Freiheitsgarantie.

## 16. Kapitel 9 - Wissensrat

Der Wissensrat ist als unabhängiges Gremium zu denken, das Methodenstandards, Replikationslogik, Interessenkonflikttransparenz, Open-Science-Anforderungen und KI-Standards für Wissenschaft begleitet. Er darf nicht Forschung steuern, sondern schützt die Bedingungen, unter denen Forschung frei und belastbar bleibt.

## 17. Kapitel 10 - Wirkungskompetenz

Wirkungskompetenz ist die Fähigkeit, Wirkpfade, Datenqualität, Unsicherheit, Nebenwirkungen und Zielkonflikte zu verstehen. Sie ist nicht nur für Wissenschaftler:innen relevant, sondern auch für Verwaltung, Politik, Medien, Unternehmen, Schulen und Bürger:innen. Ohne Wirkungskompetenz bleibt die Wirkungsökonomie elitär.

## 18. Kapitel 11 - Forschungsinfrastruktur

Zur Infrastruktur gehören Repositorien, Datenräume, Bibliotheken, Labore, Reallabore, Statistikämter, Forschungsdatenzentren, Ethikkommissionen, Prüfstellen, Open-Source-Werkzeuge und Wissenschaftskommunikation. Diese Infrastrukturen müssen wie Wasser, Energie oder Verkehr als Grundlage gesellschaftlicher Funktionsfähigkeit verstanden werden.

## 19. Kapitel 12 - Internationale Anschlussfähigkeit

Rang 18 ist international anschlussfähig, weil er an UNESCO Open Science, CoARA, DORA, OECD-Missionen, EU Missions, ERA, Horizon Europe und EU-Wissensvalorisierung anknüpft. Die Wirkungsökonomie übersetzt diese Rahmen in eine gemeinsame Architektur aus Daten, Methoden, Wirkung, Rechtsschutz und Rückkopplung.

## 20. Kapitel 13 - Umsetzungspfad

Der Umsetzungspfad beginnt mit Pilotprogrammen an Hochschulen, Kommunen und Förderinstitutionen. Danach folgen Forschungs-Scorecards, Replikationsbudgets, Datenqualitätsklassen, Open-Science-Mindeststandards, Science-for-Policy-Leitlinien, Toolkarten und jährliche Wirkungsberichte. Jede Stufe muss evaluiert und korrigierbar bleiben.

## 21. Kapitel 14 - Abgrenzung

Rang 18 ist keine Planwirtschaft der Wissenschaft, keine Nützlichkeitspflicht für jede Erkenntnis und kein Angriff auf Grundlagenforschung. Grundlagenforschung ist in der Wirkungsökonomie besonders geschützt, weil ihre Wirkung oft verzögert, indirekt und unvorhersehbar ist. Gerade deshalb braucht sie Freiheit, Langfristigkeit und Vertrauen.

## 22. Politische Anschlussfähigkeit - Aufgabe der Politik

Politik muss Wissenschaftsfreiheit schützen, Forschungsdaten zugänglich machen, Integrität sichern, öffentliche Statistik stärken und Forschung so fördern, dass Wissen in positive Netto-Wirkung übersetzt werden kann.

## 23. Politische Anschlussfähigkeit - Politische Rahmenbedingungen

Erforderlich sind Open-Science-Regeln, Forschungsintegritätsstellen, Reformen der Forschungsbewertung, Replikationsfonds, faire Förderlogiken, Schutz vor Lobbyeinfluss, unabhängige Statistik und transparente Science-for-Policy-Prozesse.

## 24. Politische Anschlussfähigkeit - Ausgestaltungsspielraum

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext. Parteien können unterschiedliche Schwerpunkte setzen: Grundlagenforschung, missionsorientierte Forschung, Transfer, Open Science, Hochschulfinanzierung, Forschungsinfrastrukturen oder Innovationsfonds.

## 25. Politische Anschlussfähigkeit - Zielkonflikte

Wissenschaftsfreiheit vs. Missionsorientierung, Open Data vs. Datenschutz, schnelle Innovation vs. Sicherheit, Transfer vs. Unabhängigkeit, Exzellenz vs. Breitenzugang, globale Offenheit vs. Forschungssicherheit.

## 26. Politische Anschlussfähigkeit - Rollenverteilung

Bund und Länder sichern Finanzierung, Recht und Infrastrukturen. Wissenschaft prüft Wirklichkeit. Gerichte schützen Rechtsschutz. Verwaltung nutzt Evidenz. Unternehmen und Zivilgesellschaft bringen Praxiswissen ein, ohne Wissenschaft zu vereinnahmen.

## 27. Politische Anschlussfähigkeit - Übergang und Schutz

Einführung über Pilotprogramme, freiwillige Scorecards, unabhängige Evaluierung, Datenschutz, Ethik, Einspruchsrechte und Schutz wissenschaftlicher Minderheitenpositionen.

## 28. Politische Anschlussfähigkeit - Evaluation und Korrektur

Alle Instrumente müssen regelmäßig auf Wirkung, Fehlanreize, Bürokratie, Exklusion, Machtkonzentration und Methodenqualität geprüft werden.

## 29. Politische Anschlussfähigkeit - Schutz vor Technokratie

Wissenschaft ersetzt keine Demokratie. Sie macht Wirklichkeit, Unsicherheit und Folgen prüfbar. Politische Entscheidungen bleiben demokratische Entscheidungen.

## 30. SDG 4 - Hochwertige Bildung

Wissenschaft und Forschung stärken Bildung, Wirkungskompetenz, kritisches Denken und lebenslanges Lernen.

## 31. SDG 5 - Geschlechtergleichstellung

Forschungszugang, Karrieren, Daten und Innovationen müssen geschlechtergerecht und diskriminierungsarm gestaltet werden.

## 32. SDG 8 - Menschenwürdige Arbeit

Wissenschaft erzeugt Zukunftsarbeit, Qualifikation und faire Transformationspfade, darf aber keine Prekarität in Forschungsstrukturen verstärken.

## 33. SDG 9 - Industrie, Innovation und Infrastruktur

Rang 18 übersetzt Forschung in wirkungsorientierte Innovation, Infrastruktur und offene Wissenssysteme.

## 34. SDG 10 - Weniger Ungleichheiten

Open Science, gerechte Datenzugänge und inklusive Forschung reduzieren Wissens- und Innovationsungleichheit.

## 35. SDG 13 - Klimaschutz

Klimaforschung, Transformationsforschung und missionsorientierte Innovation sind zentrale Hebel gegen Klimarisiken.

## 36. SDG 16 - Frieden, Gerechtigkeit und starke Institutionen

Wissenschaftliche Integrität, öffentliche Statistik, Rechtsprechung und Quellenklarheit schützen demokratische Entscheidungsfähigkeit.

## 37. SDG 17 - Partnerschaften

Forschung wirkt durch internationale Kooperation, Datenräume, transdisziplinäre Netzwerke und globale Wissenspartnerschaften.

## Quellen und Referenzrahmen

- Interne WÖk-Referenz: Systemmodell der Wirkungsökonomie: Spalte 9 beschreibt Wissen, Innovation und Digitalisierung als intellektuelles Betriebssystem der Gesellschaft: Wissenschaft liefert Wahrheit, Bildung befähigt Freiheit, Innovation ist evolutionäres Systemlernen und Digitalisierung verbindet die Architektur.

- Interne WÖk-Referenz: Die neue Ordnung des Wohlstands, Teil XIV: Wissenschaft ist kein Wahrheitsmonopol, sondern ein Korrektursystem. Die Justiz wird als Freiheitsgarantie und Korrekturinstanz einer Wirkungsordnung beschrieben.

- UNESCO: UNESCO Recommendation on Open Science, 2021: internationaler Rahmen für Open Science, Transparenz, Zusammenarbeit und Zugänglichkeit wissenschaftlichen Wissens.

- CoARA: Agreement on Reforming Research Assessment, 2022: gemeinsame Richtung zur Reform von Bewertungspraktiken für Forschung, Forschende und Forschungseinrichtungen mit Fokus auf Qualität und Wirkung.

- DORA: San Francisco Declaration on Research Assessment: Initiative zur Verbesserung der Bewertung wissenschaftlicher Forschung und Forschender, insbesondere gegen eine Verengung auf Journalmetriken.

- OECD: Mission-Oriented Innovation Policies Toolkit: politische Instrumente zur Gestaltung, Governance und Umsetzung missionsorientierter Innovationspolitik.

- Europäische Kommission: EU Missions in Horizon Europe: große Initiativen mit klaren, zeitgebundenen Zielen für gesellschaftliche Herausforderungen wie Klima, Krebs, Ozeane, Böden und klimaneutrale Städte.

- Europäische Kommission: Guiding Principles for Knowledge Valorisation, 2022: Forschungsergebnisse sollen in gesellschaftlich nützliche Lösungen, Dienste, Produkte und Politik übersetzt werden.