
WOeK Rang 19 - Internationale Ordnung, Globalisierung und Geopolitik
Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Vollständiges Paket mit PDF, DOCX, Markdown, HTML, JSON und CodeX-Anweisung.

Inhalt:
- Gesamtpaket-PDF und Gesamtpaket-DOCX
- Konzeptpapier
- Gesamtdossier
- 10 Detailkonzepte als Langfassungsentwürfe
- Wirkungsindikatoren
- Toolkarten
- SDG-/SDG+-Block
- politische Anschlussfähigkeit
- Quellen und Glossarlinks
- Buchanker und Querverlinkungen
- CodeX-WebSite-Anweisung

Hinweis:
Alle öffentlichen Inhalte verwenden die Begriffslogik der Wirkungsökonomie: Wirkung ist neutral und relational. Bewertet wird am Referenzrahmen SDGs, Agenda 2030 und SDG+. Ziel ist positive Netto-Wirkung für Mensch, Planet und Demokratie.
