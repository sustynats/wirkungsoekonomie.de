# Buchanker und Querverlinkungen Rang 19

Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Buchanker und Querverlinkungen Rang 19

Rang 19 wird im Buch "Die neue Ordnung des Wohlstands" durch Teil XV getragen. Die Kapitel 91 bis 96 bilden den Buchanker: Europa als Wirkungsraum, Handel und Lieferketten, globale Institutionen, kulturelle Anschlussfähigkeit, globale Resilienz und Wirkungsökonomie als weltfähige Ordnung.

### Querverlinkungen

- Staat, Recht & Demokratie
- Finanzsystem & Kapital
- Wirtschaft & Unternehmen
- Klima, Energie & Ressourcen
- Migration & Vielfalt
- Sicherheit & Resilienz
- Digitalisierung, KI und Wirkungsdatenräume
- Wissen, Wissenschaft und Wirkungsinnovation
- Medien & Öffentlichkeit
- Arbeit & Einkommen
- Produkte & Konsum

### Quellen und Anschlussrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XV: Internationale Ordnung, Globalisierung und Geopolitik, Kapitel 91 bis 96.

Weber, Natalie: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development, Resolution A/RES/70/1, 2015. https://sdgs.un.org/2030agenda

European Commission: Carbon Border Adjustment Mechanism, definitive regime from 2026 after transitional phase 2023 to 2025. https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en

World Trade Organization: The WTO deals with the global rules of trade between nations. https://www.wto.org/

World Trade Organization: The WTO and the Sustainable Development Goals. https://www.wto.org/english/thewto_e/coher_e/sdgs_e/sdgs_e.htm

OECD: Development co-operation and the provision of global public goods, 2023. https://www.oecd.org/en/publications/development-co-operation-and-the-provision-of-global-public-goods_aff8cba9-en.html

UNDP: Sustainable Development Goals as integrated global goals. https://www.undp.org/sustainable-development-goals
