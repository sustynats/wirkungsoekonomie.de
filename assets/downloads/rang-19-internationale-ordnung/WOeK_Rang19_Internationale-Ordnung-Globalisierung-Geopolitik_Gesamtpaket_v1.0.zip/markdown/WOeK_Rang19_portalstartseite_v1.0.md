# Portalstartseite Rang 19 - Internationale Ordnung, Globalisierung und Geopolitik

Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Internationale Ordnung, Globalisierung und Geopolitik

Rang 19 übersetzt die Wirkungsökonomie auf die internationale Ebene. Wirkung endet nicht an Grenzen. Produkte, Kapital, Daten, Energie, Rohstoffe, Emissionen, Desinformation, Migration, Lieferketten und Sicherheitsrisiken wirken grenzüberschreitend. Deshalb braucht die Wirkungsökonomie eine weltfähige, aber nicht weltbeherrschende Ordnung.

Weltfähig bedeutet: anschlussfähig, übersetzbar, interoperabel, demokratisch begrenzt, wissenschaftlich prüfbar und kulturell nicht-dominant. Die Wirkungsökonomie wird nicht global, indem überall identische Institutionen entstehen. Sie wird global, wenn dieselbe Grundfrage in unterschiedlichen Kontexten stellbar wird: Welche Wirkung entsteht wirklich für Mensch, Planet und Demokratie?

### Portalstruktur

- Konzeptpapier
- Gesamtdossier
- Europa als Wirkungsraum
- Wirkungsbasierter Handel und Lieferketten
- CBAM, Grenzausgleich und externe Kosten
- Globale Wirkungsgovernance ohne Weltregierung
- Klimagerechtigkeit und Ressourcenfairness
- Multipolare Ordnung und kulturelle Anschlussfähigkeit
- Globale Resilienz und Frühwarnkooperation
- Entwicklungspartnerschaften und Wirkungsfonds
- Globale WÖk-IDs, Datenstandards und Interoperabilität
- Geopolitische Wirkungsrisiken, Desinformation und Demokratie

### Leitgedanke

Globale Kooperation ist nicht dasselbe wie globale Herrschaft. Gemeinsame Maßstäbe schaffen Orientierung, Vergleichbarkeit und Rückkopplung. Politische Entscheidungen bleiben demokratisch, lokal übersetzbar und rechtlich begrenzt.

### SDG- und SDG+-Bezug

Rang 19 ist besonders stark mit SDG 16 und SDG 17 verbunden, weil Frieden, Rechtsstaatlichkeit, starke Institutionen und Partnerschaften zentrale Bedingungen einer weltfähigen Wirkungsordnung sind. Zugleich berührt internationale Ordnung nahezu alle SDGs: Klima, Wasser, Energie, Arbeit, Ungleichheit, Produktion, Städte, Biodiversität, Gesundheit und Bildung.

SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie. Sie ergänzt Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

- SDG 1: Armutsbekämpfung und faire Entwicklungsbedingungen.
- SDG 2: Ernährungssicherheit, resiliente Lieferketten und Krisenvorsorge.
- SDG 6: Wasserstress, Nutzungskonflikte und globale Wasserwirkung.
- SDG 7: Energiezugang, Versorgungssicherheit und faire Transformation.
- SDG 8: menschenwürdige Arbeit in globalen Wertschöpfungsketten.
- SDG 10: weniger Ungleichheiten zwischen und innerhalb von Staaten.
- SDG 12: nachhaltige Produktion und Konsum entlang globaler Lieferketten.
- SDG 13: Klimaschutz, Anpassung und Klimagerechtigkeit.
- SDG 16: Frieden, Rechtsstaatlichkeit, Institutionen und Schutz vor Korruption.
- SDG 17: Partnerschaften, Standards, Daten, Finanzierung und internationale Kooperation.

### Politische Anschlussfähigkeit und Umsetzungsoptionen

Die Wirkungsökonomie liefert keinen fertigen außenpolitischen Parteiprogrammtext. Sie liefert einen Bewertungs- und Steuerungsrahmen, der sichtbar macht, welche internationale Ordnung positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugt und wo negative Wirkungen ausgelagert werden.

Parteien behalten Ausgestaltungsspielraum bei Handelspolitik, Entwicklungspolitik, Sicherheitsarchitektur, Europa, Migration, Rohstoffstrategie, Klimafinanzierung, Industriepolitik und digitaler Souveränität. Entscheidend ist nicht die parteipolitische Richtung, sondern die überprüfbare Wirkung.

- Aufgabe der Politik: globale Wirkungen sichtbar machen, ohne nationale Demokratie zu ersetzen.
- Rahmenbedingungen: Rechtsstaat, Menschenrechte, internationale Abkommen, EU-Recht, WTO-Regeln, SDGs, SDG+ und Schutz öffentlicher Güter.
- Zielkonflikte: offene Märkte versus Schutz vor externalisierten Schäden, geopolitische Sicherheit versus Kooperation, kulturelle Übersetzung versus klare Schutzgüter.
- Rollenverteilung: Staaten setzen Regeln, Institutionen prüfen, Unternehmen berichten, Wissenschaft validiert, Zivilgesellschaft kontrolliert, Kommunen und Regionen übersetzen vor Ort.
- Schutz vor Technokratie: keine Weltregierung, keine Personenbewertung, keine verdeckte Datenherrschaft, keine Expertokratie.
- Evaluation: Indikatoren müssen öffentlich, korrigierbar, versioniert und demokratisch kontrolliert sein.

### Quellen und Anschlussrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XV: Internationale Ordnung, Globalisierung und Geopolitik, Kapitel 91 bis 96.

Weber, Natalie: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development, Resolution A/RES/70/1, 2015. https://sdgs.un.org/2030agenda

European Commission: Carbon Border Adjustment Mechanism, definitive regime from 2026 after transitional phase 2023 to 2025. https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en

World Trade Organization: The WTO deals with the global rules of trade between nations. https://www.wto.org/

World Trade Organization: The WTO and the Sustainable Development Goals. https://www.wto.org/english/thewto_e/coher_e/sdgs_e/sdgs_e.htm

OECD: Development co-operation and the provision of global public goods, 2023. https://www.oecd.org/en/publications/development-co-operation-and-the-provision-of-global-public-goods_aff8cba9-en.html

UNDP: Sustainable Development Goals as integrated global goals. https://www.undp.org/sustainable-development-goals
