# SDG- und SDG+-Block Rang 19

Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## SDG- und SDG+-Block Rang 19

### SDG- und SDG+-Bezug

Rang 19 ist besonders stark mit SDG 16 und SDG 17 verbunden, weil Frieden, Rechtsstaatlichkeit, starke Institutionen und Partnerschaften zentrale Bedingungen einer weltfähigen Wirkungsordnung sind. Zugleich berührt internationale Ordnung nahezu alle SDGs: Klima, Wasser, Energie, Arbeit, Ungleichheit, Produktion, Städte, Biodiversität, Gesundheit und Bildung.

SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie. Sie ergänzt Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

- SDG 1: Armutsbekämpfung und faire Entwicklungsbedingungen.
- SDG 2: Ernährungssicherheit, resiliente Lieferketten und Krisenvorsorge.
- SDG 6: Wasserstress, Nutzungskonflikte und globale Wasserwirkung.
- SDG 7: Energiezugang, Versorgungssicherheit und faire Transformation.
- SDG 8: menschenwürdige Arbeit in globalen Wertschöpfungsketten.
- SDG 10: weniger Ungleichheiten zwischen und innerhalb von Staaten.
- SDG 12: nachhaltige Produktion und Konsum entlang globaler Lieferketten.
- SDG 13: Klimaschutz, Anpassung und Klimagerechtigkeit.
- SDG 16: Frieden, Rechtsstaatlichkeit, Institutionen und Schutz vor Korruption.
- SDG 17: Partnerschaften, Standards, Daten, Finanzierung und internationale Kooperation.

### Quellen und Anschlussrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XV: Internationale Ordnung, Globalisierung und Geopolitik, Kapitel 91 bis 96.

Weber, Natalie: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development, Resolution A/RES/70/1, 2015. https://sdgs.un.org/2030agenda

European Commission: Carbon Border Adjustment Mechanism, definitive regime from 2026 after transitional phase 2023 to 2025. https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en

World Trade Organization: The WTO deals with the global rules of trade between nations. https://www.wto.org/

World Trade Organization: The WTO and the Sustainable Development Goals. https://www.wto.org/english/thewto_e/coher_e/sdgs_e/sdgs_e.htm

OECD: Development co-operation and the provision of global public goods, 2023. https://www.oecd.org/en/publications/development-co-operation-and-the-provision-of-global-public-goods_aff8cba9-en.html

UNDP: Sustainable Development Goals as integrated global goals. https://www.undp.org/sustainable-development-goals
