# Bestands- und Nachlieferliste Rang 19

Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Bestands- und Nachlieferliste Rang 19

Rang 19 besitzt einen starken Buchanker in Teil XV der Arbeitsfassung 2026. Dieser Buchanker reicht aber nicht aus, um Website, Akademie, Downloads, Toolkarten und Onlinefassungen vollständig abzudecken. Deshalb wird der Portalbereich als eigenständiger Fachblock im Dossier-Niveau aufgebaut.

| Baustein | Vorhandene Grundlage | Status | Nachlieferung |
| --- | --- | --- | --- |
| Portalstartseite | Teil XV Buchanker | neu erstellt | Onlinefassung, Downloads, Toolkarten, SDG-/SDG+-Block |
| Konzeptpapier | Kapitel 91 bis 96 | ausgebaut | Langfassung mit politischer Anschlussfähigkeit |
| Gesamtdossier | Teil XV | neu als Dossier | Fachkapitel, Beispiele, Indikatoren, Umsetzung |
| Detailkonzepte | im Buch angerissen | neu erstellt | 10 Langfassungsentwürfe |
| Downloads | nicht ausreichend | neu erstellt | PDF, DOCX, Markdown, HTML, ZIP |
| Toolkarten | noch nicht vollständig | neu erstellt | Beschreibung, Nutzen, Zielgruppe, Status, Link |
| SDG-/SDG+ | begrifflich vorhanden | ausgebaut | internationaler Referenzblock |
| Politische Anschlussfähigkeit | Pflichtblock | neu erstellt | für alle Wirkungsfeldseiten |

### Qualitätsentscheidung

Rang 19 darf nicht als geopolitischer Kommentar erscheinen. Er ist ein Wirkungsfeld der internationalen Ordnung. Der Maßstab ist nicht nationale Macht, nicht moralische Überlegenheit und nicht naive Globalisierung, sondern positive Netto-Wirkung für Mensch, Planet und Demokratie.

### Politische Anschlussfähigkeit und Umsetzungsoptionen

Die Wirkungsökonomie liefert keinen fertigen außenpolitischen Parteiprogrammtext. Sie liefert einen Bewertungs- und Steuerungsrahmen, der sichtbar macht, welche internationale Ordnung positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugt und wo negative Wirkungen ausgelagert werden.

Parteien behalten Ausgestaltungsspielraum bei Handelspolitik, Entwicklungspolitik, Sicherheitsarchitektur, Europa, Migration, Rohstoffstrategie, Klimafinanzierung, Industriepolitik und digitaler Souveränität. Entscheidend ist nicht die parteipolitische Richtung, sondern die überprüfbare Wirkung.

- Aufgabe der Politik: globale Wirkungen sichtbar machen, ohne nationale Demokratie zu ersetzen.
- Rahmenbedingungen: Rechtsstaat, Menschenrechte, internationale Abkommen, EU-Recht, WTO-Regeln, SDGs, SDG+ und Schutz öffentlicher Güter.
- Zielkonflikte: offene Märkte versus Schutz vor externalisierten Schäden, geopolitische Sicherheit versus Kooperation, kulturelle Übersetzung versus klare Schutzgüter.
- Rollenverteilung: Staaten setzen Regeln, Institutionen prüfen, Unternehmen berichten, Wissenschaft validiert, Zivilgesellschaft kontrolliert, Kommunen und Regionen übersetzen vor Ort.
- Schutz vor Technokratie: keine Weltregierung, keine Personenbewertung, keine verdeckte Datenherrschaft, keine Expertokratie.
- Evaluation: Indikatoren müssen öffentlich, korrigierbar, versioniert und demokratisch kontrolliert sein.

### Quellen und Anschlussrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XV: Internationale Ordnung, Globalisierung und Geopolitik, Kapitel 91 bis 96.

Weber, Natalie: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development, Resolution A/RES/70/1, 2015. https://sdgs.un.org/2030agenda

European Commission: Carbon Border Adjustment Mechanism, definitive regime from 2026 after transitional phase 2023 to 2025. https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en

World Trade Organization: The WTO deals with the global rules of trade between nations. https://www.wto.org/

World Trade Organization: The WTO and the Sustainable Development Goals. https://www.wto.org/english/thewto_e/coher_e/sdgs_e/sdgs_e.htm

OECD: Development co-operation and the provision of global public goods, 2023. https://www.oecd.org/en/publications/development-co-operation-and-the-provision-of-global-public-goods_aff8cba9-en.html

UNDP: Sustainable Development Goals as integrated global goals. https://www.undp.org/sustainable-development-goals
