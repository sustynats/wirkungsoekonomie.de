# Gesamtdossier Rang 19 - Internationale Ordnung, Globalisierung und Geopolitik

Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Gesamtdossier Rang 19

Das Gesamtdossier fasst den Fachbereich Internationale Ordnung, Globalisierung und Geopolitik im Rahmen der Wirkungsökonomie zusammen. Es zeigt, wie globale Verflechtungen so gelesen werden können, dass ausgelagerte Schäden, verdeckte Abhängigkeiten, Machtasymmetrien und gemeinsame Schutzgüter sichtbar werden.

### 1. Wirkung endet nicht an Grenzen

Ein Produkt kann in Europa verkauft werden, aber seine Wasserwirkung in Chile, seine Arbeitswirkung in Bangladesch, seine Rohstoffwirkung im Kongo, seine Klimawirkung global und seine Kapitalwirkung in Finanzzentren entfalten. Diese räumliche Trennung von Konsum, Produktion, Kapital und Wirkung ist eine zentrale Ursache globaler Blindheit.

Wirkungsökonomie macht diese räumliche Trennung nicht moralisch pauschal schlecht. Globale Arbeitsteilung kann Wohlstand, Zugang, Innovation und Kooperation erzeugen. Aber sie wird gefährlich, wenn negative Wirkungen unsichtbar bleiben und positive Wirkungen nicht fair geteilt werden.

### 2. Europa als Wirkungsraum

Europa kann eine besondere Rolle einnehmen, weil es Binnenmarkt, Rechtsstaat, Standardsetzung, Berichtspflichten, Datenschutz, Klima- und Industriepolitik verbindet. Diese Rolle ist aber nur legitim, wenn Standards nicht als Herrschaftsinstrument, sondern als offene, überprüfbare und für Dritte anschlussfähige Wirkungsinfrastruktur gestaltet werden.

### 3. Handel als Wirkungsverlagerung

Handel transportiert nicht nur Güter. Er transportiert Wirkungen. Wenn Märkte nur Preise sehen, während Wasserstress, Arbeitsbedingungen, Emissionen, Gesundheitsrisiken oder Demokratiewirkungen unsichtbar bleiben, entsteht ein globaler Wettbewerb um Externalisierung. Wirkungsbasierter Handel dreht diese Logik um.

### 4. Globale Governance ohne Weltregierung

Die Wirkungsökonomie unterscheidet globale Kooperation von globaler Herrschaft. Sie braucht gemeinsame Maßstäbe, aber keine zentrale Weltinstanz, die politische Entscheidungen ersetzt. Polyzentrische Governance bedeutet: viele Institutionen, offene Daten, geteilte Standards, lokale Übersetzung und demokratische Kontrolle.

### 5. Multipolare Ordnung

Eine multipolare Welt ist weder automatisch stabil noch automatisch gefährlich. Sie verlangt neue Übersetzungsformen. Unterschiedliche Werteordnungen müssen ernst genommen werden. Gleichzeitig dürfen Würdeverletzung, Korruption, Desinformation, autoritäre Willkür oder ökologische Zerstörung nicht als Kultur relativiert werden.

### 6. Globale Resilienz

Globale Resilienz schützt kritische Wirkungsbedingungen: Klima, Wasser, Ernährung, Gesundheit, Energie, Daten, Lieferketten, Medienqualität, Demokratie und öffentliche Wahrheit. Sie ist nicht Isolation, sondern Lern-, Anpassungs- und Kooperationsfähigkeit.

### 7. Instrumente

- Globale WÖk-ID-Mappinglogik für Produkte, Lieferketten, Kapital und öffentliche Güter.
- Wirkungsbasierte Handels- und Beschaffungsregeln.
- Grenzausgleich bei externalisierten Schäden.
- Wirkungsfonds für globale öffentliche Güter.
- Frühwarnsysteme für Wasser, Klima, Ernährung, Gesundheit, Lieferketten und Demokratie.
- Polyzentraler Wirkungsrat-Verbund mit regionalen Kontroll- und Übersetzungsinstanzen.
- Offene Datenstandards und Interoperabilität ohne Datenmonopole.

### 8. Risiken

Jede globale Wirkungsordnung kann missbraucht werden. Risiken sind Datenherrschaft, westliche Dominanz, Technokratie, politische Vereinnahmung, Scheingenauigkeit, Ausschluss kleiner Akteure, Überwachung, Greenwashing und geopolitische Instrumentalisierung. Deshalb braucht Rang 19 starke Schutzmechanismen.

### 9. Umsetzungspfad

Die Umsetzung sollte lokal beginnen, aber global anschlussfähig gebaut werden: Pilot-Lieferketten, öffentliche Beschaffung, EU-Standardräume, Wirkungspartnerschaften, Entwicklungsfonds, offene Indikatoren, wissenschaftliche Validierung und jährliche Wirkungsberichte.

### Europa als Wirkungsraum

Europa ist in Rang 19 kein moralischer Exporteur und kein bloßer Binnenmarkt, sondern ein Wirkungsraum, in dem Markt, Recht, Daten, Demokratie, Standards und Kapitalflüsse miteinander rückgekoppelt werden können.

Ein europäischer Produktstandard wirkt nicht nur in Europa. Er verändert Lieferketten, Investitionen, Messsysteme, Beschaffung und industrielle Pfade weltweit. Genau deshalb muss Europa Standards setzen, ohne sie als Herrschaftsinstrument zu verwenden.

- Interoperabilität europäischer Standards
- Zugang kleiner Unternehmen zu Wirkungsdaten
- Wirkung von EU-Binnenmarktregeln auf Drittstaaten
- Demokratische Kontrolle von Standardsetzung

### Wirkungsbasierter Handel und Lieferketten

Handel ist nicht nur Warenaustausch, sondern Wirkungsverlagerung. Ein Produkt kann in einem Land gekauft werden und seine Wasser-, Arbeits-, Rohstoff-, Klima- und Demokratiewirkung in anderen Räumen entfalten.

Ein T-Shirt kann im europäischen Regal billig erscheinen, während Wasserstress, niedrige Löhne, Energieemissionen und Chemikalienrisiken in anderen Ländern unsichtbar bleiben. Wirkungsbasierter Handel macht diese Verlagerung sichtbar.

- Lieferketten-Transparenz
- Living-Wage-Abdeckung
- Wasserstress in Vorstufen
- Scope-3-Datenqualität
- Anteil wirkungspositiver Vorleistungen

### CBAM, Grenzausgleich und externe Kosten

Grenzausgleich wird in der Wirkungsökonomie nicht als protektionistische Abwehr verstanden, sondern als Frage, ob ausgelagerte Wirkungen an der Grenze unsichtbar bleiben oder fair rückgekoppelt werden.

Der europäische CBAM zeigt, dass importierte Emissionen nicht länger vollständig außerhalb der Preislogik bleiben müssen. Die Wirkungsökonomie erweitert diese Logik auf Arbeit, Wasser, Biodiversität, Demokratie und Datenintegrität.

- Eingebettete Emissionen
- Zertifikatspflichten
- Datenqualität bei Importen
- Ausgleichsmechanismen für kleine Anbieter
- Schutz vor Carbon Leakage

### Globale Wirkungsgovernance ohne Weltregierung

Globale Wirkungsgovernance bedeutet nicht Weltregierung. Sie bedeutet polyzentrische Kooperation zwischen Staaten, Institutionen, Wissenschaft, Wirtschaft, Zivilgesellschaft und Standardsystemen.

UN, WTO, OECD, ILO, WHO, IPCC, IPBES, Entwicklungsbanken und regionale Organisationen können gemeinsame Bezugspunkte liefern, ohne nationale oder demokratische Entscheidung zu ersetzen.

- Transparenz internationaler Standards
- Beteiligung betroffener Regionen
- Offene Datenzugänge
- demokratische Kontrolle
- Rechenschaftspflichten

### Klimagerechtigkeit und Ressourcenfairness

Klimagerechtigkeit und Ressourcenfairness verbinden historische Verantwortung, gegenwärtige Verwundbarkeit, Rohstoffabhängigkeit, technologische Teilgabe und faire Finanzierung.

Ein Land mit geringer historischer Emission kann stark von Klimafolgen betroffen sein. Wirkungsökonomie macht diese asymmetrische Belastung sichtbar und überführt sie in Finanzierung, Partnerschaften und Risikoausgleich.

- Historische Emissionsverantwortung
- Klimaverwundbarkeit
- Rohstoffabhängigkeit
- Anteil lokaler Wertschöpfung
- Zugang zu Transformationsfinanzierung

### Multipolare Ordnung und kulturelle Anschlussfähigkeit

Eine weltfähige Wirkungsökonomie muss übersetzbar sein. Sie darf keine westliche Belehrungsordnung werden und darf Kultur zugleich nicht zur Rechtfertigung von Würdeverletzung, Korruption oder ökologischer Zerstörung machen.

Unterschiedliche politische und kulturelle Ordnungen können unterschiedliche Wege zu Schutz, Teilgabe und Regeneration wählen. Der Maßstab bleibt Wirkung auf Mensch, Planet und Demokratie.

- Lokale Übersetzung gemeinsamer Indikatoren
- Schutz von Menschenwürde
- Pluralität der Beteiligung
- Datenhoheit lokaler Akteure
- Risiko kultureller Dominanz

### Globale Resilienz und Frühwarnkooperation

Globale Resilienz ist die Fähigkeit, Krisen früh zu erkennen, Grundfunktionen zu schützen, Folgen zu begrenzen und aus Störungen zu lernen, ohne in Abschottung oder Sicherheitsstaatlichkeit zu kippen.

Wasserstress, Preisvolatilität, Gesundheitscluster, digitale Angriffe, Lieferverzögerungen, Versicherungsrückzug und Desinformation sind schwache Signale, die globale Wirkungsrückkopplung brauchen.

- Klimarisiko
- Wasserstress
- Ernährungsverwundbarkeit
- Pandemiefähigkeit
- Cyberresilienz
- Versicherbarkeit
- soziale Kohäsion

### Entwicklungspartnerschaften und Wirkungsfonds

Entwicklungspartnerschaften werden wirkungsökonomisch nicht als Hilfe von oben verstanden, sondern als gemeinsame Investitionen in globale öffentliche Güter, lokale Wertschöpfung und Teilgabe.

Ein Wirkungsfonds kann Klimaanpassung, Gesundheit, lokale Energie, Bildung und Dateninfrastruktur finanzieren, wenn klare Schutzgüter, lokale Beteiligung und Rückkopplung vereinbart sind.

- Lokale Ownership
- Wirkungsfinanzierung je Schutzgut
- Anteil lokaler Wertschöpfung
- Kofinanzierung
- Transparenz der Mittelverwendung

### Globale WÖk-IDs, Datenstandards und Interoperabilität

Weltfähigkeit braucht gemeinsame Sprache. Globale WÖk-IDs, Datenstandards und Interoperabilität schaffen Vergleichbarkeit, ohne lokale Unterschiede zu löschen.

Eine WÖk-ID für Wasserstress muss global verständlich, lokal kontextualisierbar und auditierbar sein. Sonst entstehen Datenmonopole oder falsche Vergleichbarkeit.

- Datenqualität
- Interoperabilität
- Auditierbarkeit
- Zugang für kleine Akteure
- Schutz vor Datenmonopolen

### Geopolitische Wirkungsrisiken, Desinformation und Demokratie

Geopolitik wirkt nicht nur über Armeen und Grenzen, sondern über Kapital, Rohstoffe, Energie, Daten, Plattformen, Narrative, Lieferketten und institutionelles Vertrauen.

Eine Desinformationskampagne kann politische Entscheidungen, Impfbereitschaft, Klimapolitik, Migrationserzählungen oder Vertrauen in Institutionen beeinflussen. Sie ist ein globales Wirkungsrisiko.

- Desinformationsintensität
- Plattformtransparenz
- Rohstoffkonzentration
- Energieabhängigkeit
- Demokratievertrauen
- institutionelle Korrekturfähigkeit

### SDG- und SDG+-Bezug

Rang 19 ist besonders stark mit SDG 16 und SDG 17 verbunden, weil Frieden, Rechtsstaatlichkeit, starke Institutionen und Partnerschaften zentrale Bedingungen einer weltfähigen Wirkungsordnung sind. Zugleich berührt internationale Ordnung nahezu alle SDGs: Klima, Wasser, Energie, Arbeit, Ungleichheit, Produktion, Städte, Biodiversität, Gesundheit und Bildung.

SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie. Sie ergänzt Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

- SDG 1: Armutsbekämpfung und faire Entwicklungsbedingungen.
- SDG 2: Ernährungssicherheit, resiliente Lieferketten und Krisenvorsorge.
- SDG 6: Wasserstress, Nutzungskonflikte und globale Wasserwirkung.
- SDG 7: Energiezugang, Versorgungssicherheit und faire Transformation.
- SDG 8: menschenwürdige Arbeit in globalen Wertschöpfungsketten.
- SDG 10: weniger Ungleichheiten zwischen und innerhalb von Staaten.
- SDG 12: nachhaltige Produktion und Konsum entlang globaler Lieferketten.
- SDG 13: Klimaschutz, Anpassung und Klimagerechtigkeit.
- SDG 16: Frieden, Rechtsstaatlichkeit, Institutionen und Schutz vor Korruption.
- SDG 17: Partnerschaften, Standards, Daten, Finanzierung und internationale Kooperation.

### Politische Anschlussfähigkeit und Umsetzungsoptionen

Die Wirkungsökonomie liefert keinen fertigen außenpolitischen Parteiprogrammtext. Sie liefert einen Bewertungs- und Steuerungsrahmen, der sichtbar macht, welche internationale Ordnung positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugt und wo negative Wirkungen ausgelagert werden.

Parteien behalten Ausgestaltungsspielraum bei Handelspolitik, Entwicklungspolitik, Sicherheitsarchitektur, Europa, Migration, Rohstoffstrategie, Klimafinanzierung, Industriepolitik und digitaler Souveränität. Entscheidend ist nicht die parteipolitische Richtung, sondern die überprüfbare Wirkung.

- Aufgabe der Politik: globale Wirkungen sichtbar machen, ohne nationale Demokratie zu ersetzen.
- Rahmenbedingungen: Rechtsstaat, Menschenrechte, internationale Abkommen, EU-Recht, WTO-Regeln, SDGs, SDG+ und Schutz öffentlicher Güter.
- Zielkonflikte: offene Märkte versus Schutz vor externalisierten Schäden, geopolitische Sicherheit versus Kooperation, kulturelle Übersetzung versus klare Schutzgüter.
- Rollenverteilung: Staaten setzen Regeln, Institutionen prüfen, Unternehmen berichten, Wissenschaft validiert, Zivilgesellschaft kontrolliert, Kommunen und Regionen übersetzen vor Ort.
- Schutz vor Technokratie: keine Weltregierung, keine Personenbewertung, keine verdeckte Datenherrschaft, keine Expertokratie.
- Evaluation: Indikatoren müssen öffentlich, korrigierbar, versioniert und demokratisch kontrolliert sein.

### Quellen und Anschlussrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XV: Internationale Ordnung, Globalisierung und Geopolitik, Kapitel 91 bis 96.

Weber, Natalie: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development, Resolution A/RES/70/1, 2015. https://sdgs.un.org/2030agenda

European Commission: Carbon Border Adjustment Mechanism, definitive regime from 2026 after transitional phase 2023 to 2025. https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en

World Trade Organization: The WTO deals with the global rules of trade between nations. https://www.wto.org/

World Trade Organization: The WTO and the Sustainable Development Goals. https://www.wto.org/english/thewto_e/coher_e/sdgs_e/sdgs_e.htm

OECD: Development co-operation and the provision of global public goods, 2023. https://www.oecd.org/en/publications/development-co-operation-and-the-provision-of-global-public-goods_aff8cba9-en.html

UNDP: Sustainable Development Goals as integrated global goals. https://www.undp.org/sustainable-development-goals
