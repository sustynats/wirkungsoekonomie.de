# Toolkarten Rang 19

Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Toolkarten Rang 19

Die Toolkarten übersetzen Rang 19 in praktische Anwendungen. Keine Toolkarte bewertet Personen. Bewertet werden Strukturen, Programme, Lieferketten, Datenräume und institutionelle Wirkung.

### Global Impact Trade Mapper

Visualisiert, wo Produktwirkungen entlang internationaler Lieferketten entstehen.

| Feld | Inhalt |
| --- | --- |
| Nutzen | Wirkung sichtbar machen, Risiken prüfen und politische oder wirtschaftliche Entscheidungen verbessern. |
| Zielgruppe | Unternehmen, Beschaffung, Politik |
| Status | Demo in Vorbereitung |
| Link | /tools/global-impact-trade-mapper/ |

### Wirkungsbasierter Grenzausgleich-Check

Prüft, ob externe Kosten an Grenzen sichtbar gemacht und fair rückgekoppelt werden.

| Feld | Inhalt |
| --- | --- |
| Nutzen | Wirkung sichtbar machen, Risiken prüfen und politische oder wirtschaftliche Entscheidungen verbessern. |
| Zielgruppe | Finanzverwaltung, Handel, Unternehmen |
| Status | Demo in Vorbereitung |
| Link | /tools/wirkungsbasierter-grenzausgleich-check/ |

### Rohstoff- und Abhängigkeitsradar

Bewertet Konzentrations-, Lieferketten- und Machtwirkungen kritischer Rohstoffe.

| Feld | Inhalt |
| --- | --- |
| Nutzen | Wirkung sichtbar machen, Risiken prüfen und politische oder wirtschaftliche Entscheidungen verbessern. |
| Zielgruppe | Industrie, Finanzsystem, Politik |
| Status | Demo in Vorbereitung |
| Link | /tools/rohstoff-und-abhaengigkeitsradar/ |

### Globale Resilienz-Frühwarnkarte

Erfasst Wasser, Klima, Ernährung, Gesundheit, Lieferketten, Cyber und Demokratie als gekoppelte Risiken.

| Feld | Inhalt |
| --- | --- |
| Nutzen | Wirkung sichtbar machen, Risiken prüfen und politische oder wirtschaftliche Entscheidungen verbessern. |
| Zielgruppe | Staat, Kommunen, Forschung |
| Status | Demo in Vorbereitung |
| Link | /tools/globale-resilienz-fruehwarnkarte/ |

### SDG+/Demokratie-Risikomonitor

Macht mediale, institutionelle und demokratische Risiken internationaler Wirkungsräume sichtbar.

| Feld | Inhalt |
| --- | --- |
| Nutzen | Wirkung sichtbar machen, Risiken prüfen und politische oder wirtschaftliche Entscheidungen verbessern. |
| Zielgruppe | Medien, Politik, Zivilgesellschaft |
| Status | Demo in Vorbereitung |
| Link | /tools/sdg-demokratie-risikomonitor/ |

### Wirkungspartnerschafts-Score

Bewertet Entwicklungspartnerschaften nach lokaler Teilgabe, Datenhoheit, Wirkung und Fairness.

| Feld | Inhalt |
| --- | --- |
| Nutzen | Wirkung sichtbar machen, Risiken prüfen und politische oder wirtschaftliche Entscheidungen verbessern. |
| Zielgruppe | Entwicklungspolitik, NGOs, Fonds |
| Status | Demo in Vorbereitung |
| Link | /tools/wirkungspartnerschafts-score/ |

### WÖk-ID Interoperability Checker

Prüft, ob internationale Datenstandards, DPP und WÖk-IDs anschlussfähig und auditierbar sind.

| Feld | Inhalt |
| --- | --- |
| Nutzen | Wirkung sichtbar machen, Risiken prüfen und politische oder wirtschaftliche Entscheidungen verbessern. |
| Zielgruppe | Datenräume, Unternehmen, Standardsetzer |
| Status | Demo in Vorbereitung |
| Link | /tools/woek-id-interoperability-checker/ |

### Quellen und Anschlussrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XV: Internationale Ordnung, Globalisierung und Geopolitik, Kapitel 91 bis 96.

Weber, Natalie: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development, Resolution A/RES/70/1, 2015. https://sdgs.un.org/2030agenda

European Commission: Carbon Border Adjustment Mechanism, definitive regime from 2026 after transitional phase 2023 to 2025. https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en

World Trade Organization: The WTO deals with the global rules of trade between nations. https://www.wto.org/

World Trade Organization: The WTO and the Sustainable Development Goals. https://www.wto.org/english/thewto_e/coher_e/sdgs_e/sdgs_e.htm

OECD: Development co-operation and the provision of global public goods, 2023. https://www.oecd.org/en/publications/development-co-operation-and-the-provision-of-global-public-goods_aff8cba9-en.html

UNDP: Sustainable Development Goals as integrated global goals. https://www.undp.org/sustainable-development-goals
