# Konzeptpapier Rang 19 - Internationale Ordnung, Globalisierung und Geopolitik

Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Konzeptpapier Rang 19

Dieses Konzeptpapier beschreibt Rang 19 der Wirkungsökonomie: Internationale Ordnung, Globalisierung und Geopolitik. Es baut auf der Grundannahme auf, dass Wirkung nicht an Grenzen endet und dass globale Verflechtungen nur dann zukunftsfähig sind, wenn sie messbar, fair, demokratisch begrenzt und kulturell anschlussfähig gestaltet werden.

### Ausgangsproblem

Die klassische internationale Ordnung wird häufig als Machtordnung gelesen: Staaten konkurrieren um Einfluss, Ressourcen, Sicherheit, Märkte und Daten. Gleichzeitig werden globale Wirkungen in nationalen Bilanzen unsichtbar. Ein Importprodukt kann lokale Preise senken und zugleich Wasserstress, Arbeitsrisiken, Emissionen oder Biodiversitätsverluste in anderen Ländern erzeugen. Kapital kann Schäden verlagern. Plattformen können Desinformation grenzüberschreitend verstärken. Kriege können Energiepreise, Migration, Ernährung, Gesundheit, Versicherbarkeit und demokratische Stabilität in vielen Ländern gleichzeitig verändern.

Die Wirkungsökonomie setzt hier an. Sie fordert keine Weltregierung und keine globale Einheitsordnung. Sie fordert eine gemeinsame Sprache der Wirkung, mit der globale Externalitäten, Abhängigkeiten, Resilienzrisiken und Schutzgüter sichtbar werden.

### Leitprinzipien

- Weltfähig statt weltbeherrschend: globale Anschlussfähigkeit ohne Dominanzanspruch.
- Kooperation statt Herrschaft: gemeinsame Maßstäbe ersetzen nicht demokratische Aushandlung.
- Übersetzung statt Belehrung: kulturelle und institutionelle Unterschiede werden ernst genommen.
- Interoperabilität statt Datenmonopol: Standards müssen offen, prüfbar und zugänglich sein.
- Wirkungsbasierter Handel: Preise und Grenzregeln dürfen Schäden nicht unsichtbar machen.
- Globale Resilienz: Klima, Wasser, Ernährung, Gesundheit, Infrastruktur, Daten und Demokratie sind gekoppelte Stabilitätsbedingungen.

### Architektur des Portals

Das Portal verbindet Europa, Handel, Lieferketten, CBAM, globale Governance, Klimagerechtigkeit, Ressourcenfairness, multipolare Ordnung, globale Frühwarnsysteme, Entwicklungspartnerschaften, Datenstandards und geopolitische Wirkungsrisiken. Es bildet damit die internationale Erweiterung der vorherigen Ränge zu Digitalisierung, Wissenschaft, Sicherheit, Migration, Klima, Finanzsystem und Wirtschaft.

### Abgrenzung

Rang 19 ist kein außenpolitisches Parteiprogramm und keine geostrategische Doktrin. Er ist ein Bewertungsrahmen. Er kann von unterschiedlichen Parteien und Institutionen verschieden umgesetzt werden, solange Wirkungen sichtbar, prüfbar, verhältnismäßig, demokratisch kontrolliert und korrigierbar bleiben.

### Berechnungslogik und Bewertungsrahmen

Rang 19 arbeitet mit einer mehrstufigen Bewertungslogik. Zuerst wird bestimmt, welche Wirkungsträger beteiligt sind: Staaten, Unternehmen, Lieferanten, Finanzakteure, Plattformen, internationale Organisationen, Städte, Entwicklungsbanken, Forschungseinrichtungen und Zivilgesellschaft. Danach wird erfasst, welche Wirkungsempfänger betroffen sind: Menschen in Produktionsländern, Konsument:innen, Ökosysteme, zukünftige Generationen, demokratische Institutionen, Kommunen und globale Gemeingüter.

Anschließend wird die Wirkung räumlich und zeitlich gelesen. Direktwirkungen entstehen dort, wo eine Maßnahme unmittelbar greift. Indirekte Wirkungen entstehen entlang von Lieferketten, Kapitalflüssen, Datenräumen oder Migrationspfaden. Systemwirkungen entstehen, wenn sich Abhängigkeiten, Marktstrukturen, Sicherheitslagen, Standards oder politische Handlungsspielräume dauerhaft verändern. Transformationswirkung liegt vor, wenn aus einer Maßnahme neue Regeln, neue Routinen, neue Datenstandards oder neue Investitionspfade entstehen.

| Ebene | Leitfrage | Beispiel |
| --- | --- | --- |
| Direktwirkung | Welche Zustandsveränderung tritt unmittelbar ein? | Emissionswert eines importierten Produkts |
| Indirekte Wirkung | Welche Wirkung wird räumlich oder sozial ausgelagert? | Wasserstress in der Vorproduktion |
| Systemwirkung | Welche Abhängigkeit oder Resilienz verändert sich? | Rohstoffkonzentration, Datenmacht, Lieferkettenverwundbarkeit |
| Transformationswirkung | Welcher Pfad wird dauerhaft verschoben? | DPP, CBAM, gemeinsame Benchmarks, Wirkungsfonds |

### Datenarchitektur

Die internationale Wirkungsökonomie braucht keine zentrale Welt-Datenbank. Sie braucht föderierte Datenräume, offene Schnittstellen, Datenqualitätsklassen, Audit-Trails, lokale Benchmarks, Rechteverwaltung und unabhängige Prüfung. Der Zweck der Datenarchitektur ist nicht Kontrolle von Personen, sondern Sichtbarkeit von Wirkungen, Risiken, Übergängen und Verantwortlichkeiten.

Ein wirksames Datenmodell trennt Rohdaten, geprüfte Daten, abgeleitete Indikatoren, Bewertungsregeln und politische Entscheidungen. Diese Trennung ist wichtig, damit Messung nicht zur verdeckten Herrschaft wird. Daten zeigen Zustände. Bewertungsregeln ordnen Zustände ein. Politische Prozesse entscheiden, wie auf diese Einordnung reagiert wird.

### Übergangslogik

Globale Wirkungsstandards müssen Übergänge ermöglichen. Kleine Unternehmen, Kommunen, Zulieferer und Länder mit schwacher Dateninfrastruktur dürfen nicht durch perfekte Nachweispflichten ausgeschlossen werden. Zugleich darf fehlende Datenlage nicht belohnt werden. Deshalb braucht Rang 19 Datenqualitätsklassen, Standardwerte, technische Hilfe, Fristen, lokale Prüfstellen und Wirkungsfonds, die Kapazitäten aufbauen.

- Datenqualitätsklasse A: geprüfte Primärdaten mit Audit-Trail.
- Datenqualitätsklasse B: geprüfte Sekundärdaten mit plausibler Zuordnung.
- Datenqualitätsklasse C: konservative Standardwerte mit Verbesserungsplan.
- Datenqualitätsklasse D: fehlende oder widersprüchliche Daten mit erhöhter Prüfpflicht.

### Politische Spannungsfelder

Rang 19 bewegt sich in politischen Spannungsfeldern. Eine Wirkungsordnung muss offene Märkte erhalten und zugleich externalisierte Schäden sichtbar machen. Sie muss Entwicklung ermöglichen und zugleich ökologische Grenzen schützen. Sie muss kulturelle Unterschiede respektieren und zugleich universelle Schutzgüter verteidigen. Sie muss globale Kooperation stärken und zugleich Machtmissbrauch, Korruption und Desinformation begrenzen.

Diese Spannungsfelder verschwinden nicht durch Messung. Die Wirkungsökonomie macht sie sichtbar, damit politische Entscheidungen ehrlicher werden. Ein wirkungsbasierter Grenzmechanismus kann richtig sein, wenn er transparent, verhältnismäßig und entwicklungssensibel ist. Er kann falsch werden, wenn er als Abschottung, Industrieprotektion oder moralische Überlegenheit funktioniert.

### Website- und Dossierlogik

Das Portal muss alle Langfassungen online lesbar machen. Jede Unterseite braucht den Pflichtblock politische Anschlussfähigkeit, einen SDG-/SDG+-Block, Quellen, Glossarlinks, Downloadlinks für PDF und DOCX, mobile Inhaltsverzeichnisse und Querverlinkungen. Rang 19 darf nicht als Kommentar oder Essay erscheinen, sondern als systematischer Fachbereich mit Tools, Indikatoren, Dossiers und Umsetzungspfad.

### Fachliche Vertiefung: Europa, Handel und globale Governance

Die internationale Wirkungsökonomie beginnt nicht bei einer abstrakten Weltordnung, sondern bei konkreten Schnittstellen. Europa verfügt über Schnittstellen zwischen Markt, Recht, Daten, Produkten, Finanzierung und Demokratie. Der Welthandel verfügt über Schnittstellen zwischen Produktion, Konsum, Zoll, Standards und Konformitätsbewertung. Internationale Organisationen verfügen über Schnittstellen zwischen Wissen, Berichten, Normen und Kooperation. Rang 19 ordnet diese Schnittstellen so, dass sie nicht isolierte Regelwerke bleiben, sondern in eine gemeinsame Wirkungsarchitektur eingebunden werden können.

Diese Vertiefung ist notwendig, weil viele globale Debatten in falschen Gegensätzen stecken: Freihandel oder Protektionismus, Souveränität oder Kooperation, Entwicklung oder Klima, Sicherheit oder Freiheit, kulturelle Vielfalt oder universelle Schutzgüter. Die Wirkungsökonomie ersetzt diese Gegensätze nicht durch einfache Harmonie. Sie zeigt, welche Zustandsveränderungen jede Option erzeugt und welche Nebenwirkungen politisch abgefedert werden müssen.

### Fachliche Vertiefung: gerechte Lastenverteilung

Ein globaler Wirkungsstandard ist nur tragfähig, wenn er Kosten, Nutzen und Anpassungsfähigkeit berücksichtigt. Wer bereits Dateninfrastruktur, Prüfinstitutionen und Kapitalzugang besitzt, kann neue Standards leichter erfüllen als kleine Zulieferer, Kommunen oder Länder mit schwacher Verwaltung. Deshalb braucht Rang 19 eine explizite Fairnesslogik: technische Hilfe, Datenhilfe, Übergangsfristen, Standardwerte, lokale Wertschöpfung, Finanzierung und Rechtsschutz.

Gerechte Lastenverteilung bedeutet nicht, negative Wirkung zu relativieren. Kinderarbeit, massive Umweltzerstörung, Korruption, Gewalt, Desinformation oder autoritäre Willkür werden nicht dadurch akzeptabel, dass ein Akteur schwach ist. Aber der Weg aus schädlichen Strukturen muss so gestaltet werden, dass er reale Verbesserung ermöglicht und nicht bloß Lieferketten in intransparentere Räume verschiebt.

### Fachliche Vertiefung: Geopolitik als Wirkungsrisiko

Geopolitik wird in Rang 19 als Wirkungsrisiko gelesen. Rohstoffkonzentration, Energieabhängigkeit, Datenmonopole, Plattformmacht, Desinformation, Finanzabhängigkeit, militärische Eskalation und blockierte Lieferketten sind nicht nur Machtfragen. Sie verändern Versorgung, Preise, demokratisches Vertrauen, Migration, Investitionen, Versicherbarkeit und öffentliche Sicherheit.

Ein geopolitisches Wirkungsmodell fragt daher nicht nur, wer stärker ist. Es fragt, welche Verwundbarkeiten entstehen, welche kritischen Funktionen betroffen sind, welche Akteure Lasten tragen, welche Pfade durch Abhängigkeit blockiert werden und wie Kooperation möglich bleibt, ohne naiv zu werden.

### Fachliche Vertiefung: Rechtsstaatlichkeit und Rechtsschutz

Sobald Wirkungsdaten in Marktzugang, Finanzierung, Beschaffung oder Steuern eingehen, braucht es Rechtsschutz. Unternehmen müssen fehlerhafte Einstufungen angreifen können. Partnerländer müssen Methoden kritisieren können. Zivilgesellschaft muss Datenlücken benennen können. Bürger:innen müssen verstehen können, welche Daten welche Entscheidung beeinflussen.

Rechtsschutz ist kein Bremsklotz der Wirkungsökonomie. Er ist ihr Legitimitätskern. Ohne Rechtsschutz wird Wirkungsmessung zur Machttechnik. Mit Rechtsschutz wird sie zur überprüfbaren Rückkopplung. Deshalb muss jede Website-Unterseite zu Rang 19 klarstellen, dass Wirkungsdaten Orientierung liefern und demokratische Entscheidung nicht ersetzen.

### SDG- und SDG+-Bezug

Rang 19 ist besonders stark mit SDG 16 und SDG 17 verbunden, weil Frieden, Rechtsstaatlichkeit, starke Institutionen und Partnerschaften zentrale Bedingungen einer weltfähigen Wirkungsordnung sind. Zugleich berührt internationale Ordnung nahezu alle SDGs: Klima, Wasser, Energie, Arbeit, Ungleichheit, Produktion, Städte, Biodiversität, Gesundheit und Bildung.

SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie. Sie ergänzt Demokratiequalität, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

- SDG 1: Armutsbekämpfung und faire Entwicklungsbedingungen.
- SDG 2: Ernährungssicherheit, resiliente Lieferketten und Krisenvorsorge.
- SDG 6: Wasserstress, Nutzungskonflikte und globale Wasserwirkung.
- SDG 7: Energiezugang, Versorgungssicherheit und faire Transformation.
- SDG 8: menschenwürdige Arbeit in globalen Wertschöpfungsketten.
- SDG 10: weniger Ungleichheiten zwischen und innerhalb von Staaten.
- SDG 12: nachhaltige Produktion und Konsum entlang globaler Lieferketten.
- SDG 13: Klimaschutz, Anpassung und Klimagerechtigkeit.
- SDG 16: Frieden, Rechtsstaatlichkeit, Institutionen und Schutz vor Korruption.
- SDG 17: Partnerschaften, Standards, Daten, Finanzierung und internationale Kooperation.

### Politische Anschlussfähigkeit und Umsetzungsoptionen

Die Wirkungsökonomie liefert keinen fertigen außenpolitischen Parteiprogrammtext. Sie liefert einen Bewertungs- und Steuerungsrahmen, der sichtbar macht, welche internationale Ordnung positive Netto-Wirkung für Mensch, Planet und Demokratie erzeugt und wo negative Wirkungen ausgelagert werden.

Parteien behalten Ausgestaltungsspielraum bei Handelspolitik, Entwicklungspolitik, Sicherheitsarchitektur, Europa, Migration, Rohstoffstrategie, Klimafinanzierung, Industriepolitik und digitaler Souveränität. Entscheidend ist nicht die parteipolitische Richtung, sondern die überprüfbare Wirkung.

- Aufgabe der Politik: globale Wirkungen sichtbar machen, ohne nationale Demokratie zu ersetzen.
- Rahmenbedingungen: Rechtsstaat, Menschenrechte, internationale Abkommen, EU-Recht, WTO-Regeln, SDGs, SDG+ und Schutz öffentlicher Güter.
- Zielkonflikte: offene Märkte versus Schutz vor externalisierten Schäden, geopolitische Sicherheit versus Kooperation, kulturelle Übersetzung versus klare Schutzgüter.
- Rollenverteilung: Staaten setzen Regeln, Institutionen prüfen, Unternehmen berichten, Wissenschaft validiert, Zivilgesellschaft kontrolliert, Kommunen und Regionen übersetzen vor Ort.
- Schutz vor Technokratie: keine Weltregierung, keine Personenbewertung, keine verdeckte Datenherrschaft, keine Expertokratie.
- Evaluation: Indikatoren müssen öffentlich, korrigierbar, versioniert und demokratisch kontrolliert sein.

### Quellen und Anschlussrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XV: Internationale Ordnung, Globalisierung und Geopolitik, Kapitel 91 bis 96.

Weber, Natalie: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development, Resolution A/RES/70/1, 2015. https://sdgs.un.org/2030agenda

European Commission: Carbon Border Adjustment Mechanism, definitive regime from 2026 after transitional phase 2023 to 2025. https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en

World Trade Organization: The WTO deals with the global rules of trade between nations. https://www.wto.org/

World Trade Organization: The WTO and the Sustainable Development Goals. https://www.wto.org/english/thewto_e/coher_e/sdgs_e/sdgs_e.htm

OECD: Development co-operation and the provision of global public goods, 2023. https://www.oecd.org/en/publications/development-co-operation-and-the-provision-of-global-public-goods_aff8cba9-en.html

UNDP: Sustainable Development Goals as integrated global goals. https://www.undp.org/sustainable-development-goals
