# Detailkonzept - Klimagerechtigkeit und Ressourcenfairness

Autorin: Natalie Weber
Referenz: Wirkungsökonomie
Version: 1.0
Stand: Mai 2026
Status: Langfassungsentwurf für Website, Akademie, Download und politische Anschlussfähigkeit

## Klimagerechtigkeit und Ressourcenfairness

Klimagerechtigkeit und Ressourcenfairness verbinden historische Verantwortung, gegenwärtige Verwundbarkeit, Rohstoffabhängigkeit, technologische Teilgabe und faire Finanzierung.

Dieses Detailkonzept ordnet das Thema in die Wirkungsökonomie ein und zeigt, wie aus globaler Komplexität keine pauschale Herrschaftslogik, sondern eine messbare, demokratisch begrenzte und lernfähige Rückkopplungsarchitektur entstehen kann.

### Executive Summary

Klimagerechtigkeit und Ressourcenfairness verbinden historische Verantwortung, gegenwärtige Verwundbarkeit, Rohstoffabhängigkeit, technologische Teilgabe und faire Finanzierung.

Die zentrale Aufgabe besteht darin, globale Wirkungen sichtbar zu machen, ohne lokale Handlungsfähigkeit, demokratische Entscheidung und kulturelle Übersetzung zu ersetzen. Rang 19 verbindet deshalb Messbarkeit mit Begrenzung, Interoperabilität mit Datenhoheit und globale Kooperation mit politischer Verantwortung.

### Wirkungsökonomische Einordnung

Wirkung ist in diesem Feld neutral und relational. Sie beschreibt nicht Absicht, Moral oder geopolitische Selbstdarstellung, sondern tatsächliche Zustandsveränderungen. Bewertet wird am Referenzrahmen SDGs, Agenda 2030 und SDG+.

Internationale Ordnung wird damit nicht nach Machtgewinn, Exportvolumen oder Blockzugehörigkeit bewertet, sondern nach ihrer Netto-Wirkung auf Mensch, Planet und Demokratie.

### Wirkungspotenziale und Wirkungsrisiken

Das Wirkungspotenzial liegt in besserer Transparenz, fairerer Kostenverteilung, gemeinsamen Standards, stabileren Lieferketten, resilienteren öffentlichen Gütern und einer stärkeren Korrekturfähigkeit internationaler Politik.

Das Wirkungsrisiko liegt in Dominanz, Datenmonopolen, Scheingenauigkeit, politischer Instrumentalisierung, Ausschluss kleiner Akteure und neuen Abhängigkeiten. Diese Risiken müssen Teil der Bewertung sein, nicht nachträgliche Fußnote.

### Datenquellen, Indikatoren und Bewertungslogik

Die Bewertungslogik nutzt vorhandene Datenräume: SDGs, CSRD, ESRS, GRI, EU-Taxonomie, CBAM-Daten, Lieferkettendaten, DPP, Handelsstatistiken, Klima- und Wasserindikatoren, Arbeitsstandards, Menschenrechtsdaten, Medienqualitätsindikatoren und Resilienzmetriken.

| Indikatorfeld | Beispielfrage | Bewertungslogik |
| --- | --- | --- |
| Historische Emissionsverantwortung | Welche Zustandsveränderung wird sichtbar? | Score, Datenqualität, Kontext, Nichtkompensation |
| Klimaverwundbarkeit | Welche Zustandsveränderung wird sichtbar? | Score, Datenqualität, Kontext, Nichtkompensation |
| Rohstoffabhängigkeit | Welche Zustandsveränderung wird sichtbar? | Score, Datenqualität, Kontext, Nichtkompensation |
| Anteil lokaler Wertschöpfung | Welche Zustandsveränderung wird sichtbar? | Score, Datenqualität, Kontext, Nichtkompensation |

### Umsetzungsmodell

Die Umsetzung beginnt mit Pilotbereichen, die hohe Datenverfügbarkeit und hohe Wirkung besitzen: Lieferketten, öffentliche Beschaffung, grenzüberschreitende Infrastruktur, Klimafinanzierung, Rohstoffpartnerschaften, digitale Standards und Frühwarnsysteme.

- Phase 1: Mapping von Wirkungsräumen und Datenquellen.
- Phase 2: Definition von WÖk-IDs, Benchmarks und roten Linien.
- Phase 3: öffentliche Konsultation, Beteiligung betroffener Regionen und wissenschaftliche Prüfung.
- Phase 4: Pilotierung mit Rückkopplung in Preise, Förderung, Beschaffung oder Kapitalzugang.
- Phase 5: Evaluation, Korrektur und Versionierung.

### Beispielhafte Anwendung

Ein Land mit geringer historischer Emission kann stark von Klimafolgen betroffen sein. Wirkungsökonomie macht diese asymmetrische Belastung sichtbar und überführt sie in Finanzierung, Partnerschaften und Risikoausgleich.

Das Beispiel zeigt: Die Wirkungsökonomie ersetzt nicht politische Entscheidung. Sie verändert den Informationszustand, auf dessen Grundlage entschieden wird. Wirkungen werden sichtbar, Zielkonflikte werden benennbar und Korrektur wird möglich.

### SDG- und SDG+-Bezug

Besonders relevant sind SDG 8, SDG 10, SDG 12, SDG 13, SDG 16 und SDG 17. Je nach Thema kommen Wasser, Energie, Gesundheit, Biodiversität, Bildung und Arbeit hinzu. SDG+ ergänzt Demokratie, Medienqualität, Rechtsstaatlichkeit, digitale Selbstbestimmung und institutionelles Vertrauen.

### Politische Anschlussfähigkeit und Umsetzungsoptionen

Politische Akteure können unterschiedliche Strategien wählen: stärker marktorientiert, stärker regulativ, stärker partnerschaftlich, stärker europäisch oder stärker global. Die Wirkungsökonomie verlangt keine Einheitslösung, sondern nachvollziehbare Wirkung, demokratische Kontrolle und Korrekturfähigkeit.

### Schutz vor Technokratie und Dominanz

Schutzmechanismen sind: offene Methoden, öffentliche Begründung, unabhängige Prüfung, lokale Beteiligung, Datenschutz, keine Personenbewertung, keine Social-Credit-Logik, Widerspruchsmöglichkeiten und klare institutionelle Zuständigkeiten.

### Evaluation und Korrektur

Evaluation prüft, ob die Maßnahme ihre beabsichtigte Wirkung erreicht, Nebenwirkungen erzeugt, Machtasymmetrien verstärkt, kleine Akteure belastet oder Datenmonopole begünstigt. Bewertungslogik und Benchmarks müssen versioniert und regelmäßig überprüft werden.

### Fachliche Vertiefung: Wirkraum und Zurechnung

Das Detailkonzept behandelt einen Wirkraum, in dem Ursachen, Verantwortung und Folgen räumlich, zeitlich und institutionell auseinanderfallen. Genau deshalb reicht eine nationale oder rein sektorale Betrachtung nicht aus. Die Wirkungsökonomie fragt, welche Zustände durch das Handeln von Staaten, Unternehmen, Plattformen, Kapitalgebern, Institutionen und Konsument:innen verändert werden.

Zurechnung bedeutet hier nicht, alle Folgen einer einzigen Instanz zuzuschreiben. Es geht um robuste Verantwortungszonen: Wer erzeugt Wirkungspotenzial, wer verstärkt Wirkungsrisiken, wer profitiert von ausgelagerten Schäden, wer kann Risiken senken und wer trägt die Folgen? Diese Fragen müssen offen gelegt werden, bevor politische Instrumente entwickelt werden.

Bei Klimagerechtigkeit und Ressourcenfairness ist besonders wichtig, dass lokale Wirkung und globale Wirkung nicht getrennt werden. Eine Maßnahme kann in einem Land Wohlstand, Effizienz oder Sicherheit erzeugen und zugleich in einem anderen Raum Wasserstress, Datenabhängigkeit, Arbeitsrisiko oder demokratische Destabilisierung verstärken. Der Wirkraum muss deshalb entlang der gesamten Kette gelesen werden.

Die Bewertung folgt nicht der Logik einer Schuldzuweisung, sondern der Logik der Korrekturfähigkeit. Wo Wirkung sichtbar wird, kann sie in Preise, Standards, Förderung, Beschaffung, Kapitalzugang, Risikomodelle oder politische Verhandlung zurückgeführt werden.

### Akteure, Rollen und Verantwortungszonen

| Akteur | Rolle im Wirkraum | Verantwortungszone |
| --- | --- | --- |
| Staaten | setzen Rechtsrahmen, handeln Abkommen aus, sichern Schutzgüter | Rechtsstaat, Menschenrechte, Handelsregeln, Krisenvorsorge |
| Unternehmen | gestalten Produkte, Lieferketten, Investitionen und Datenflüsse | Transparenz, faire Arbeit, Umweltwirkung, Datenqualität |
| Finanzsystem | lenkt Kapital, Risiko, Zinsen und Versicherbarkeit | Kapitalwirkung, Risikoprüfung, Ausschluss schädlicher Externalisierung |
| Wissenschaft und Statistik | prüfen Daten, Unsicherheit und Wirkpfade | Methodik, Validierung, Offenlegung von Grenzen |
| Zivilgesellschaft und Betroffene | machen blinde Flecken sichtbar und kontrollieren Macht | Teilgabe, lokale Übersetzung, Widerspruch, Beschwerdewege |

Diese Rollen sind nicht hierarchisch zu verstehen. Rang 19 braucht eine polyzentrische Architektur, weil globale Wirkung nicht durch eine einzige Institution kontrollierbar ist. Vielmehr braucht es mehrere Korrekturräume, die sich gegenseitig begrenzen.

Ein Unternehmen kann Daten liefern, aber nicht allein festlegen, was gute Wirkung ist. Ein Staat kann Regeln setzen, aber nicht ohne Betroffenenperspektive und wissenschaftliche Prüfung. Eine internationale Organisation kann Standards koordinieren, aber nicht demokratische Aushandlung ersetzen.

### Wirkpfade erster, zweiter und dritter Ordnung

Wirkung erster Ordnung beschreibt direkte Zustandsveränderungen. Bei Klimagerechtigkeit und Ressourcenfairness können das konkrete Preisänderungen, Datenpflichten, Investitionen, Zugang zu Infrastruktur, Berichtspflichten, Grenzregelungen oder Beteiligungsformate sein.

Wirkung zweiter Ordnung beschreibt indirekte Folgen. Dazu gehören Verlagerungen in Lieferketten, neue Markteintrittsbarrieren, bessere Datenqualität, veränderte Kapitalflüsse, politische Akzeptanz, Innovation oder unerwünschte Ausweichreaktionen.

Wirkung dritter Ordnung verändert Entscheidungsstrukturen. Wenn internationale Akteure beginnen, Wirkung systematisch zu berücksichtigen, verändern sich Standards, Investitionskriterien, Handelsbeziehungen, Sicherheitslogiken und öffentliche Erwartungshorizonte. Das ist Transformationswirkung.

| Wirkungsordnung | Leitfrage | Beispiel im Rang 19 |
| --- | --- | --- |
| Erste Ordnung | Was verändert sich unmittelbar? | Daten werden erhoben, Emissionen werden berichtet, Beschaffung wird angepasst. |
| Zweite Ordnung | Welche indirekten Folgen entstehen? | Lieferanten investieren, kleine Akteure brauchen Unterstützung, Kapital bewertet Risiken neu. |
| Dritte Ordnung | Welche Entscheidungslogik verändert sich? | Handel wird nicht nur nach Preis, sondern nach Wirkung und Resilienz gesteuert. |

### Datenarchitektur und Qualitätsklassen

Daten sind für Rang 19 notwendig, aber nicht hinreichend. Globale Wirkungsdaten müssen maschinenlesbar, prüfbar, kontextsensibel und zugänglich sein. Gleichzeitig muss klar sein, welche Daten hart gemessen, geschätzt, modelliert oder nur indikativ verfügbar sind.

Die Wirkungsökonomie unterscheidet deshalb Datenqualität. Hohe Qualität entsteht durch Primärdaten, Audit, nachvollziehbare Methodik und regelmäßige Aktualisierung. Mittlere Qualität kann aus anerkannten Sekundärdaten oder belastbaren Schätzungen entstehen. Niedrige Qualität muss offen markiert werden und darf nicht als präzise Wahrheit verkauft werden.

| Qualitätsklasse | Beschreibung | Umgang |
| --- | --- | --- |
| A | geprüfte Primärdaten mit klarer Methodik | voll steuerungsfähig und auditierbar |
| B | belastbare Sekundärdaten oder nachvollziehbare Modelle | steuerungsfähig mit Unsicherheitsangabe |
| C | Schätzung mit begrenzter Datenlage | nur vorläufige Bewertung, Nachlieferpflicht |
| D | Datenlücke oder nicht prüfbare Angabe | konservative Einstufung und Korrekturpfad |

Diese Qualitätslogik schützt vor Scheingenauigkeit und vor dem Missbrauch von Kennzahlen. Sie ist auch eine Fairnessbedingung: Länder, kleine Unternehmen und lokale Akteure dürfen nicht allein deshalb abgewertet werden, weil sie weniger Dateninfrastruktur besitzen. Statt Ausschluss braucht es Übergang, Unterstützung und offene Standards.

### Rechtliche und institutionelle Anschlussstellen

Rang 19 kann an bestehende Institutionen anschließen, ohne sie zu ersetzen. WTO, UN, OECD, ILO, WHO, Entwicklungsbanken, EU, regionale Entwicklungsbanken, Standardsetzer und nationale Statistiksysteme sind mögliche Anschlussräume. Sie liefern Regeln, Daten, Verhandlungskanäle oder Finanzierung, aber die Wirkungsökonomie ordnet sie nach Wirkung neu.

Die rechtliche Umsetzung muss verhältnismäßig bleiben. Grenzausgleich, Beschaffungsregeln, Berichtspflichten, Handelsabkommen, Investitionskriterien oder Wirkungsfonds müssen gegen Wettbewerbsrecht, Menschenrechte, Datenschutz, Verwaltungsfähigkeit und internationale Verpflichtungen geprüft werden.

Die Wirkungsökonomie schafft deshalb keine Abkürzung um Recht und Demokratie herum. Im Gegenteil: Sie macht sichtbar, welche Folgen rechtlicher und politischer Entscheidungen entstehen, damit Entscheidungen besser begründet und korrigiert werden können.

### Pilotmodell

Ein Pilot für Klimagerechtigkeit und Ressourcenfairness sollte in einem klar abgegrenzten Wirkungsraum beginnen. Geeignet sind Lieferketten mit hoher Datenverfügbarkeit, öffentliche Beschaffung, ein Rohstoffkorridor, eine Klima- oder Wasserpartnerschaft, eine Energieinfrastruktur, ein Gesundheitsfrühwarnsystem oder ein europäisch-internationales Datenstandardprojekt.

- Pilotraum definieren und Wirkungsempfänger identifizieren.
- Datenquellen und Datenqualitätsklassen festlegen.
- WÖk-IDs und Benchmarks transparent dokumentieren.
- Betroffene Akteure beteiligen und Widerspruchswege einrichten.
- Rückkopplung in Beschaffung, Förderung, Kapital oder Standards testen.
- Nach zwölf Monaten Wirkungsbericht veröffentlichen und Methodik korrigieren.

Der Pilot muss reversibel sein. Wenn Nebenwirkungen auftreten, müssen Benchmarks, Gewichtung, Datenquellen oder Instrumente angepasst werden können. Lernfähigkeit ist kein Zusatz, sondern Bedingung einer weltfähigen Wirkungsordnung.

### Finanzierung und Kapitalwirkung

Kapital wirkt global schneller als viele politische Verfahren. Deshalb muss Rang 19 Kapitalwirkung ausdrücklich einbeziehen. Investitionen in Infrastruktur, Rohstoffe, Energie, digitale Netze, Landwirtschaft, Wasser, Gesundheit oder Medien können positive Netto-Wirkung erzeugen oder Abhängigkeiten, Extraktion und demokratische Risiken verstärken.

Wirkungsfonds, Entwicklungsbanken, öffentliche Garantien, Risikoabsicherung, Zinsdifferenzierung und öffentliche Beschaffung können Kapital in Richtung positiver Netto-Wirkung lenken. Voraussetzung ist, dass Kriterien transparent, überprüfbar, demokratisch kontrolliert und lokal anschlussfähig sind.

Ein Wirkungsfonds darf nicht nur Projekte finanzieren, die gut klingen. Er muss zeigen, welche Zustände sich ändern, welche Risiken sinken, welche Gruppen profitieren, welche Nebenwirkungen entstehen und wie lokaler Nutzen gesichert wird.

### Kommunikation und öffentliche Resonanz

Internationale Ordnung ist ein besonders anfälliger Resonanzraum. Begriffe wie Agenda, Transformation, Monitoring, globale Standards oder internationale Kooperation können in polarisierten Öffentlichkeiten als Kontrolle, Bevormundung oder geheimer Plan gelesen werden. Rang 19 muss deshalb sprachlich sehr präzise sein.

Die öffentliche Kommunikation muss Kooperation und Herrschaft klar unterscheiden. Ein Zielrahmen ersetzt keine demokratische Entscheidung. Ein Indikator ist keine Überwachung. Ein Datenstandard ist kein Weltstaat. Ein Wirkungsbericht ist keine Lebensstilpolizei. Gleichzeitig darf Kritik an globaler Macht nicht in Desinformation oder Verschwörungsnarrative kippen.

Eine gute Kommunikationsarchitektur benennt Zielkonflikte offen. Sie erklärt, wer entscheidet, wer Daten prüft, welche Grenzen bestehen, wie Widerspruch möglich ist und wie Fehler korrigiert werden. Genau diese Offenheit schützt vor Technokratie und Misstrauen.

### Rote Linien und Nichtkompensation

Globale Wirkung darf nicht als Durchschnittslogik berechnet werden, wenn schwere Schäden auftreten. Menschenrechtsverletzungen, Zwangsarbeit, Korruption, demokratische Destabilisierung, Biodiversitätszerstörung, schwere Gesundheitsrisiken oder massive Datenmanipulation dürfen nicht durch positive Effekte an anderer Stelle glattgerechnet werden.

Die Reverse Merit Order ist deshalb auch international wichtig. Das schwächste zentrale Wirkungsfeld begrenzt die Gesamtbewertung. Ein Projekt mit guter Klimawirkung kann nicht als positiv gelten, wenn es lokale Rechte verletzt, Korruption stärkt oder Datenmonopole erzeugt.

### Prüffragen für Umsetzung und Website

- Ist klar, welche Wirkungsempfänger betroffen sind?
- Sind positive und negative Wirkungen getrennt sichtbar?
- Sind Datenquellen und Datenqualität nachvollziehbar?
- Wird zwischen Kooperation und Herrschaft unterschieden?
- Gibt es lokale Beteiligung und Beschwerdewege?
- Sind politische Spielräume erhalten?
- Sind rote Linien und Nichtkompensation erklärt?
- Wird SDG+ als WÖk-Erweiterung und nicht als UN-Kategorie dargestellt?
- Sind PDF und DOCX als Downloads verfügbar?
- Sind Onlinefassungen vollständig lesbar?

### Bewertungsmatrix für Netto-Wirkung

Die Bewertungsmatrix führt positive und negative Wirkungen nicht zu einem einfachen Durchschnitt zusammen. Sie prüft Mindestbedingungen, rote Linien, Datenqualität, Reichweite, Dauer und Reversibilität. Ein hoher Nutzen in einem Feld kann schwere Schäden in einem anderen Feld nicht neutralisieren.

| Bewertungsschritt | Leitfrage | Ergebnis |
| --- | --- | --- |
| 1. Wirkraum | Wo entsteht Wirkung und wer ist betroffen? | Wirkungsempfänger und Räume sind benannt. |
| 2. Mindestschutz | Werden Menschenwürde, Rechtsstaat, ökologische Lebensgrundlagen und Demokratiegrenzen eingehalten? | Rote Linien sind geprüft. |
| 3. Netto-Wirkung | Welche positiven und negativen Zustandsveränderungen entstehen? | Wirkungsbilanz ohne Scheinkompensation. |
| 4. Transformationswirkung | Verändert die Maßnahme Anreize, Standards oder Pfade? | Systemische Wirkung wird sichtbar. |
| 5. Korrektur | Wie werden Fehler, Nebenwirkungen und Unsicherheiten zurückgeführt? | Lernschleife ist definiert. |

Für Klimagerechtigkeit und Ressourcenfairness bedeutet das: Die Bewertung darf nicht bei einer einzigen Kennzahl stehen bleiben. Sie braucht eine Wirkungsbilanz, die direkte Effekte, indirekte Effekte, Betroffenheit, Machtasymmetrien und langfristige Stabilitätsbedingungen zusammenführt.

Der Netto-Wirkungs-Ansatz verhindert, dass internationale Politik nur mit großen Zielworten arbeitet. Er verlangt, dass jedes Instrument zeigt, welche Wirkungen es tatsächlich erzeugt und welche Folgewirkungen es auslöst.

### Zielkonfliktmatrix

Rang 19 ist voller legitimer Zielkonflikte. Offene Märkte können Wohlstand schaffen, aber auch Externalisierung erleichtern. Standards können Qualität sichern, aber kleine Akteure überfordern. Sicherheitsmaßnahmen können Resilienz erhöhen, aber Freiheit einschränken. Klimaschutz kann globale Güter schützen, aber Verteilungskonflikte verschärfen, wenn er nicht sozial abgefedert wird.

| Zielkonflikt | Risiko | Wirkungsökonomische Bearbeitung |
| --- | --- | --- |
| Kooperation versus Souveränität | globale Regeln wirken wie Fremdsteuerung | lokale Übersetzung, demokratische Kontrolle, Widerspruchswege |
| Standards versus Marktzugang | kleine Akteure werden ausgeschlossen | Übergangsfristen, technische Hilfe, offene Datenstandards |
| Klimaschutz versus Verteilung | Kosten treffen vulnerable Gruppen | Kaufkraftschutz, Wirkungsfonds, soziale Rückerstattung |
| Sicherheit versus Freiheit | Resilienz kippt in Kontrolllogik | klare Rechtsgrundlagen, Verhältnismäßigkeit, parlamentarische Kontrolle |
| Datenqualität versus Datenmacht | wenige Akteure kontrollieren Wirklichkeit | öffentliche Statistik, Interoperabilität, Datenhoheit, Audits |

Zielkonflikte verschwinden nicht durch Wirkungsmessung. Sie werden aber sichtbarer und dadurch demokratisch bearbeitbar. Das ist die politische Stärke der Wirkungsökonomie: Sie behauptet nicht, Zielkonflikte technisch zu lösen, sondern macht ihre Folgen prüfbar.

### Operationalisierung in Website, Akademie und Dossiers

Für die Website muss dieses Detailkonzept als vollständiger Online-Volltext erscheinen. Es darf nicht nur als PDF verlinkt werden. Nutzer:innen müssen die Begriffslogik, die Instrumente, die Indikatoren, den SDG-/SDG+-Bezug und die politische Anschlussfähigkeit direkt auf der Seite lesen können.

Für die Akademie eignet sich das Thema als Modul mit drei Lernebenen: erstens Grundbegriffe wie Wirkraum, Externalisierung und Weltfähigkeit; zweitens Instrumente wie WÖk-IDs, Grenzausgleich, Wirkungsfonds und Frühwarnsysteme; drittens Anwendung auf konkrete Fallstudien aus Handel, Rohstoffen, Klima, Daten oder Desinformation.

Für Dossiers muss jedes Kapitel mit Beispielen, Datenquellen und Umsetzungspfaden arbeiten. Die Wirkungsökonomie lebt nicht von großen Begriffen, sondern von der Übersetzung in prüfbare Rückkopplung.

### Fallstudienlogik

Eine geeignete Fallstudie für Klimagerechtigkeit und Ressourcenfairness sollte mindestens drei Räume verbinden: den Ort der Entscheidung, den Ort der direkten Wirkung und den Ort der indirekten Folge. Nur so wird sichtbar, ob Wirkungen ausgelagert oder fair geteilt werden.

| Fallstudienebene | Frage | Beispielhafte Daten |
| --- | --- | --- |
| Entscheidungsraum | Wer entscheidet und mit welcher Legitimation? | Rechtsgrundlage, Beteiligung, Zuständigkeit |
| Produktions- oder Wirkraum | Wo entstehen Emissionen, Arbeit, Wasser- oder Datenwirkungen? | Lieferketten, DPP, CSRD, Auditdaten |
| Betroffenenraum | Wer trägt Folgen oder Nutzen? | Sozialdaten, Umweltindikatoren, Beteiligung |
| Kapitalraum | Wer finanziert, profitiert oder versichert? | Investitionsdaten, Zinsen, Versicherbarkeit |
| Resonanzraum | Wie wird das Thema öffentlich gerahmt? | Medienframes, Desinformation, Vertrauen |

Fallstudien verhindern Abstraktion. Sie zeigen, dass internationale Ordnung nicht irgendwo fern stattfindet, sondern in Preisen, Produkten, Daten, Versicherungen, Lieferketten, Krisen, Medien und kommunalen Folgen ankommt.

### Abnahmekriterien für ein reifes Detailkonzept

- Das Konzept benennt Wirkungspotenziale, Wirkungsrisiken und tatsächliche Wirkungen getrennt.
- Es enthält Beispiele, Indikatoren, Datenquellen und politische Anschlussfähigkeit.
- Es unterscheidet Kooperation klar von Herrschaft.
- Es enthält Schutzmechanismen gegen Technokratie, Datenmacht und Dominanz.
- Es bietet PDF und DOCX als Downloads sowie eine vollständige Onlinefassung.
- Es enthält keine internen Arbeitsanweisungen und keine Platzhalter.
- Es macht deutlich, dass die Wirkungsökonomie einen Rahmen liefert, kein fertiges Parteiprogramm.

### Akteurslandkarte und Wirkungsräume

Das Feld "Klimagerechtigkeit und Ressourcenfairness" entsteht aus mehreren Akteursgruppen. Staaten setzen Regeln und verhandeln Abkommen. Unternehmen gestalten Lieferketten, Investitionen, Produktdaten und Beschaffung. Finanzakteure entscheiden über Kapitalzugang, Risikoaufschläge und Versicherbarkeit. Internationale Organisationen strukturieren Daten, Standards und Kooperation. Zivilgesellschaft, Wissenschaft, Medien und lokale Gemeinschaften prüfen, kritisieren, übersetzen und korrigieren.

Die Wirkungsräume sind nicht deckungsgleich mit Staatsgrenzen. Ein Wirkungsraum kann eine Lieferkette, ein Rohstoffgebiet, eine Handelsroute, ein Datenraum, ein Finanzportfolio, ein Ökosystem, ein Migrationskorridor, ein Konfliktraum, ein Hafen, ein digitales Netzwerk oder ein Stadt-Land-Verbund sein. Internationale Ordnung muss deshalb nach Wirkungsräumen lesen, nicht nur nach Territorien.

| Akteur | Mögliche Rolle | Wirkungsrisiko |
| --- | --- | --- |
| Staat | Regeln, Schutz, Finanzierung, Diplomatie | Machtpolitik oder Protektionismus |
| Unternehmen | Daten, Lieferketten, Innovation | Externalisierung oder Impact-Washing |
| Finanzsystem | Kapitalzugang, Versicherbarkeit, Portfoliosteuerung | Kurzfristige Renditelogik |
| Wissenschaft | Prüfung, Datenqualität, Unsicherheit | Expertokratie oder politische Vereinnahmung |
| Zivilgesellschaft | Kontrolle, lokale Übersetzung, Teilgabe | Symbolische Beteiligung ohne Wirkung |

### Datenquellen und Datenqualitätsklassen

Ein Detailkonzept auf Dossier-Niveau muss Datenquellen benennen. Für "Klimagerechtigkeit und Ressourcenfairness" kommen je nach Unterfeld SDG-Indikatoren, CSRD- und ESRS-Daten, Produktpässe, CBAM-Berichte, Zoll- und Handelsdaten, Satellitendaten, Klimarisikoindikatoren, Lieferkettenaudits, ILO-Standards, Gesundheitsdaten, Wasserstresskarten, Biodiversitätsdaten, Medienqualitätsindikatoren, Rechtsstaatsdaten und Finanzmarktdaten in Betracht.

Datenqualität wird nicht als Nebenthema behandelt. Schlechte Daten können falsche Preise, falsche Sanktionen, falsche Investitionsentscheidungen und ungerechte Belastungen erzeugen. Deshalb braucht jede Wirkungsbewertung Angaben zu Herkunft, Aktualität, Prüftiefe, Unsicherheit, regionalem Kontext und möglichem Bias.

- Primärdaten mit Audit-Trail haben Vorrang vor ungeprüften Selbstauskünften.
- Sekundärdaten müssen Quelle, Zeitraum, Auflösung und Unsicherheit offenlegen.
- Standardwerte dürfen nur konservativ und befristet eingesetzt werden.
- Fehlende Daten lösen Verbesserungspläne aus und dürfen keine strategische Lücke bleiben.

### Wirkungsbewertung und Nichtkompensation

Die Wirkungsbewertung verbindet positive und negative Effekte nicht als einfache Summe. Schwere negative Wirkungen dürfen nicht durch einzelne positive Werte überdeckt werden. Ein Lieferkettenprojekt mit guter CO2-Bilanz bleibt problematisch, wenn es Kinderarbeit, Landraub, Gewalt gegen lokale Gemeinschaften oder massive Wasserbelastung enthält. Ein digitaler Datenraum bleibt problematisch, wenn er lokale Datenhoheit zerstört oder autoritäre Überwachung erleichtert.

Die Reverse Merit Order schützt vor globalem Impact-Washing. Sie sagt nicht, dass jeder Mangel sofort jede Kooperation verhindert. Sie sagt, dass rote Linien und Engpässe sichtbar bleiben müssen und nicht im Durchschnitt verschwinden dürfen. Politische Übergänge können abgestuft sein. Die Diagnose darf aber nicht weichgerechnet werden.

| Wertungsfeld | Positive Wirkung | Rote Linie |
| --- | --- | --- |
| Mensch | faire Arbeit, Schutz, Teilgabe | Gewalt, Ausbeutung, Zwang, Kinderarbeit |
| Planet | Regeneration, Emissionsminderung, Biodiversität | irreversible Zerstörung, kritischer Wasserstress |
| Demokratie | Transparenz, Rechtsstaat, Medienqualität | Korruption, Desinformation, Willkür, Überwachung |

### Umsetzungspfad für Pilotierung

Die Pilotierung beginnt dort, wo Wirkung hoch und Daten anschlussfähig sind. Für "Klimagerechtigkeit und Ressourcenfairness" bedeutet das: zunächst Pilotlieferketten, ausgewählte Rohstoffe, öffentliche Beschaffung, Grenzwirkungsdaten, Entwicklungsfonds, digitale Produktpässe oder Resilienzindikatoren. Der Pilot muss klein genug sein, um kontrollierbar zu bleiben, aber groß genug, um reale Systemwirkung zu testen.

- Pilot 1: Wirkungsraum abgrenzen und betroffene Akteure beteiligen.
- Pilot 2: Datenquellen, WÖk-IDs, Benchmarks und rote Linien definieren.
- Pilot 3: technische Schnittstellen und Auditwege testen.
- Pilot 4: Wirkung in Beschaffung, Finanzierung, Förderung oder Preislogik zurückführen.
- Pilot 5: Nebenwirkungen, Kosten, Akzeptanz und Verteilungswirkung evaluieren.

Jeder Pilot braucht eine Ausstiegs- und Korrekturlogik. Wenn ein Indikator falsche Anreize erzeugt, muss er geändert werden. Wenn ein Standard kleine Anbieter ausschließt, braucht er technische Hilfe, Übergangsfristen oder differenzierte Datenklassen. Wenn eine Maßnahme demokratisch nicht erklärbar ist, muss ihre Begründung verbessert oder ihre Anwendung begrenzt werden.

### Beispielhafte Scorecard

Für die erste Version einer Scorecard genügt eine strukturierte Matrix, die Wirkung, Datenqualität und Governance trennt. Die Scorecard muss nicht alle globalen Fragen lösen. Sie muss die relevanten Zustandsveränderungen sichtbar machen und die Entscheidung dokumentieren.

| Scorefeld | Prüffrage | Datenqualität | Rückkopplung |
| --- | --- | --- | --- |
| Grenzwirkung | Welche Wirkung entsteht außerhalb des Verbrauchs- oder Entscheidungsraums? | A bis D | Preis, Steuer, Förderung, Beschaffung |
| Verteilung | Wer trägt Kosten und wer profitiert? | A bis D | Ausgleich, Fonds, Übergang |
| Resilienz | Wird eine kritische Funktion stabiler oder verwundbarer? | A bis D | Risikoaufschlag, Investition |
| Demokratie | Bleiben Kontrolle, Rechtsschutz und Transparenz erhalten? | A bis D | Audit, Beschwerde, öffentliche Begründung |

### Kommunikations- und Akzeptanzlogik

Globale Wirkungsstandards scheitern, wenn sie als abstrakte Bürokratie erscheinen. Sie müssen erklären, welche Probleme sie lösen: unfairen Wettbewerb durch externalisierte Schäden, Blindheit in Lieferketten, Rohstoffabhängigkeit, Datenmonopole, Klimarisiken, Desinformation und unfaire Lastenverteilung. Kommunikation darf nicht moralisieren. Sie muss Zustände zeigen, Unsicherheit benennen und Übergänge erklären.

Akzeptanz entsteht durch Nachvollziehbarkeit. Unternehmen brauchen stabile Regeln und digitale Schnittstellen. Bürger:innen brauchen verständliche Preissignale und sozialen Schutz. Partnerländer brauchen Datenhilfe, lokale Wertschöpfung und Mitsprache. Parlamente brauchen Kontrolle. Gerichte brauchen prüfbare Methoden. Medien brauchen Quellenklarheit.

### Abnahmekriterien für ein belastbares Detailkonzept

- Das Konzept benennt Wirkungsträger, Wirkungsempfänger und Wirkungsräume.
- Es unterscheidet Wirkungspotenzial, Wirkungsrisiko und eingetretene Wirkung.
- Es enthält Datenquellen, Datenqualitätslogik und Bewertungsregeln.
- Es benennt Zielkonflikte, rote Linien und Nichtkompensation.
- Es zeigt einen realistischen Pilot- und Umsetzungspfad.
- Es integriert SDG, SDG+, politische Anschlussfähigkeit, Quellen und Glossarlinks.
- Es vermeidet Dominanz, Personenbewertung und Social-Credit-Logik.

### Vertiefung: internationale Anschlussfähigkeit des Unterbereichs

Der Unterbereich "Klimagerechtigkeit und Ressourcenfairness" muss so beschrieben werden, dass er auf unterschiedlichen Ebenen anschlussfähig bleibt: EU-Recht, nationale Politik, kommunale Umsetzung, Unternehmenspraxis, Finanzsystem, Entwicklungszusammenarbeit, Wissenschaft und Zivilgesellschaft. Anschlussfähigkeit bedeutet dabei nicht, überall dieselbe Lösung zu erzwingen. Sie bedeutet, dass unterschiedliche Systeme mit denselben Wirkungsfragen arbeiten können.

Die erste Wirkungsfrage lautet: Welche Zustände werden verändert? Die zweite lautet: Wer trägt die Folgen? Die dritte lautet: Welche Daten belegen diese Veränderung? Die vierte lautet: Welche demokratische oder rechtliche Instanz kann die Bewertung prüfen? Erst wenn diese Fragen beantwortet sind, kann aus internationaler Komplexität eine belastbare Wirkungsarchitektur entstehen.

### Vertiefung: Zielkonflikte im Unterbereich

Jedes internationale Wirkungsfeld enthält Zielkonflikte. Für "Klimagerechtigkeit und Ressourcenfairness" sind besonders relevant: globale Vergleichbarkeit versus lokale Besonderheiten, Datenpflichten versus Verwaltungsfähigkeit, schnelle Transformation versus soziale Abfederung, offene Märkte versus Schutz vor externalisierten Schäden, Sicherheit versus Freiheit, Standardisierung versus Innovation und Kooperation versus strategische Autonomie.

Die Wirkungsökonomie löst diese Konflikte nicht durch eine einzige politische Antwort. Sie verlangt, dass die Konflikte sichtbar, begründet und überprüfbar werden. Ein Zielkonflikt darf nicht als technisches Problem versteckt werden. Er muss politisch entschieden und später evaluiert werden.

| Zielkonflikt | Risiko bei falscher Lösung | Wirkungsökonomische Antwort |
| --- | --- | --- |
| Vergleichbarkeit vs. Kontext | globale Gleichmacherei oder Beliebigkeit | gemeinsame Indikatoren plus lokale Benchmarks |
| Datenpflicht vs. Kapazität | Ausschluss kleiner Akteure | Datenhilfe, Übergänge, Standardwerte |
| Sicherheit vs. Freiheit | Abschottung oder Überwachung | Resilienz mit Rechtsschutz |
| Kooperation vs. Machtpolitik | Naivität oder Dominanz | Partnerschaft plus Kontrolle |

### Vertiefung: institutionelle Einbettung

Damit "Klimagerechtigkeit und Ressourcenfairness" nicht nur als Konzeptpapier funktioniert, braucht es institutionelle Einbettung. Dafür kommen je nach Thema Wirkungsrat, Wissensrat, europäische Datenräume, Handelskammern, Entwicklungsbanken, Standardisierungsorganisationen, kommunale Piloträume, unabhängige Audits, Gerichte und parlamentarische Berichtspflichten in Frage.

Institutionelle Einbettung heißt auch, dass Zuständigkeiten getrennt bleiben. Wissenschaft prüft und erklärt. Politik entscheidet. Verwaltung setzt um. Gerichte kontrollieren Rechtmäßigkeit. Zivilgesellschaft beobachtet und widerspricht. Unternehmen liefern Daten und verändern Praxis. Finanzakteure bilden Risiken ab. Diese Rollen dürfen nicht in einer technokratischen Superinstanz verschmelzen.

### Vertiefung: Finanzierungs- und Anreizlogik

Internationale Wirkung entsteht nur dann dauerhaft, wenn Finanzierung und Anreize zur Wirkungslogik passen. Solange Kapital externalisierte Schäden ignoriert, bleiben zerstörerische Pfade attraktiv. Rang 19 braucht daher Finanzierungsinstrumente, die Transformationswirkung, Resilienz, lokale Wertschöpfung und Schutzgüter belohnen, ohne Gewinne zu privatisieren und Risiken zu sozialisieren.

- Wirkungsfonds können Übergänge finanzieren und Datenkapazitäten aufbauen.
- Öffentliche Beschaffung kann wirkungspositive Lieferketten bevorzugen.
- Kapitalaufschläge können hohe Wirkungsrisiken sichtbar machen.
- Garantien und Versicherungen können Resilienzprojekte ermöglichen.
- T-SROI kann zeigen, ob Investitionen Systempfade verändern statt nur Projekterfolge zu zählen.

### Vertiefung: Website-Umsetzung des Detailkonzepts

Die Website-Fassung dieses Detailkonzepts muss vollständig online lesbar sein. Sie braucht ein mobil nutzbares Inhaltsverzeichnis, eine Kurzfassung, Downloadlinks für PDF und DOCX, Glossarlinks, Quellen, einen SDG-/SDG+-Block, politische Anschlussfähigkeit und Querverlinkungen zu den Portalen Wirtschaft, Finanzsystem, Klima, Digitalisierung, Sicherheit, Migration, Medien und Wissenschaft.

Die Downloadfassung muss im Corporate Design der Wirkungsökonomie erscheinen, mit Autorin Natalie Weber, Referenz Wirkungsökonomie, Version, Stand und Status. Interne CodeX-Hinweise dürfen nicht im öffentlichen Text erscheinen. Toolkarten müssen Beschreibung, Nutzen, Zielgruppe, Status und Link enthalten.

### Quellen und Anschlussrahmen

Weber, Natalie: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026, Teil XV: Internationale Ordnung, Globalisierung und Geopolitik, Kapitel 91 bis 96.

Weber, Natalie: Führender Begriffsleitfaden der Wirkungsökonomie, Version 1.0, Stand 21. Mai 2026.

United Nations: Transforming our world: the 2030 Agenda for Sustainable Development, Resolution A/RES/70/1, 2015. https://sdgs.un.org/2030agenda

European Commission: Carbon Border Adjustment Mechanism, definitive regime from 2026 after transitional phase 2023 to 2025. https://taxation-customs.ec.europa.eu/carbon-border-adjustment-mechanism_en

World Trade Organization: The WTO deals with the global rules of trade between nations. https://www.wto.org/

World Trade Organization: The WTO and the Sustainable Development Goals. https://www.wto.org/english/thewto_e/coher_e/sdgs_e/sdgs_e.htm

OECD: Development co-operation and the provision of global public goods, 2023. https://www.oecd.org/en/publications/development-co-operation-and-the-provision-of-global-public-goods_aff8cba9-en.html

UNDP: Sustainable Development Goals as integrated global goals. https://www.undp.org/sustainable-development-goals
