# Detailkonzept Fachbibliothek und Wissensarchiv

**Untertitel:** Vom Dokumentenbestand zur öffentlichen Wissensinfrastruktur
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Version:** 1.0
**Stand:** Mai 2026
**Status:** Langfassungsentwurf für Website, Akademie, Fachbibliothek und Downloadstruktur

## Kernthese

Die Fachbibliothek ist nicht Ablage, sondern Orientierungsraum. Sie ordnet alle Inhalte der Wirkungsökonomie nach Thema, Rang, Dokumenttyp, Status, Zielgruppe, SDG-/SDG+-Bezug und Anwendungsfall.

## Bibliotheksmodell

Jeder Eintrag braucht Titel, Kurzbeschreibung, Autorin, Referenz, Version, Stand, Status, Onlinefassung, PDF, DOCX, Quellen, Glossarlinks und Querverlinkungen. Die Bibliothek muss Volltextsuche, Filter und kuratierte Sammlungen unterstützen.

## Nutzungsszenarien

Eine Kommune sucht Integrationstools. Ein Unternehmen sucht Lieferkettenindikatoren. Eine Lehrkraft sucht Wirkungskompetenzmaterial. Eine politische Mitarbeiterin sucht Kurzfassungen und Dossiers. Die Fachbibliothek muss alle vier Wege ermöglichen.

## Beispiele und Anwendung

Beispiel Kommune: Eine Stadt nutzt die Fachbibliothek, um Integrations-, Wohnungs-, Bildungs- und Resilienzmaterialien gemeinsam zu lesen. Aus isolierten PDF-Downloads wird ein kommunaler Lernpfad mit Quellen, Glossar, Toolkarten und Umsetzungsbeispielen.

Beispiel Unternehmen: Ein Unternehmen baut Wirkungskompetenz nicht nur in der Nachhaltigkeitsabteilung auf, sondern in Einkauf, Produktentwicklung, Risikomanagement, Personal und Kommunikation. Die Akademie liefert Module, Fallstudien und Checklisten.

Beispiel Schule oder Hochschule: Lehrende verbinden Fach Zukunft, Systemdenken, Medienkompetenz und Projektlernen. Die Fachbibliothek liefert Hintergrundtexte, die Akademie Lernpfade und das Glossar eine gemeinsame Sprache.

Beispiel Redaktion: Vor Veröffentlichung eines Dossiers werden Begriffe, Quellen, Downloadlinks, Onlinefassung, mobile Tabellen, CodeX-Anweisung und politische Anschlussfähigkeit geprüft. Dadurch entsteht kein Content-Stapel, sondern verlässliche Wissensinfrastruktur.

## Daten- und Qualitätslogik

Die Qualitätslogik von Rang 23 beruht auf Nachvollziehbarkeit. Jede Seite muss zeigen, welche Fassung aktuell ist, welche Quelle verwendet wurde, welcher Dokumenttyp vorliegt und welche weiterführenden Inhalte verfügbar sind.

Datenqualität bedeutet hier nicht nur Zahlenqualität. Auch Begriffe, Links, Dateiformate, Versionen, Quellen, Metadaten, Statusangaben und mobile Darstellung sind Qualitätsdaten. Eine defekte Downloadstruktur ist eine negative Website-Wirkung.

Für jede Seite werden Mindestfelder definiert: Titel, Kurzbeschreibung, Autorin, Referenz, Version, Stand, Status, Dokumenttyp, Onlinefassung, PDF, DOCX, Quellen, Glossarlinks, Querverlinkungen, Druckansicht und Aktualisierungsdatum.

Die Datenstruktur soll als JSON-Index abbildbar sein. Dadurch kann die Website später Suche, Filter, Bibliotheksansichten, Lernpfad-Generatoren und Downloadübersichten automatisiert erzeugen.

## Website-Umsetzung

Die Website muss die Unterscheidung zwischen Lesen, Lernen, Anwenden und Downloaden sichtbar machen. Nicht jede Person will ein hundertseitiges Dossier lesen. Manche brauchen eine Kurzfassung, andere ein Tool, wieder andere eine Quelle oder ein Seminar.

Jede Langfassung soll online vollständig lesbar sein. PDF und DOCX sind zusätzliche Downloadformate, aber kein Ersatz für die Onlinefassung. Suchmaschinen, Screenreader, mobile Nutzer:innen und interne Links brauchen HTML-Volltexte.

Tabellen werden mobil als Cards oder horizontal scrollbare Elemente dargestellt. Inhaltsverzeichnisse werden einklappbar. Downloadbuttons zeigen Dateiformat und Version. Toolkarten zeigen Status und vermeiden Scheinverfügbarkeit.

Die Downloadseite eines Rangs enthält nicht nur eine Dateiliste, sondern eine kuratierte Übersicht: Was ist Einstieg, was ist Dossier, was ist Detailkonzept, was ist Toolkarte, was ist CodeX-Anweisung, was ist Gesamtpaket.

## Akademie-Transfer

Die Akademie übersetzt Inhalte in Fähigkeiten. Dazu braucht jedes Modul Lernziele, Kernbegriffe, Fallbeispiele, Übungsfragen, Reflexion, Transferaufgabe und Quellen. Ohne Übung bleibt Wirkung ein Lesebegriff.

Ein Lernpfad kann kurz sein: Was ist Wirkung? Was ist positive Netto-Wirkung? Warum ist SDG+ nötig? Wie erkenne ich Wirkungspotenzial? Ein anderer Lernpfad kann tief sein: Scorecards, Datenqualität, T-SROI, Reverse Merit Order und politische Anschlussfähigkeit.

Zertifikate sollen keine Haltung prüfen. Sie prüfen methodische Fähigkeit: Begriffe korrekt verwenden, Wirkungsräume analysieren, Zielkonflikte benennen, Datenquellen beurteilen, Schutzgrenzen beachten und Entscheidungen begründen.

Wirkungskompetenz wird dann wirksam, wenn sie in reale Rollen übersetzt wird: Lehrkraft, Einkäuferin, Produktmanager, Verwaltungsmitarbeiterin, Journalist, Kommunalpolitikerin, Investor, Pflegeleitung oder Bürger:in.

## Risiken und Schutzmechanismen

Risiko eins ist Überfrachtung. Die Wirkungsökonomie ist komplex. Rang 23 muss Komplexität ordnen, nicht vermehren. Deshalb braucht es klare Einstiegsebenen, Glossarlinks und Lernpfade.

Risiko zwei ist Autoritätsillusion. Eine Fachbibliothek darf nicht so auftreten, als seien alle Fragen abschließend beantwortet. Unsicherheit, Versionierung, Widerspruch und Korrektur gehören sichtbar dazu.

Risiko drei ist digitale Exklusion. Akademie und Bibliothek dürfen nicht nur für Menschen funktionieren, die technisch sicher, akademisch geschult und sprachlich stark sind. Es braucht einfache Einstiege, klare Sprache, Druckfassungen und unterschiedliche Lernformate.

Risiko vier ist Technokratie. Wirkungskompetenz darf Menschen nicht bewerten oder normieren. Bewertet werden Dokumente, Methoden, Strukturen, Programme, Tools und Wirkungsdaten, nicht Personen als Personen.

## Evaluation und Korrektur

Evaluation fragt, ob die Wissensarchitektur tatsächlich genutzt wird: Welche Seiten werden gelesen? Welche Downloads funktionieren? Welche Begriffe bleiben unklar? Welche Lernpfade werden abgeschlossen? Wo entstehen Fehlinterpretationen?

Korrektur braucht sichtbare Wege: Kontaktformular, Fehlerhinweis, fachliche Rückmeldung, Änderungsprotokoll, Versionierung und redaktionelle Antwort. Kritik wird nicht als Störung verstanden, sondern als Rückkopplung.

Jährlich sollte ein Bibliotheks- und Akademiebericht erscheinen. Er zeigt neue Inhalte, aktualisierte Begriffe, korrigierte Fehler, offene Baustellen, Nutzerfeedback, Lernpfade und geplante Weiterentwicklungen.

So wird Rang 23 selbst zum Beispiel der Wirkungsökonomie: nicht perfekt, sondern lernend, transparent, korrigierbar und anschlussfähig.

## Mindestarchitektur für jedes Detailkonzept

Jedes Detailkonzept braucht eine eigene Online-Identität. Dazu gehören eine klare URL, eine kurze Zusammenfassung, eine Volltextfassung, ein Inhaltsverzeichnis, Downloadlinks, eine Druckansicht, Quellen und Querverlinkungen.

Die Mindestarchitektur verhindert, dass Detailkonzepte zu isolierten PDFs werden. Sie zwingt die Redaktion, jedes fachliche Thema in das größere Wirkungsnetz einzubetten.

Zu jedem Detailkonzept gehört außerdem ein Abschnitt "Was dieses Konzept nicht leistet". Diese Grenze schützt vor Überdehnung, falschen Erwartungen und politischer Vereinnahmung.

Ein gutes Detailkonzept enthält Beispiele. Ohne Beispiele bleiben Begriffe wie Wirkungsarchitektur, Wirkungskompetenz, Netto-Wirkung oder Wirkungslenkung zu abstrakt.

## Rollen und Verantwortlichkeiten

Die Autorin verantwortet die inhaltliche Linie, die Begriffslogik und die Anschlussfähigkeit an die Wirkungsökonomie. Die Website-Redaktion verantwortet Darstellung, Linklogik, Downloadstruktur und Aktualität.

Die Akademie-Redaktion verantwortet Lernziele, Übungen, Lernpfade, Zertifikate und didaktische Übersetzung. Die Fachbibliotheks-Redaktion verantwortet Tags, Ordnung, Metadaten, Quellen und Versionierung.

Technische Umsetzung verantwortet Build, Routing, responsive Layouts, Suchindex, Dateipfade, Downloadlinks und Barrierearmut. Keine dieser Rollen ersetzt die anderen.

Schnittstellenverantwortung ist zentral: Viele Fehler entstehen nicht in einem Bereich allein, sondern zwischen Inhalt, Design, Technik, Quellenprüfung und Veröffentlichung.

## Beispielhafte Prozesskette

Schritt 1: Ein neues Detailkonzept wird fachlich erstellt und bekommt Metadaten. Schritt 2: Begriffe werden gegen den führenden Begriffsleitfaden geprüft. Schritt 3: Quellen werden ergänzt und in menschlich lesbarer Form angegeben.

Schritt 4: PDF und DOCX werden erzeugt und visuell geprüft. Schritt 5: Markdown und HTML werden für die Onlinefassung generiert. Schritt 6: Downloadlinks und interne Links werden getestet.

Schritt 7: Toolkarten, Glossarlinks, SDG-/SDG+-Block und politische Anschlussfähigkeit werden ergänzt. Schritt 8: Die Seite wird mobil geprüft. Schritt 9: Das Dokument wird in der Bibliothek indexiert.

Schritt 10: Nach Veröffentlichung beginnt die Rückkopplung. Fehlerhinweise, Nutzerfragen, neue Quellen und veränderte Begriffslogik werden in die nächste Version übersetzt.

## Anforderungen an Barrierearmut und Lesbarkeit

Barrierearmut beginnt nicht bei Technik, sondern bei Struktur. Kurze Absätze, klare Überschriften, wiedererkennbare Metadaten und sinnvolle Inhaltsverzeichnisse helfen allen Nutzer:innen.

PDFs bleiben wichtig für Download und Druck. HTML bleibt wichtig für Suche, mobile Nutzung, Barrierearmut und direkte Verlinkung. DOCX bleibt wichtig für Weiterbearbeitung, interne Abstimmung und redaktionelle Nutzung.

Tabellen sollen nie nur als große Desktop-Tabellen funktionieren. Wenn Inhalte mobil nicht lesbar sind, verliert die Website Wirkung. Kartenansichten, horizontales Scrollen und klare Tabellenüberschriften sind Pflicht.

Auch Sprache ist Barrierearmut. Fachbegriffe werden nicht vermieden, aber erklärt. Glossarlinks helfen, ohne den Haupttext zu überladen.

## Wirtschaftliche und organisatorische Anschlussfähigkeit

Rang 23 kann in Organisationen sofort genutzt werden. Unternehmen können interne Wirkungsakademien aufbauen. Kommunen können die Fachbibliothek für Schulungen und Bürger:innenformate nutzen. Hochschulen können Module in Lehre und Transfer integrieren.

Für kleine Organisationen braucht es niedrigschwellige Einstiegspakete: fünf Begriffe, drei Beispiele, ein Tool, ein Lernpfad und eine Checkliste. Für große Organisationen braucht es Vertiefungen, Rollenmodelle und Governance.

Die Fachbibliothek kann auch ein Beschleuniger für Beratungs-, Bildungs- und Akademieangebote werden. Sie zeigt, welche Materialien vorhanden sind und welche Pakete für welche Zielgruppen geeignet sind.

Damit wird Wissen selbst zu Infrastruktur. Nicht als Wissensmonopol, sondern als geteilte Orientierung, die andere befähigt, bessere Entscheidungen zu treffen.

## Langfristige Entwicklungslogik

Langfristig kann Rang 23 in drei Ausbaustufen wachsen. Stufe 1 stabilisiert Bibliothek, Downloads und Onlinefassungen. Stufe 2 baut Lernpfade, Übungen und Zertifikate. Stufe 3 verbindet Tooldemos, Datenräume und Community-Feedback.

Eine vierte Ausbaustufe kann Partnerschaften mit Schulen, Hochschulen, Kommunen, Unternehmen, Medien und zivilgesellschaftlichen Organisationen bilden. Diese Partnerschaften müssen transparent bleiben und dürfen die Begriffslogik nicht privatisieren.

Die Akademie kann später mehrere Formate anbieten: Selbstlernkurse, Präsenzseminare, Online-Workshops, Kommunalprogramme, Unternehmensmodule, Lehrkräftefortbildungen und öffentliche Wirkungslabore.

Die Fachbibliothek bleibt dabei der stabile Kern. Sie sammelt nicht alles, sondern ordnet das Relevante. Sie aktualisiert, archiviert, verlinkt und macht sichtbar, welche Inhalte für welche Fragen tragfähig sind.

## Praxisbeispiel: Von Rangpaket zu Lernmodul

Ein Rangpaket entsteht zunächst als ZIP mit PDF, DOCX, Markdown, HTML und CodeX-Anweisung. Rang 23 definiert, was danach geschieht: Das Paket wird nicht einfach abgelegt, sondern in die Fachbibliothek, die Akademie und die Website-Navigation übersetzt.

Aus dem Konzeptpapier entsteht ein Einstiegstext. Aus dem Gesamtdossier entsteht ein Vertiefungspfad. Aus den Detailkonzepten entstehen einzelne Lektionen. Aus den Toolkarten entstehen Übungen. Aus dem SDG-/SDG+-Block entsteht ein Reflexionsmodul.

Die politische Anschlussfähigkeit wird als Fallübung genutzt: Welche Entscheidungen bleiben demokratisch offen? Welche Wirkungen sind empirisch prüfbar? Wo liegen Zielkonflikte? Welche Schutzmechanismen verhindern Technokratie?

Die Quellen werden als Quellenkompetenz genutzt: Welche Quelle ist amtlich? Welche ist wissenschaftlich? Welche ist interne WÖk-Quelle? Welche Quelle braucht Aktualisierung? Welche Quelle trägt die Aussage wirklich?

Die Glossarbegriffe werden zu einem Lerncheck. Nutzer:innen sollen Wirkung nicht mit positiver Wirkung verwechseln, Wirkungspotenzial nicht als eingetretene Wirkung behandeln und SDG+ nicht als UN-Kategorie ausgeben.

So entsteht aus jedem Rangpaket ein didaktisch nutzbares Modul. Die Website ist dann nicht nur Auslage, sondern Lernumgebung.

Die gleiche Logik gilt für alle Portale. Rang 23 macht den Prozess wiederholbar, prüfbar und skalierbar.

Damit wird die Wirkungsökonomie operationalisierbar: Inhalte werden zu Kompetenzen, Kompetenzen zu Entscheidungen und Entscheidungen zu besserer Rückkopplung.

## Praxisbeispiel: Redaktioneller Prüfpfad

Vor Veröffentlichung einer Seite prüft die Redaktion zuerst den Dokumenttyp. Ein kurzer Überblick darf nicht als Detailkonzept erscheinen. Ein Detailkonzept braucht Fachkapitel, Beispiele, Datenquellen, SDG-/SDG+-Bezug und politische Anschlussfähigkeit.

Danach wird die Begriffslogik geprüft. Besonders kritisch sind die Begriffe Wirkung, positive Netto-Wirkung, Wirkungspotenzial, Wirkungsrisiko, Transformationswirkung, Wirkungslenkung, Wirkungsarchitektur und SDG+.

Im dritten Schritt werden Quellen und Aussagen geprüft. Eine starke Aussage braucht tragfähige Begründung. Wenn Unsicherheit besteht, wird sie benannt. Wenn Quellen veraltet sind, werden sie markiert oder ersetzt.

Im vierten Schritt wird die technische Veröffentlichung geprüft: Routing, Dateipfade, Downloadlinks, HTML-Volltext, DOCX, PDF, Druckansicht, mobile Tabellen, Inhaltsverzeichnis, Breadcrumbs und Querverlinkungen.

Im fünften Schritt wird die öffentliche Wirkung geprüft. Erzeugt die Seite Orientierung oder Verwirrung? Ist sie zugänglich? Sind Zielkonflikte sichtbar? Gibt es unnötige Alarmbegriffe? Wird Demokratie als Ausgestaltungsspielraum respektiert?

Im sechsten Schritt wird die Seite in die Bibliothek eingetragen. Erst dann gilt sie als vollständig veröffentlicht.

Dieser Prüfpfad ist nicht Bürokratie. Er reduziert Blindleistung, weil er Fehler vor der Veröffentlichung sichtbar macht.

Er schützt Natalie Weber als Autorin, die Wirkungsökonomie als Referenz und die Nutzer:innen vor unvollständigen oder irreführenden Inhalten.

## Begriffslogik

Wirkung ist neutral und relational. Wirkung ist die tatsächliche Veränderung von Zuständen. Sie kann positiv, negativ oder neutral sein und braucht immer einen Bezugspunkt.

Bewertet wird am Referenzrahmen der SDGs, der Agenda 2030 und SDG+. SDG+ ist keine UN-Kategorie, sondern eine transparente Erweiterung der Wirkungsökonomie für Demokratie, Medienqualität, Rechtsstaatlichkeit, Diskursfähigkeit, institutionelles Vertrauen, gesellschaftlichen Zusammenhalt und digitale Selbstbestimmung.

Ziel der Wirkungsökonomie ist positive Netto-Wirkung für Mensch, Planet und Demokratie. Diese Zielgröße ersetzt keine demokratische Entscheidung, sondern macht Folgen, Wirkungsrisiken und Zielkonflikte sichtbar.

## Problem und Wirkungsrisiko

Das zentrale Risiko besteht darin, dass viele gute Inhalte entstehen, aber nicht als System zusammenwirken. Wenn Onlinefassungen fehlen, Downloads nicht funktionieren, Begriffe uneinheitlich verwendet werden oder Toolkarten nur Namen tragen, verliert die Website Wirkung.

Ein zweites Risiko ist Wissensungleichheit. Wer die Wirkungsökonomie nur als Fachtext versteht, erreicht vor allem Expert:innen. Eine Akademie muss unterschiedliche Zugänge schaffen: schnelle Einstiege, verständliche Lernpfade, vertiefende Dossiers, Glossare, Übungen, Beispiele und Zertifikate.

Ein drittes Risiko ist Wirkungssimulation. Wenn Inhalte nur nach außen professionell wirken, aber keine geprüften Quellen, Versionen, Korrekturwege und Downloadlogik besitzen, entsteht ein Schein von Fachlichkeit ohne belastbare Rückkopplung.

## Zielbild

Ziel ist eine Wissensarchitektur, in der jedes Portal, jedes Dossier, jedes Detailkonzept, jede Toolkarte und jeder Download in eine klare Ordnung eingebettet ist.

Nutzer:innen sollen erkennen: Was ist Überblick? Was ist Langfassung? Was ist Detailkonzept? Was ist Tool? Was ist Buchanker? Was ist Glossarbegriff? Was ist Quelle? Was ist Demo in Vorbereitung?

Die Akademie soll Wirkungskompetenz aufbauen: Wahrnehmungskompetenz, Systemkompetenz, Analysekompetenz, Kommunikationskompetenz und Entscheidungskompetenz.

## Umsetzungsebenen

Erste Ebene ist die öffentliche Fachbibliothek mit stabilen Seiten, Tags, Suchfunktionen, Downloadübersichten und Zitierhinweisen.

Zweite Ebene ist die Akademie mit Kursen, Lernpfaden, Übungen, Fallstudien, Zertifikatslogik und Lernfortschritt.

Dritte Ebene ist die redaktionelle Governance mit Versionierung, Quellenprüfung, Glossarbindung, Qualitätssicherung und klarer Unterscheidung zwischen Entwurf, Beta, veröffentlicht und archiviert.

Vierte Ebene ist die Website-UX: mobile Inhaltsverzeichnisse, responsive Tabellen, Druckfunktionen, vollständige Onlinefassungen und funktionierende Downloads.

## Politische Anschlussfähigkeit und Umsetzungsoptionen

Die Wirkungsökonomie liefert keinen fertigen Parteiprogrammtext, sondern einen Bewertungs- und Steuerungsrahmen. Parteien, Verwaltungen, Bildungsinstitutionen und zivilgesellschaftliche Akteure behalten Ausgestaltungsspielraum.

Politik muss Rahmenbedingungen schaffen, in denen Wirkungskompetenz, öffentliche Wissensinfrastruktur, transparente Quellen, faire Datenzugänge und lernfähige Korrekturverfahren möglich werden.

Die Ausgestaltung kann parteipolitisch unterschiedlich erfolgen: über öffentliche Akademien, Hochschulprogramme, kommunale Lernorte, digitale Bibliotheken, Förderprogramme, Open-Source-Infrastrukturen, Bürger:innen-Akademien oder zertifizierte Weiterbildung.

Schutz vor Technokratie bedeutet: Wirkungskompetenz darf nicht zur Belehrung von oben werden. Methoden, Daten, Bewertungslogiken und Unsicherheiten müssen öffentlich erklärt, versioniert, kritisierbar und korrigierbar sein.

## Quellen und Anschlussrahmen

Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026. Bezug: Wirkungskompetenz, Fach Zukunft, Wirkungswohlstand und lernende Rückkopplung.

Natalie Weber: Systemmodell der Wirkungsökonomie, 2025. Bezug: Wirkungskompetenz-Akademie, Wirkungsdaten, KI-Wirkungsmodelle, systemisches Denken und evidenzbasierte Politikberatung.

Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, 21. Mai 2026. Bezug: Wirkung, Wirkungspotenzial, Netto-Wirkung, SDG+ und Wirkungsarchitektur.

UNESCO: Recommendation on Open Science, 2021. URL: https://www.unesco.org/en/open-science
