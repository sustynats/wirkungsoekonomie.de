# Quellen und Glossarlinks Rang 23

**Untertitel:** Anschlussrahmen, Begriffe und Zitierlogik
**Autorin:** Natalie Weber
**Referenz:** Wirkungsökonomie
**Version:** 1.0
**Stand:** Mai 2026
**Status:** Langfassungsentwurf für Website, Akademie, Fachbibliothek und Downloadstruktur

## Quellenrahmen

Natalie Weber: Die neue Ordnung des Wohlstands, Arbeitsfassung 2026. Bezug: Wirkungskompetenz, Fach Zukunft, Wirkungswohlstand und lernende Rückkopplung.

Natalie Weber: Systemmodell der Wirkungsökonomie, 2025. Bezug: Wirkungskompetenz-Akademie, Wirkungsdaten, KI-Wirkungsmodelle, systemisches Denken und evidenzbasierte Politikberatung.

Natalie Weber: Führender Begriffsleitfaden der Wirkungsökonomie, 21. Mai 2026. Bezug: Wirkung, Wirkungspotenzial, Netto-Wirkung, SDG+ und Wirkungsarchitektur.

UNESCO: Recommendation on Open Science, 2021. URL: https://www.unesco.org/en/open-science

OECD: Learning Compass 2030. URL: https://www.oecd.org/en/data/tools/oecd-learning-compass-2030.html

Europäische Kommission: Digital Education Action Plan 2021-2027. URL: https://education.ec.europa.eu/focus-topics/digital-education/actions

Rat der Europäischen Union: Council Recommendation of 22 May 2018 on key competences for lifelong learning. URL: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=oj:JOC_2018_189_R_0001

## Glossarlinks

Zentrale Glossarbegriffe: Wirkung, Wirkungspotenzial, Wirkungsrisiko, Netto-Wirkung, positive Netto-Wirkung, Transformationswirkung, Wirkungslenkung, Wirkungsarchitektur, Wirkungskompetenz, Wirkungsdaten, Wirkungsraum, Resonanzraum, SDG+ und Reverse Merit Order.

Jede Onlinefassung sollte die zentralen Begriffe auf das Glossar verlinken.

## Zitierhinweis

Empfohlene Zitierweise: Weber, Natalie: Rang 23 - Wirkungsakademie, Fachbibliothek und Wirkungskompetenz. Wirkungsökonomie, Version 1.0, Stand Mai 2026.

Bei Onlinefassungen sollen Veröffentlichungsdatum, Version, URL und Abrufdatum ergänzt werden.
